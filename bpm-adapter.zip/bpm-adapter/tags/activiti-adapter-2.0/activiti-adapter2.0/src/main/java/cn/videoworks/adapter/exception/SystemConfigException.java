package cn.videoworks.adapter.exception;

/**
 * Created by caofeiyi on 2014/7/8.
 */
public class SystemConfigException extends Exception {
    public SystemConfigException() {
        super();
    }

    public SystemConfigException(String message) {
        super(message);
    }

    public SystemConfigException(Throwable cause) {
        super(cause);
    }

    public SystemConfigException(String message, Throwable cause) {
        super(message, cause);
    }


    public SystemConfigException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
        super(message, cause, enableSuppression, writableStackTrace);
    }
}
