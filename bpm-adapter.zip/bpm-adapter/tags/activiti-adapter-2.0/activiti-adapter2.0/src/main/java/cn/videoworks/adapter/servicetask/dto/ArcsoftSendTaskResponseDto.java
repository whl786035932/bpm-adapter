package cn.videoworks.adapter.servicetask.dto;

import cn.videoworks.adapter.servicetask.enumeration.ArcsoftTaskStatus;

import java.util.List;

/**
 * Created by caofeiyi on 2015/1/13.
 */
public class ArcsoftSendTaskResponseDto {
    private String href;
    private ArcsoftTaskStatus status;
    private List<String> errors;

    public String getHref() {
        return href;
    }

    public void setHref(String href) {
        this.href = href;
    }

    public ArcsoftTaskStatus getStatus() {
        return status;
    }

    public void setStatus(ArcsoftTaskStatus status) {
        this.status = status;
    }

    public List<String> getErrors() {
        return errors;
    }

    public void setErrors(List<String> errors) {
        this.errors = errors;
    }
}
