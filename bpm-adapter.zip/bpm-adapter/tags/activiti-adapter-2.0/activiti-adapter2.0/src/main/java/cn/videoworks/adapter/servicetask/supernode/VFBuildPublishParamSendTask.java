package cn.videoworks.adapter.servicetask.supernode;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Map;

import org.activiti.engine.delegate.DelegateExecution;
import org.activiti.engine.delegate.JavaDelegate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public  class VFBuildPublishParamSendTask implements JavaDelegate {

	private Logger logger = LoggerFactory
			.getLogger(VFBuildPublishParamSendTask.class);

	DateFormat df = new SimpleDateFormat("yyyyMMddHHmmss");

	public void execute(DelegateExecution delegateExecution) {
		try {
			Map<String, Object> variables = delegateExecution.getVariables();
			delegateExecution.setVariable("errcode", 0);
			delegateExecution.setVariable("error_msg", "组装发布系统参数任务成功");
			logger.debug("下发组装发布系统参数任务成功!");
		} catch (Exception e) {
			logger.error(e.getMessage(), e.fillInStackTrace());
			delegateExecution.setVariable("errcode", 1);
			delegateExecution.setVariable("error_msg", "发布系统下发任务异常");
		}
	}

	
}
