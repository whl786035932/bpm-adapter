package cn.videoworks.adapter.exception;

/**
 * Created by caofeiyi on 2015/1/12.
 */
public class XmlException extends Exception {
    public XmlException() {
        super();
    }

    public XmlException(String message) {
        super(message);
    }


    public XmlException(Throwable cause) {
        super(cause);
    }

    public XmlException(String message, Throwable cause) {
        super(message, cause);
    }

    protected XmlException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
        super(message, cause, enableSuppression, writableStackTrace);
    }
}
