package cn.videoworks.adapter.servicetask.node;

import cn.videoworks.adapter.servicetask.supernode.EncryptEncryptSuperCheckTask;

public class EncryptEncryptCheck extends EncryptEncryptSuperCheckTask{

}
