package cn.videoworks.adapter.servicetask.dto;

import cn.videoworks.adapter.servicetask.entity.TaskProgress;

public class MCClusterArcVideoTranscodeCheckTaskResponseDto {
	private String taskId;
	//任务状态
	private String taskStatus;
	//任务开始时间
	private String taskStartAt;
	//任务结束时间
	private String taskCompleteAt;
	//出错描述（预留）
	private String lastError;
	//任务进度
	private TaskProgress taskProgress;

	public String getTaskId() {
		return taskId;
	}

	public void setTaskId(String taskId) {
		this.taskId = taskId;
	}

	public String getTaskStatus() {
		return taskStatus;
	}

	public void setTaskStatus(String taskStatus) {
		this.taskStatus = taskStatus;
	}

	public String getTaskStartAt() {
		return taskStartAt;
	}

	public void setTaskStartAt(String taskStartAt) {
		this.taskStartAt = taskStartAt;
	}

	public String getTaskCompleteAt() {
		return taskCompleteAt;
	}

	public void setTaskCompleteAt(String taskCompleteAt) {
		this.taskCompleteAt = taskCompleteAt;
	}

	public String getLastError() {
		return lastError;
	}

	public void setLastError(String lastError) {
		this.lastError = lastError;
	}

	public TaskProgress getTaskProgress() {
		return taskProgress;
	}

	public void setTaskProgress(TaskProgress taskProgress) {
		this.taskProgress = taskProgress;
	}

}
