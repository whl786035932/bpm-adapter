package cn.videoworks.adapter.servicetask.dto;

public class MCClusterArcVideoTranscodeCheckTaskRequestDto {
	//任务id
	private String taskId;

	public String getTaskId() {
		return taskId;
	}

	public void setTaskId(String taskId) {
		this.taskId = taskId;
	}
	
	
}
