package cn.videoworks.adapter.servicetask.node;

import java.util.List;

import org.activiti.engine.delegate.DelegateExecution;
import org.activiti.engine.delegate.JavaDelegate;
import org.activiti.engine.history.VWHistoricProcessInstance;
import org.activiti.engine.history.VWHistoricTaskInstance;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import cn.videoworks.adapter.util.JsonUtil;

public class AdapterTaskAutoAssigneeForBack implements JavaDelegate {
	private Logger logger = LoggerFactory
			.getLogger(AdapterTaskAutoAssigneeForBack.class);

	public void execute(DelegateExecution execution) {
		try {
			String taskAssignee = "";
			String taskDefinitionKey = "";
			String processId = "";
			if (execution.getVariables().containsKey("taskDefinitionKey")
					&& execution.getVariables().get("taskDefinitionKey") != null) {
				taskDefinitionKey = String.valueOf(execution.getVariables()
						.get("taskDefinitionKey"));
			}
			if (StringUtils.isNotBlank(taskDefinitionKey)) {
				String childProcessInstanceId = execution
						.getProcessInstanceId();
				logger.debug("自动分配打回任务,子流程ID:"+childProcessInstanceId);
				VWHistoricProcessInstance childProcess = execution
						.getEngineServices().getHistoryService()
						.createVWHistoricProcessInstanceQuery()
						.processInstanceId(childProcessInstanceId)
						.singleResult();
				logger.debug("自动分配打回任务,子流程:"+JsonUtil.format(childProcess));
				VWHistoricProcessInstance process = execution
						.getEngineServices()
						.getHistoryService()
						.createVWHistoricProcessInstanceQuery()
						.processInstanceId(
								childProcess.getSuperProcessInstanceId())
						.singleResult();
				logger.debug("自动分配打回任务,父流程:"+JsonUtil.format(process));
				processId = process.getId();
				List<VWHistoricTaskInstance> tasks = execution
						.getEngineServices().getHistoryService()
						.createVWHistoricTaskInstanceQuery().finished()
						.processInstanceId(process.getId())
						.taskDefinitionKey(taskDefinitionKey)
						.orderByHistoricTaskInstanceEndTime().desc().list();
				if (tasks != null && tasks.size() > 0) {
					taskAssignee = tasks.get(0).getAssignee();
				}
			}
			if (StringUtils.isNotBlank(taskAssignee)) {
				logger.debug("自动分配打回任务成功:已将流程[" + processId + "]中的打回的["
						+ taskDefinitionKey + "]任务分配给[" + taskAssignee + "]");
				execution.setVariable("taskAssignee", taskAssignee);
			} else {
				logger.debug("自动分配打回任务错误");
				execution.setVariable("taskAssignee", null);
			}
		} catch (Exception e) {
			e.printStackTrace();
			logger.debug("自动分配打回任务异常", e.fillInStackTrace());
			execution.setVariable("taskAssignee", null);
		}
	}

}
