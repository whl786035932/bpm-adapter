package cn.videoworks.adapter.servicetask.node;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.HashMap;
import java.util.Map;

import org.activiti.engine.delegate.DelegateExecution;
import org.activiti.engine.delegate.JavaDelegate;
import org.apache.http.HttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.params.CoreConnectionPNames;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import cn.videoworks.adapter.util.HttpUtil;
import cn.videoworks.adapter.util.JsonUtil;
import cn.videoworks.adapter.util.PropertiesUtil;
import cn.videoworks.commons.util.json.JsonConverter;

public class VFPreTaskStatusActual implements JavaDelegate {

private Logger logger = LoggerFactory.getLogger(VFPreTaskStatusActual.class);
	
    public void execute(DelegateExecution delegateExecution) throws Exception {
        try {
            Map<String, String> dataMap = new HashMap<String, String>();
            int clipId = Integer.parseInt(delegateExecution.getVariables().get("clip_id").toString());
            String url = "http://" + PropertiesUtil.get("application.ip") + "/workflowAutoTask/vfPreTaskStatus/"+clipId;
//            String responseJson = HttpUtil.httpGet(url);
            DefaultHttpClient httpClient = new DefaultHttpClient();
            httpClient.getParams().setParameter(CoreConnectionPNames.CONNECTION_TIMEOUT,10000);
            httpClient.getParams().setParameter(CoreConnectionPNames.SO_TIMEOUT,10000);
            HttpGet getRequest = new HttpGet(url);
            HttpResponse response = httpClient.execute(getRequest);
            InputStream is = response.getEntity().getContent();
            BufferedReader in = new BufferedReader(new InputStreamReader(is));
            StringBuffer buffer = new StringBuffer();
            String line = "";
            while ((line = in.readLine()) != null) {
                buffer.append(line);
            }
			String responseJson = buffer.toString();
            Map<String,Object> res =JsonUtil.parse(responseJson,Map.class);
            if ((int) Double.parseDouble(res.get("statusCode").toString()) == 200) {
				Map<String, Object> body = (Map<String, Object>) res.get("body");
				delegateExecution.setVariable("pre_status", (int)Double.parseDouble(body.get("status").toString()));
            }
        } catch (Exception e) {
        	e.printStackTrace();
            logger.error(e.getMessage(), e.fillInStackTrace());
            delegateExecution.setVariable("pre_status", 1);
        }
    }
}
