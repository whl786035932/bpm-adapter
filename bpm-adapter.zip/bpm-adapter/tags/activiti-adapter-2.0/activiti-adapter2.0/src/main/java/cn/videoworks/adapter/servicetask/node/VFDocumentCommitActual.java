package cn.videoworks.adapter.servicetask.node;

import cn.videoworks.adapter.servicetask.enumeration.ApplicationActualTaskType;
import cn.videoworks.adapter.servicetask.supernode.ApplicationSuperActualTask;

public class VFDocumentCommitActual extends ApplicationSuperActualTask{

	@Override
	public ApplicationActualTaskType getType() throws Exception {
		// TODO Auto-generated method stub
		 return ApplicationActualTaskType.vfDocumentCommit;
	}

	

}
