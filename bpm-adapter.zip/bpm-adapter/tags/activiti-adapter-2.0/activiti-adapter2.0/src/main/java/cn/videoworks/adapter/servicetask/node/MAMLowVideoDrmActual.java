package cn.videoworks.adapter.servicetask.node;

import cn.videoworks.adapter.servicetask.enumeration.ApplicationActualTaskType;
import cn.videoworks.adapter.servicetask.supernode.ApplicationSuperActualTask;

/**
 * Created by caofeiyi on 2015/1/20.
 */
public class MAMLowVideoDrmActual extends ApplicationSuperActualTask {
    public ApplicationActualTaskType getType() throws Exception {
        return ApplicationActualTaskType.mamLowVideoDrm;
    }
}
