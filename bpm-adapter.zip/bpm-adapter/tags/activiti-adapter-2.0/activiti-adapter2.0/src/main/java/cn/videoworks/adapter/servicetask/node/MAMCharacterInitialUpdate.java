package cn.videoworks.adapter.servicetask.node;


import cn.videoworks.adapter.servicetask.enumeration.ApplicationActualTaskType;
import cn.videoworks.adapter.servicetask.supernode.ApplicationSuperActualTask;

public class MAMCharacterInitialUpdate extends ApplicationSuperActualTask {

    public ApplicationActualTaskType getType() throws Exception {
        return ApplicationActualTaskType.mamCharacterInitialUpdate;
    }
}
