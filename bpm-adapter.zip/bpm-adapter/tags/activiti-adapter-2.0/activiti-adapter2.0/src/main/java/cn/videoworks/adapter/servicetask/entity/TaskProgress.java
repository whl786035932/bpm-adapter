package cn.videoworks.adapter.servicetask.entity;

public class TaskProgress {
	//具体文件的进度，预留，当前返回0
	private Integer index;
	//任务开始后花费的时间，单位秒
	private Integer elapsed;
	//任务进度，为1-100，单位%
	private Integer progress;
	public Integer getIndex() {
		return index;
	}
	public void setIndex(Integer index) {
		this.index = index;
	}
	public Integer getElapsed() {
		return elapsed;
	}
	public void setElapsed(Integer elapsed) {
		this.elapsed = elapsed;
	}
	public Integer getProgress() {
		return progress;
	}
	public void setProgress(Integer progress) {
		this.progress = progress;
	}
	
}
