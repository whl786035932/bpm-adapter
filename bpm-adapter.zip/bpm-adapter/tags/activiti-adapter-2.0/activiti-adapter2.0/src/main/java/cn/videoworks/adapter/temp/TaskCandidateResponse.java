package cn.videoworks.adapter.temp;

import java.util.Map;

public class TaskCandidateResponse {
	private int statusCode;
	private String message;
	private TaskCandidateResponseData data;

	public int getStatusCode() {
		return statusCode;
	}

	public void setStatusCode(int statusCode) {
		this.statusCode = statusCode;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public TaskCandidateResponseData getData() {
		return data;
	}

	public void setData(TaskCandidateResponseData data) {
		this.data = data;
	}

}
