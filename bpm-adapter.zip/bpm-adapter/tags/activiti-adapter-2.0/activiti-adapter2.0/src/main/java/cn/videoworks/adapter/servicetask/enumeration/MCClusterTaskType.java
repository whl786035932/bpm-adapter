package cn.videoworks.adapter.servicetask.enumeration;

/**
 * Created by caofeiyi on 2014/7/7.
 */
public enum MCClusterTaskType {
    Transcode,          //转码
    Cut,                //切割
    Index,              //索引
    LocateFrame,        //定位视频帧
    FrameFeature,       //获取指定帧特征值
    Image,              //获取视频帧图片
    KeyFrames,          //提取关键帧
    MediaInfo,          //媒体信息
    DeleteFile,         //删除文件
    CopyFiles,          //复制文件
    WriteFile,          //写入文件
    AutoReview,         //自动计审
    SpeechRecognition,  //语音识别
    SpeechChinese,  	//语音识别(中文)
    SpeechEnglish,  	//语音识别(英文)
    SubtitleRecognition,//字幕识别
    Segment,            //视频分段
    Md5                 //计算MD5
}
