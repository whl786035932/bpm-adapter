package cn.videoworks.adapter.temp;

import java.util.Set;

/**
 * 角色实体类.
 *
 * @author LuoChuan
 * @version 1.0.0
 * @since 1.0.0
 */
public class Role {

	/** 角色ID. */
	private int id;

	/** 角色名称. */
	private String name;

	/** 角色类别. */
	private RoleType category;

	/** 角色包含用户列表. */
	private Set<UserInfo> users;

	/** 角色权限列表. */
	private Set<Authorization> authorizations;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public RoleType getCategory() {
		return category;
	}

	public void setCategory(RoleType category) {
		this.category = category;
	}

	public Set<UserInfo> getUsers() {
		return users;
	}

	public void setUsers(Set<UserInfo> users) {
		this.users = users;
	}

	public Set<Authorization> getAuthorizations() {
		return authorizations;
	}

	public void setAuthorizations(Set<Authorization> authorizations) {
		this.authorizations = authorizations;
	}
}
