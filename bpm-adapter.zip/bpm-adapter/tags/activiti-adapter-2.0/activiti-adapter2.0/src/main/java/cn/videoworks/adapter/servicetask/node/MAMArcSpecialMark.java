package cn.videoworks.adapter.servicetask.node;


import cn.videoworks.adapter.servicetask.enumeration.ApplicationActualTaskType;
import cn.videoworks.adapter.servicetask.supernode.ApplicationSuperActualTask;

public class MAMArcSpecialMark extends ApplicationSuperActualTask {

    public ApplicationActualTaskType getType() throws Exception {
    	System.out.println("现在要进行的是：山东虹软出库转码特殊处理");
        return ApplicationActualTaskType.mamArcSpecialMark;
    }
}
