package cn.videoworks.adapter.servicetask.node;

import cn.videoworks.adapter.servicetask.enumeration.MCClusterTaskType;
import cn.videoworks.adapter.servicetask.supernode.MCClusterSuperSendTask;
import cn.videoworks.adapter.util.JsonUtil;

import java.util.*;
import java.util.Map.Entry;

public class MCClusterKeyFramesSend extends MCClusterSuperSendTask {

    public Map<String, Object> getParam(Map<String, Object> variables) throws Exception {
        Map<String, Object> paramMap = new HashMap<String, Object>();
        Iterator<Entry<String, Object>> iter = variables.entrySet().iterator();
        while (iter.hasNext()) {
            Map.Entry entry = (Map.Entry) iter.next();
            String key = (String) entry.getKey();
            Object val = entry.getValue();
            if (key.equals("video_url")) {
                List<String> list = JsonUtil.parse((String) val, List.class);
                paramMap.put("file", list.get(0));
            } else if (key.equals("keyframes_menu")) {
                paramMap.put("output_path", (String) val);
            }
        }
        if (paramMap.containsKey("file") && paramMap.containsKey("output_path")) {
            return paramMap;
        } else {
            return null;
        }
    }

    public List<String> getTemplate(Map<String, Object> variables) throws Exception {
        return new LinkedList<String>();
    }

    public MCClusterTaskType getType() throws Exception {
        return MCClusterTaskType.KeyFrames;
    }

}