package cn.videoworks.adapter.servicetask.node;

import java.util.HashMap;
import java.util.Map;

import org.activiti.engine.delegate.DelegateExecution;
import org.activiti.engine.delegate.JavaDelegate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import cn.videoworks.adapter.exception.SystemConfigException;
import cn.videoworks.adapter.util.HttpUtil;
import cn.videoworks.adapter.util.HttpUtil.HttpRequestType;
import cn.videoworks.adapter.util.JsonUtil;
import cn.videoworks.adapter.util.PropertiesUtil;
/**
 * 上传媒资内容到百度VOD
 * @author ad
 *
 */
public class BaiduVodUploadContentSend implements JavaDelegate{
	private Logger logger = LoggerFactory.getLogger(BaiduVodUploadContentSend.class);
	/**
	 * 流入参数（子流程变量）
	 * title:题名
	 * mamId:媒资id
	 * videoUrl:视频地址（本地路径）
	 * description:描述
	 */
	@Override
	public void execute(DelegateExecution delegateExecution){
		try {
			logger.info("开始下发媒资【"+String.valueOf(delegateExecution.getVariables().get("mamId"))+"】【"+String.valueOf(delegateExecution.getVariables().get("title"))+"】上传到百度VOD任务");
			Map<String,String> requestMap=buildRequestMap(delegateExecution.getVariables(),delegateExecution.getProcessInstanceId());
			String requestJson=JsonUtil.format(requestMap);
			String voidServerAddress=PropertiesUtil.get("baidu.vod.server");
			String url="http://"+voidServerAddress+"/forward2bdvod/api/uploadMediaAsset";
			logger.info("下发任务地址【"+url+"】参数【"+JsonUtil.format(requestMap)+"】");
			String responseJson=HttpUtil.httpPost(url, requestJson, HttpRequestType.JSON);
			logger.info("下发任务结果参数【"+responseJson+"】");
			Map<String,Object> responseMap=JsonUtil.parse(responseJson, Map.class);
			int statusCode=Integer.valueOf(String.valueOf(responseMap.get("statusCode")).indexOf(".")>=0?String.valueOf(responseMap.get("statusCode")).substring(0, String.valueOf(responseMap.get("statusCode")).indexOf(".")):String.valueOf(responseMap.get("statusCode")));
			if(statusCode==200){
				String taskIdStr=String.valueOf(((Map<String,Object>)(responseMap.get("body"))).get("taskId"));
				taskIdStr=taskIdStr.indexOf(".")>=0?taskIdStr.substring(0, taskIdStr.indexOf(".")):taskIdStr;
				Integer taskId=Integer.valueOf(taskIdStr);
				delegateExecution.setVariable("taskId", taskId);
				delegateExecution.setVariable("errcode", 0);
	            delegateExecution.setVariable("error_msg", "内容上传到百度VOD任务下发成功");
	            logger.info("内容上传到百度VOD任务下发成功:【"+taskId+"】【"+responseJson+"】");
			}else{
				delegateExecution.setVariable("errcode", 1);
	            delegateExecution.setVariable("error_msg", "内容上传到百度VOD任务下发失败");
	            logger.info("内容上传到百度VOD任务下发失败");
			}
		} catch (Exception e) {
			delegateExecution.setVariable("errcode", 1);
            delegateExecution.setVariable("error_msg", "内容上传到百度VOD任务下发异常");
            logger.error("内容上传到百度VOD任务下发任务异常",e.fillInStackTrace());
		}
	}
	
	private Map<String,String> buildRequestMap(Map<String,Object> variablesMap,String procId) throws Exception{
		Map<String,String> requestMap=new HashMap<String, String>();
		String vodeoUrl=String.valueOf(variablesMap.get("videoUrl"));
		if(vodeoUrl.startsWith("vwfs://")){
			String url = "http://" + PropertiesUtil.get("application.ip") + "/workflowAutoTask/getStorageUrl?url="+vodeoUrl.replace("vwfs://", "/");
			vodeoUrl=HttpUtil.httpGet(url);
		}
		requestMap.put("mamId", String.valueOf(variablesMap.get("mamId")));
		requestMap.put("title", String.valueOf(variablesMap.get("title")));
		requestMap.put("fileUrl",vodeoUrl);
		requestMap.put("description", variablesMap.get("description")==null?"":String.valueOf(variablesMap.get("description")));
		requestMap.put("callBackUrl", PropertiesUtil.get("callback.url")+"/"+procId);
		return requestMap;
	}

	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
