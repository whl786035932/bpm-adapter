package cn.videoworks.adapter.servicetask.node;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import org.activiti.engine.delegate.DelegateExecution;
import org.activiti.engine.delegate.JavaDelegate;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import cn.videoworks.adapter.exception.AdapterBusinessException;

import cn.videoworks.adapter.servicetask.dto.ArcDrmSendRequestDto;
import cn.videoworks.adapter.servicetask.dto.MCClusterArcVideoTranscodeSendTaskRequestDto;
import cn.videoworks.adapter.util.HttpUtil;
import cn.videoworks.adapter.util.JsonUtil;
import cn.videoworks.adapter.util.PropertiesUtil;

/**
 * 虹软drm加密
 * 
 * @author ad
 * 
 */
public class ArcChannelDrmSend implements JavaDelegate {
	private Logger logger = LoggerFactory.getLogger(ArcChannelDrmSend.class);

	@Override
	public void execute(DelegateExecution delegateExecution) throws Exception {
		try {
			Map<String,Object> requestDto = buildRequest(delegateExecution);
			String requestJson = JsonUtil.format(requestDto);
			String url = getBaseUrl(delegateExecution.getVariables())
					+ "Encrypt/vodFileRequest";
			String responseJson = HttpUtil.httpPost(url, requestJson,
					HttpUtil.HttpRequestType.JSON);
			HashMap<String, Object> responseMap = JsonUtil.parse(responseJson,
					HashMap.class);
			if (responseMap.containsKey("status")) {
				if ("0".equals(responseMap.get("status").toString())) {
					delegateExecution.setVariable("errcode", 0);
					delegateExecution.setVariable("error_msg", "虹软直播加密任务下发成功");
					delegateExecution.setVariable("taskId",String.valueOf(responseMap.get("taskId")));
					return;
				} else {
					logger.debug("虹软直播加密任务下发返回异常参数：" + responseJson);
					delegateExecution.setVariable("errcode", 1);
					delegateExecution.setVariable("error_msg", "虹软drm加密任务下发异常");
					return;
				}
			} else {
				logger.debug("虹软直播加密任务下发返回异常参数：" + responseJson);
				delegateExecution.setVariable("errcode", 1);
				delegateExecution.setVariable("error_msg", "虹软drm加密任务下发异常");
				return;
			}

		} catch (Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage(), e.fillInStackTrace());
			delegateExecution.setVariable("errcode", 1);
			delegateExecution.setVariable("error_msg", "虹软drm加密任务下发异常");
		}

	}

	public Map<String,Object> buildRequest(DelegateExecution delegateExecution)
			throws Exception {
		try {
			Map<String, Object> variables = delegateExecution.getVariables();
			Map<String,Object> map=new HashMap<>();
			map=(Map<String,Object>)JsonUtil.parse(String.valueOf(variables.get("metadata")), Map.class);
			return map;
		} catch (Exception e) {
			e.printStackTrace();
			throw new AdapterBusinessException();
		}
	}

	public String getBaseUrl(Map<String, Object> variables) throws Exception {
		String baseUrl = "";
		if (variables.containsKey("arcDrmIp")
				&& variables.get("arcDrmIp") != null) {
			baseUrl = String.valueOf(variables.get("arcDrmIp"));
		} else {
			baseUrl = PropertiesUtil.get("arcDrmIp");
		}
		if (StringUtils.isBlank(baseUrl)) {
			throw new AdapterBusinessException("读取drm加密ip异常");
		}
		if (!baseUrl.startsWith("http://")) {
			baseUrl = "http://" + baseUrl;
		}
		if (!baseUrl.endsWith("/")) {
			baseUrl = baseUrl + "/";
		}
		return baseUrl.trim();
	}

}
