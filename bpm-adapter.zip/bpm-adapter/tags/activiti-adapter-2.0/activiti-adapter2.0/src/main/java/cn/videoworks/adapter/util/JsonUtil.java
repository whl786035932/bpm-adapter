package cn.videoworks.adapter.util;

import cn.videoworks.adapter.exception.JsonException;
import com.google.gson.Gson;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Created by caofeiyi on 2014/7/7.
 */
public class JsonUtil {

    private static Logger logger = LoggerFactory.getLogger(JsonUtil.class);

    /**
     * 将对象转为json字符串
     *
     * @param object
     * @return
     * @throws JsonException
     */
    public static String format(Object object) throws JsonException {
        Gson gson = new Gson();
        String json = "";
        try {
            json = gson.toJson(object);
        } catch (Exception e) {
            throw new JsonException("拼装JSON异常", e.fillInStackTrace());
        }
        return json;
    }

    /**
     * 将json字符串转为对象
     *
     * @param json
     * @param clazz
     * @param <T>
     * @return
     * @throws JsonException
     */
    public static <T> T parse(String json, Class<T> clazz) throws JsonException {
        Gson gson = new Gson();
        T object = null;
        try {
            object = gson.fromJson(json, clazz);
        } catch (Exception e) {
        	logger.error("json解析异常，接受字符串为："+json);
            throw new JsonException("解析JSON异常", e.fillInStackTrace());
        }
        return object;
    }
}
