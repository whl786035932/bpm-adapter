package cn.videoworks.adapter.servicetask.dto;

public class MCClusterArcVideoTranscodeSendTaskResponseDto {
	private String taskId;
	private String result;
	private String description;
	public String getTaskId() {
		return taskId;
	}
	public void setTaskId(String taskId) {
		this.taskId = taskId;
	}
	public String getResult() {
		return result;
	}
	public void setResult(String result) {
		this.result = result;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	@Override
	public String toString() {
		return "MCClusterArcVideoTranscodeSendTaskResponseDto [taskId="
				+ taskId + ", result=" + result + ", description="
				+ description + "]";
	}
	
}
