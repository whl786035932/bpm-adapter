package cn.videoworks.adapter.servicetask.supernode;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.activiti.engine.delegate.DelegateExecution;
import org.activiti.engine.delegate.JavaDelegate;
import org.activiti.engine.history.HistoricActivityInstance;
import org.activiti.engine.history.VWHistoricProcessInstance;
import org.activiti.engine.repository.ProcessDefinition;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import cn.videoworks.adapter.exception.AdapterBusinessException;
import cn.videoworks.adapter.exception.HttpException;
import cn.videoworks.adapter.servicetask.dto.EncryptEncryptSendRequestDto;
import cn.videoworks.adapter.servicetask.dto.EncryptEncryptSendResponseDto;
import cn.videoworks.adapter.servicetask.dto.MCClusterArcVideoTranscodeCheckTaskRequestDto;
import cn.videoworks.adapter.servicetask.dto.MCClusterArcVideoTranscodeCheckTaskResponseDto;
import cn.videoworks.adapter.servicetask.dto.MCClusterArcVideoTranscodeSendTaskRequestDto;
import cn.videoworks.adapter.servicetask.dto.MCClusterArcVideoTranscodeSendTaskResponseDto;
import cn.videoworks.adapter.servicetask.dto.MCClusterCheckTaskRequestDto;
import cn.videoworks.adapter.servicetask.dto.MCClusterCheckTaskResponseDto;
import cn.videoworks.adapter.servicetask.dto.MCClusterSendTaskRequestDto;
import cn.videoworks.adapter.servicetask.dto.MCClusterSendTaskResponseDto;
import cn.videoworks.adapter.servicetask.enumeration.MCClusterTaskType;
import cn.videoworks.adapter.util.HttpUtil;
import cn.videoworks.adapter.util.JsonUtil;
import cn.videoworks.adapter.util.PropertiesUtil;

/**
 * 计算集群下发任务模板类 Created by caofeiyi on 2014/7/9.
 */
public abstract class EncryptEncryptSuperCheckTask implements JavaDelegate {

	private Logger logger = LoggerFactory
			.getLogger(EncryptEncryptSuperCheckTask.class);

	DateFormat df = new SimpleDateFormat("yyyyMMddHHmmss");

	public void execute(DelegateExecution delegateExecution) {
		try {
			Map<String, Object> variables = delegateExecution.getVariables();
			String url = getBaseUrl(delegateExecution.getVariables())
					+ "api/task/query?id=" + variables.get("taskId");
			String responseJson = HttpUtil.httpGet(url);
			logger.debug("------------"+responseJson);
			EncryptEncryptSendResponseDto responseDto = JsonUtil.parse(
					responseJson, EncryptEncryptSendResponseDto.class);
			if (responseDto != null && responseDto.getStatusCode() == 200
					&& null != responseDto.getData()) {
				Map map = responseDto.getData();
				Integer status = Integer.parseInt((String) map.get("status"));
				if (status == null) {
					delegateExecution.setVariable("errcode", 1);
					delegateExecution.setVariable("error_msg", "加密任务查询成功:"
							+ responseDto.getMessage());
//					logger.debug("加密任务查询成功!" + "---" + "请求:" + "(id="
//							+ variables.get("taskId") + ")" + "---" + "响应:"
//							+ "(" + responseJson + ")");
				} else {
					if (status == 2) {
						delegateExecution.setVariable("errcode", 0);
						delegateExecution.setVariable("error_msg", "");
//						logger.debug("check加密任务成功!" + "---" + "请求:" + "(id="
//								+ variables.get("taskId") + ")" + "---" + "响应:"
//								+ "(" + responseJson + ")");
					} else if (status == 1 || status == 0) {
						delegateExecution.setVariable("errcode", 2);
						delegateExecution.setVariable("error_msg", "加密任务查询成功:"
								+ responseDto.getMessage());
//						logger.debug("加密任务查询成功!" + "---" + "请求:" + "(id="
//								+ variables.get("taskId") + ")" + "---" + "响应:"
//								+ "(" + responseJson + ")");
					} else {
						delegateExecution.setVariable("errcode", 1);
						delegateExecution.setVariable("error_msg", "加密任务查询成功:"
								+ responseDto.getMessage());
//						logger.debug("加密任务查询成功!" + "---" + "请求:" + "(id="
//								+ variables.get("taskId") + ")" + "---" + "响应:"
//								+ "(" + responseJson + ")");
					}
				}
			} else {
				delegateExecution.setVariable("errcode", 1);
				delegateExecution.setVariable("error_msg", "加密任务查询失败:"
						+ responseDto.getMessage());
//				logger.debug("加密任务查询失败!" + "---" + "请求:" + "(id="
//						+ variables.get("taskId") + ")" + "---" + "响应:" + "("
//						+ responseJson + ")");
			}

		} catch (Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage(), e.fillInStackTrace());
			delegateExecution.setVariable("errcode", 1);
			delegateExecution.setVariable("error_msg", "查询加密任务异常");
		}
	}

	public MCClusterArcVideoTranscodeCheckTaskRequestDto buildRequest(
			DelegateExecution delegateExecution) throws Exception {
		try {
			Map<String, Object> variables = delegateExecution.getVariables();
			MCClusterArcVideoTranscodeCheckTaskRequestDto dto = new MCClusterArcVideoTranscodeCheckTaskRequestDto();
			dto.setTaskId(String.valueOf(variables.get("taskId")));
			return dto;
		} catch (Exception e) {
			e.printStackTrace();
			throw new AdapterBusinessException();
		}
	}

	public String getBaseUrl(Map<String, Object> variables) throws Exception {
		String baseUrl = "";
		if (variables.containsKey("encrypt_ip")
				&& variables.get("encrypt_ip") != null) {
			baseUrl = String.valueOf(variables.get("encrypt_ip"));
		} else {
			baseUrl = PropertiesUtil.get("encrypt.ip");
		}
		if (StringUtils.isBlank(baseUrl)) {
			throw new AdapterBusinessException("读取计算集群URL异常");
		}
		if (!baseUrl.startsWith("http://")) {
			baseUrl = "http://" + baseUrl;
		}
		if (!baseUrl.endsWith("/")) {
			baseUrl = baseUrl + "/";
		}
		return baseUrl;
	}
}
