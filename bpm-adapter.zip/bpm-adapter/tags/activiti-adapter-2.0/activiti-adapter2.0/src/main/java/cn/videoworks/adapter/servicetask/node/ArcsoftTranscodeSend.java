package cn.videoworks.adapter.servicetask.node;

import cn.videoworks.adapter.exception.AdapterBusinessException;
import cn.videoworks.adapter.servicetask.dto.ArcsoftSendTaskRequestDto;
import cn.videoworks.adapter.servicetask.dto.ArcsoftSendTaskResponseDto;
import cn.videoworks.adapter.servicetask.enumeration.ArcsoftTaskStatus;
import cn.videoworks.adapter.util.HttpUtil;
import cn.videoworks.adapter.util.PropertiesUtil;
import cn.videoworks.adapter.util.XmlUtil;
import org.activiti.engine.delegate.DelegateExecution;
import org.activiti.engine.delegate.JavaDelegate;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import java.io.ByteArrayInputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * Created by caofeiyi on 2015/1/13.
 */
public class ArcsoftTranscodeSend implements JavaDelegate {

    private Logger logger = LoggerFactory.getLogger(ArcsoftTranscodeSend.class);

    public void execute(DelegateExecution delegateExecution) throws Exception {
        try {
            ArcsoftSendTaskRequestDto requestDto = buildRequest(delegateExecution);
            String requestXml = XmlUtil.format(requestDto);
            String url = getBaseUrl(delegateExecution.getVariables()) + "/api/task/ext/launch";
            String responseXML = HttpUtil.httpPost(url, requestXml, HttpUtil.HttpRequestType.XML);
            ArcsoftSendTaskResponseDto responseDto = readResponse(responseXML);
            if (responseDto.getErrors() == null || responseDto.getErrors().size() <= 0) {
                delegateExecution.setVariable("currentTaskId", responseDto.getHref());
                delegateExecution.setVariable("errcode", 0);
                delegateExecution.setVariable("error_msg", "计算集群下发任务成功");
                System.out.println("虹软转码下发任务成功!" + "---" + "请求:" + "(" + requestXml + ")" + "---" + "响应:" + "(" + responseXML + ")");
                logger.debug("虹软转码下发任务成功!" + "---" + "请求:" + "(" + requestXml + ")" + "---" + "响应:" + "(" + responseXML + ")");
            } else {
                delegateExecution.setVariable("errcode", 1);
                delegateExecution.setVariable("error_msg", "计算集群下发任务失败:" + responseDto.getErrors().toString());
                System.out.println("虹软转码下发任务失败!" + "---" + "请求:" + "(" + requestXml + ")" + "---" + "响应:" + "(" + responseXML + ")");
                logger.debug("虹软转码下发任务失败!" + "---" + "请求:" + "(" + requestXml + ")" + "---" + "响应:" + "(" + responseXML + ")");
            }
        } catch (Exception e) {
            e.printStackTrace();
            logger.error(e.getMessage(), e.fillInStackTrace());
            delegateExecution.setVariable("errcode", 1);
            delegateExecution.setVariable("error_msg", "虹软转码下发任务异常");
        }
    }

    public ArcsoftSendTaskRequestDto buildRequest(DelegateExecution delegateExecution) throws Exception {
        try {
            Map<String, Object> variables = delegateExecution.getVariables();
            ArcsoftSendTaskRequestDto dto = new ArcsoftSendTaskRequestDto();
            String input = variables.get("input").toString();
            String output = variables.get("output").toString();
            String template = variables.get("template").toString();
            String name = PropertiesUtil.get("taskName.prefix") + "_" + delegateExecution.getProcessInstanceId();
            dto.setName(name);
            dto.setInputFile(new ArcsoftSendTaskRequestDto.InputFile(input));
            dto.setOutputFile(new ArcsoftSendTaskRequestDto.OutputFile(output));
            dto.setProfile(new ArcsoftSendTaskRequestDto.Profile(template));
            dto.setPriority(10);
            dto.setEncodingoption("Balance");
            return dto;
        } catch (Exception e) {
            e.printStackTrace();
            throw new AdapterBusinessException();
        }
    }

    public ArcsoftSendTaskResponseDto readResponse(String responseXML) throws Exception {
        ArcsoftSendTaskResponseDto responseDto = new ArcsoftSendTaskResponseDto();
        DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
        DocumentBuilder builder = factory.newDocumentBuilder();
        Document doc = builder.parse(new ByteArrayInputStream(responseXML.getBytes()));
        Element root = doc.getDocumentElement();
        String rootName = root.getTagName();
        if ("task".equals(rootName)) {
            String href = root.getAttributes().getNamedItem("href").getNodeValue();
            responseDto.setHref(href);
            for (Node node = root.getFirstChild(); node != null; node = node.getNextSibling()) {
                if (node.getNodeType() == Node.ELEMENT_NODE) {
                    if (node.getNodeName().equals("status")) {
                        String name = node.getFirstChild().getNodeValue();
                        switch (name.toUpperCase()) {
                            case "COMPLETED":
                                responseDto.setStatus(ArcsoftTaskStatus.COMPLETED);
                                break;
                            case "CANCELLED":
                                responseDto.setStatus(ArcsoftTaskStatus.CANCELLED);
                                break;
                            case "ERROR":
                                responseDto.setStatus(ArcsoftTaskStatus.ERROR);
                                break;
                            case "PENDING":
                                responseDto.setStatus(ArcsoftTaskStatus.PENDING);
                                break;
                            case "RUNNING":
                                responseDto.setStatus(ArcsoftTaskStatus.RUNNING);
                                break;
                            default:
                                break;
                        }
                    }
                }
            }
        }
        if ("errors".equals(rootName)) {
            List<String> errors = new ArrayList<String>();
            for (Node node = root.getFirstChild(); node != null; node = node.getNextSibling()) {
                if (node.getNodeType() == Node.ELEMENT_NODE) {
                    if (node.getNodeName().equals("error")) {
                        String error = node.getFirstChild().getNodeValue();
                        errors.add(error);
                    }
                }
            }
            responseDto.setErrors(errors);
        }
        return responseDto;
    }

    public String getBaseUrl(Map<String, Object> variables) throws Exception {
        String baseUrl = "";
        baseUrl = PropertiesUtil.get("arcsoft.ip");
        if (StringUtils.isBlank(baseUrl)) {
            throw new AdapterBusinessException("读取虹软URL异常");
        }
        if (!baseUrl.startsWith("http://")) {
            baseUrl = "http://" + baseUrl;
        }
        return baseUrl;
    }
}