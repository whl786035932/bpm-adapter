package cn.videoworks.adapter.temp;

import java.util.Date;
import java.util.Set;

/**
 * 角色权限实体类.
 *
 * @author LuoChuan
 * @version 1.0.0
 * @since 1.0.0
 */
public class Authorization {

	/** 权限ID. */
	private int id;

	/** 权限名称. */
	private String name;

	/** 权限内容. */
	private String content;

	/** 权限描述. */
	private String description;

	/** 权限生效时间. */
	private Date effectiveDate;

	/** 权限失效时间. */
	private Date expireDate;

	/** 权限对应角色列表. */
	private Set<Role> roles;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Date getEffectiveDate() {
		return effectiveDate;
	}

	public void setEffectiveDate(Date effectiveDate) {
		this.effectiveDate = effectiveDate;
	}

	public Date getExpireDate() {
		return expireDate;
	}

	public void setExpireDate(Date expireDate) {
		this.expireDate = expireDate;
	}

	public Set<Role> getRoles() {
		return roles;
	}

	public void setRoles(Set<Role> roles) {
		this.roles = roles;
	}
}
