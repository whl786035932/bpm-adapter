package cn.videoworks.adapter.servicetask.node;

import cn.videoworks.adapter.servicetask.enumeration.ApplicationActualTaskType;
import cn.videoworks.adapter.servicetask.supernode.ApplicationSuperActualTask;

/**
 * Created by caofeiyi on 2015/3/31.
 */
public class MAMProcessCountActual extends ApplicationSuperActualTask {
    public ApplicationActualTaskType getType() throws Exception {
        return ApplicationActualTaskType.mamProcessCount;
    }
}
