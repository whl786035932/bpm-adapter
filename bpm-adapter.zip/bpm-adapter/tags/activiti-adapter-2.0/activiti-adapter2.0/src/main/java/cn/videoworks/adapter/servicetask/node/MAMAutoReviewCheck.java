package cn.videoworks.adapter.servicetask.node;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;



import org.activiti.engine.delegate.DelegateExecution;
import org.activiti.engine.delegate.JavaDelegate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;



import cn.videoworks.adapter.exception.AdapterBusinessException;
import cn.videoworks.adapter.servicetask.dto.ApplicationActualTaskRequestDto;
import cn.videoworks.adapter.servicetask.dto.ApplicationActualTaskResponseDto;
import cn.videoworks.adapter.servicetask.enumeration.ApplicationActualTaskResult;
import cn.videoworks.adapter.servicetask.enumeration.ApplicationActualTaskType;
import cn.videoworks.adapter.servicetask.supernode.ApplicationSuperActualTask;
import cn.videoworks.adapter.servicetask.supernode.ArcVideoTranscodeSuperSendTask;
import cn.videoworks.adapter.util.HttpUtil;
import cn.videoworks.adapter.util.JsonUtil;
import cn.videoworks.adapter.util.PropertiesUtil;

/**
 * Created by zyj on 2015/10/29.
 */
public class MAMAutoReviewCheck  implements JavaDelegate /*extends ApplicationSuperActualTask */{
	private Logger logger = LoggerFactory
			.getLogger(MAMAutoReviewCheck.class);
	
	 public void execute(DelegateExecution delegateExecution) {
	        try {
	            ApplicationActualTaskRequestDto requestDto = buildRequest(delegateExecution);
	            String requestJson = JsonUtil.format(requestDto);
	            String url = "http://" + PropertiesUtil.get("application.ip") + "/workflowAutoTask/" + getType().name();
	            String responseJson = HttpUtil.httpPost(url, requestJson, HttpUtil.HttpRequestType.JSON);
	            ApplicationActualTaskResponseDto responseDto = JsonUtil.parse(responseJson, ApplicationActualTaskResponseDto.class);
	            if (responseDto.getStatusCode() == 200) {
	                if (responseDto.getData().getResult() == ApplicationActualTaskResult.SUCCESS) {
	                    Map<String, String> variables = setVariables(responseDto);
	                    if (variables != null) {
	                        delegateExecution.setVariables(variables);
	                    }
	                    delegateExecution.setVariable("errcode", 0);
	                    delegateExecution.setVariable("error_msg", "任务成功");
	                    logger.debug("任务成功!" + "---" + "请求:" + "(" + requestJson + ")" + "---" + "响应:" + "(" + responseJson + ")");
	                } else {
	                    delegateExecution.setVariable("errcode", 2);
	                   logger.debug("任务尚在进行中");
	                }
	            } else {
	            	delegateExecution.setVariable("errcode", 1);
                    delegateExecution.setVariable("error_msg", "任务失败:" + responseDto.getData().getResultMessage());
                    logger.debug("任务失败!" + "---" + "请求:" + "(" + requestJson + ")" + "---" + "响应:" + "(" + responseJson + ")");
	            }
	        } catch (Exception e) {
	            logger.error(e.getMessage(), e.fillInStackTrace());
	            delegateExecution.setVariable("errcode", 1);
	            delegateExecution.setVariable("error_msg", "任务异常");
	        }
	    }

	    public ApplicationActualTaskType getType() throws Exception{
	    	return ApplicationActualTaskType.mamAutoReviewCheck;
	    }

	    public ApplicationActualTaskRequestDto buildRequest(DelegateExecution delegateExecution) throws Exception {
	        ApplicationActualTaskRequestDto dto = new ApplicationActualTaskRequestDto();
	        dto.setId(delegateExecution.getProcessInstanceId());
	        dto.setData(delegateExecution.getVariables());
	        return dto;
	    }

	    public Map<String, String> setVariables(ApplicationActualTaskResponseDto responseDto) throws Exception {
	        return responseDto.getData().getData();
	    }
	
//	public void execute(DelegateExecution delegateExecution) {
//		try {
//			System.out.println("任务查询开始");
//			String taskId=String.valueOf(delegateExecution.getVariables().get("taskId"));
//			BatonProxy client=new BatonProxy("10.2.17.215", 8080, "admin", "admin");
//			TasksProxy tasksProxy=client.Tasks;
//			List<String> statics=tasksProxy.status(taskId);
//			String staticString="";
//			if(statics!=null&&statics.size()>0){
//				staticString =statics.get(0);
//			}
//			if("".equals(staticString)){
//				delegateExecution.setVariable("errcode", 1);
//				delegateExecution.setVariable("error_msg", "计审任务失败");
//				System.out.println("计审任务失败");
//				return;
//			}
//			if("Finished".equals(staticString)){
//				
//				String report=tasksProxy.report(taskId);
//				JSON objJson = new XMLSerializer().read(report);
//				delegateExecution.setVariable("out_examineinfo", objJson.toString());
//				delegateExecution.setVariable("errcode", 0);
//				delegateExecution.setVariable("error_msg", "计审任务成功");	
//	            System.out.println("JSON data : " + objJson.toString());
//	            System.out.println("计审任务成功ByZyj");
//				return;
//			}else if("Aborted".equals(staticString)||"Cancelled".equals(staticString)){
//				delegateExecution.setVariable("errcode", 1);
//				delegateExecution.setVariable("error_msg", "计审任务失败，失败原因是由于任务取消或者任务终止【"+staticString+"】");
//				System.out.println("计审任务失败");
//				return;
//			}else{
//				delegateExecution.setVariable("errcode", 2);
//				System.out.println("机身任务进行中");
//			}
//			
//			
//		} catch (Exception e) {
//			e.printStackTrace();
//			logger.error(e.getMessage(), e.fillInStackTrace());
//			delegateExecution.setVariable("errcode", 1);
//			delegateExecution.setVariable("error_msg", "计审任务异常");
//		}
//	}
//	
//	
//	
//	public static void main(String[]args) {
//		try {
//			System.out.println("程序开始执行，请稍后");
//			BatonProxy client=new BatonProxy("10.2.17.215", 8080, "admin", "admin");
//			TasksProxy tasksProxy=client.Tasks;
//			System.out.println(client.edition());
//			System.out.println(tasksProxy.numAllTasks());
//			String url="\\\\10.2.17.215\\Media\\CCTVEN_1500000_20150817_14632195_0.ts";
//			System.out.println(url);
//			String taskId=tasksProxy.verifyFile("Audio Test Plan", "", "High", url, new ArrayList<String>());
//			System.out.println("taskId:"+taskId);
//		} catch (Exception e) {
//			e.printStackTrace();
//			System.out.println("任务出错");
//		}
//	}
//	
//	
//	public ApplicationActualTaskRequestDto buildRequest(DelegateExecution delegateExecution) throws Exception {
//        ApplicationActualTaskRequestDto dto = new ApplicationActualTaskRequestDto();
//        dto.setId(delegateExecution.getProcessInstanceId());
//        dto.setData(delegateExecution.getVariables());
//        return dto;
//    }
//
//    public Map<String, String> setVariables(ApplicationActualTaskResponseDto responseDto) throws Exception {
//        return responseDto.getData().getData();
//    }
}
