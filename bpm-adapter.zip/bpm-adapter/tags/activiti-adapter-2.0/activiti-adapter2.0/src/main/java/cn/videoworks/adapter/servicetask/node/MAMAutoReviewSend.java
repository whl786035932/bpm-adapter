package cn.videoworks.adapter.servicetask.node;


import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import cn.videoworks.adapter.servicetask.enumeration.ApplicationActualTaskType;
import cn.videoworks.adapter.servicetask.supernode.ApplicationSuperActualTask;


/**
 * Created by caofeiyi on 2015/1/20.
 */
public class MAMAutoReviewSend  /*implements JavaDelegate */extends ApplicationSuperActualTask {
	private Logger logger = LoggerFactory
			.getLogger(MAMAutoReviewSend.class);
	  public ApplicationActualTaskType getType() throws Exception {
	        return ApplicationActualTaskType.mamAutoReviewSend;
	    }
//	public void execute(DelegateExecution delegateExecution) {
//		try {
//			Map<String,Object> map=delegateExecution.getVariables();
//			BatonProxy client=new BatonProxy("10.2.17.215", 8080, "admin", "admin");
//			TasksProxy tasksProxy=client.Tasks;
//			String url=String.valueOf(map.get("video_url"));
//			if(url==null||"".equals(url)||"null".equals(url)){
//				logger.error("计审视频路径有误");
//				delegateExecution.setVariable("errcode", 1);
//				delegateExecution.setVariable("error_msg", "下发计审任务异常");
//				return;
//			}
//			String template=String.valueOf(map.get("template"));
//			if(template==null||"".equals(template)||"null".equals(template)){
//				template="Audio Test Plan";
//			}
//			String templateId=String.valueOf(map.get("templateId"));
//			if(templateId==null||"null".equals(templateId)){
//				templateId="";
//			}
//			String priority=String.valueOf(map.get("priority"));
//			if(priority==null||"".equals(priority)||"null".equals(priority)){
//				priority="Normal";
//			}
//			String taskId=tasksProxy.verifyFile(template, templateId, priority, url, new ArrayList<String>());
//			delegateExecution.setVariable("taskId", taskId);
//			delegateExecution.setVariable("errcode", 0);
//			System.out.println("任务执行成功:"+taskId);
//			logger.debug("计审任务下发成功，该任务id为:"+taskId);
//		} catch (Exception e) {
//			e.printStackTrace();
//			logger.error(e.getMessage(), e.fillInStackTrace());
//			delegateExecution.setVariable("errcode", 1);
//			delegateExecution.setVariable("error_msg", "下发计审任务异常");
//		}
//	}

}
