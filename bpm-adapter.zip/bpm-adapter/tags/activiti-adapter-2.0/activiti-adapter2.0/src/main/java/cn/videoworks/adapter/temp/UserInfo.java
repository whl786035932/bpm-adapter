package cn.videoworks.adapter.temp;

import java.util.Set;

/**
 * 用户信息实体类.
 * 
 * @author LuoChuan
 * @version 1.0.0
 * @since 1.0.0
 */
public class UserInfo {

	/** 用户ID. */
	private String id;

	/** 是否启用 */
	private boolean enable = true;

	/** 是否同步 */
	private boolean upload = false;

	/** 用于drm同步用户返回的accountId */
	private Long accountId;

	/** 用于判断是否订购了drm的商品 */
	private boolean drmOrder = false;

	/** 用户所属分组列表. */
	private Set<GroupInfo> groups;

	/** 用户所属角色列表. */
	private Set<Role> roles;

	/** 对应LDAP中具体用户信息. */
	private LdapUser ldapUser;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public Set<GroupInfo> getGroups() {
		return groups;
	}

	public void setGroups(Set<GroupInfo> groups) {
		this.groups = groups;
	}

	public Set<Role> getRoles() {
		return roles;
	}

	public void setRoles(Set<Role> roles) {
		this.roles = roles;
	}

	public LdapUser getLdapUser() {
		return ldapUser;
	}

	public void setLdapUser(LdapUser ldapUser) {
		this.ldapUser = ldapUser;
	}

	public boolean isEnable() {
		return enable;
	}

	public void setEnable(boolean enable) {
		this.enable = enable;
	}

	/**
	 * @return the upload
	 */
	public boolean isUpload() {
		return upload;
	}

	/**
	 * @param upload
	 *            the upload to set
	 */
	public void setUpload(boolean upload) {
		this.upload = upload;
	}

	/**
	 * @return the accountId
	 */
	public Long getAccountId() {
		return accountId;
	}

	/**
	 * @param accountId
	 *            the accountId to set
	 */
	public void setAccountId(Long accountId) {
		this.accountId = accountId;
	}

	/**
	 * @return the drmOrder
	 */
	public boolean isDrmOrder() {
		return drmOrder;
	}

	/**
	 * @param drmOrder
	 *            the drmOrder to set
	 */
	public void setDrmOrder(boolean drmOrder) {
		this.drmOrder = drmOrder;
	}

}
