package cn.videoworks.adapter.servicetask.node;

import cn.videoworks.adapter.servicetask.enumeration.MCClusterTaskType;
import cn.videoworks.adapter.servicetask.supernode.MCClusterSuperSendTask;
import cn.videoworks.adapter.util.JsonUtil;

import java.util.*;
import java.util.Map.Entry;

public class MCClusterDeleteFileSend extends MCClusterSuperSendTask {

    public Map<String, Object> getParam(Map<String, Object> variables) throws Exception {
        Map<String, Object> paramMap = new HashMap<String, Object>();
        Iterator<Entry<String, Object>> iter = variables.entrySet().iterator();
        paramMap.put("path", "");
        paramMap.put("files", new LinkedList<String>());
        while (iter.hasNext()) {
            Map.Entry entry = (Map.Entry) iter.next();
            String key = (String) entry.getKey();
            Object val = entry.getValue();
            if (key.equals("path")) {
                String path = ((String) val).trim();
                paramMap.put("path", path);
            }
            if (key.equals("file")) {
                String file = ((String) val).trim();
                List<String> files = new LinkedList<String>();
                files.add(file);
                paramMap.put("files", files);

            }
            if (key.equals("files")) {
                String filesJson = ((String) val).trim();
                List<String> files = JsonUtil.parse(filesJson, LinkedList.class);
                paramMap.put("files", files);
            }
        }

        if (paramMap.containsKey("path") && paramMap.containsKey("files")) {
            return paramMap;
        } else {
            return null;
        }
    }

    public List<String> getTemplate(Map<String, Object> variables) throws Exception {
        return new LinkedList<String>();
    }

    public MCClusterTaskType getType() throws Exception {
        return MCClusterTaskType.DeleteFile;
    }

}