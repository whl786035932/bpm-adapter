package cn.videoworks.adapter.servicetask.dto;

import java.util.Map;

/**
 * Created by caofeiyi on 2014/7/7.
 */
public class EncryptEncryptSendResponseDto {
	private Map<String,Object> data;
	private Map<String,Object> body;
	private Map<String,Object> header;
    private int statusCode;
    private String message;

    
    public Map<String, Object> getBody() {
		return body;
	}

	public void setBody(Map<String, Object> body) {
		this.body = body;
	}

	public Map<String, Object> getHeader() {
		return header;
	}

	public void setHeader(Map<String, Object> header) {
		this.header = header;
	}

	public int getStatusCode() {
		return statusCode;
	}

	public void setStatusCode(int statusCode) {
		this.statusCode = statusCode;
	}

	public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

	public Map<String, Object> getData() {
		return data;
	}

	public void setData(Map<String, Object> data) {
		this.data = data;
	}
    
}
