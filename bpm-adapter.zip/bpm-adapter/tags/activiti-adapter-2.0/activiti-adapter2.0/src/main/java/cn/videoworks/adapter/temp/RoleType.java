package cn.videoworks.adapter.temp;


/**
 * 权限类型实体类.
 *
 * @author LuoChuan
 * @version 1.0.0
 * @since 1.0.0
 */
public class RoleType {

	/** 权限类型ID. */
	private int id;

	/** 权限类型名称. */
	private String name;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
}
