package cn.videoworks.adapter.servicetask.node;

import cn.videoworks.adapter.servicetask.enumeration.MCClusterTaskType;
import cn.videoworks.adapter.servicetask.supernode.MCClusterSuperSendTask;
import cn.videoworks.adapter.util.JsonUtil;

import java.util.*;
import java.util.Map.Entry;

public class MCClusterTranscodeSend extends MCClusterSuperSendTask {

    public Map<String, Object> getParam(Map<String, Object> variables) throws Exception {
        Map<String, Object> paramMap = new HashMap<String, Object>();
        List<Map<String, Object>> input = new LinkedList<Map<String, Object>>();
        List<Map<String, Object>> output = new LinkedList<Map<String, Object>>();
        Iterator<Entry<String, Object>> iter = variables.entrySet().iterator();
        Map<String, Object> inputEntity = new HashMap<String, Object>();
        String inputfile = (String) variables.get("source");
        List<String> templates = new LinkedList<String>();
        List<String> targets = new LinkedList<String>();
        while (iter.hasNext()) {
            Map.Entry entry = (Map.Entry) iter.next();
            String key = (String) entry.getKey();
            Object val = entry.getValue();
            if (key.equals("source")) {
                inputEntity.put("filename", val);
                input.add(inputEntity);
                paramMap.put("input", input);
            } else if (key.equals("cutpoints")) {
                if (val == null) continue;
                inputEntity.put("times", getCutPoints(val.toString()));
                inputEntity.put("frame_index_file", inputfile
                        + "?mode=DATABASE&field=FRAME_INDEX");
            } else if (key.equals("template")) {
                templates = JsonUtil.parse((String) val, List.class);
            } else if (key.equals("target")) {
                targets = JsonUtil.parse((String) val, List.class);
            }
        }
        if (templates.size() != targets.size()) {
            return null;
        }
        int i = 0;
        for (String template : templates) {
            Map<String, Object> outputEntity = new HashMap<String, Object>();
            outputEntity.put("template", template);
            outputEntity.put("filename", targets.get(i));
            output.add(outputEntity);
            i++;
        }
        paramMap.put("output", output);
        if (paramMap.containsKey("input") && paramMap.containsKey("output")) {
            return paramMap;
        } else {
            return null;
        }
    }

    private List<Map<String, Object>> getCutPoints(String val) throws Exception {
        List<Map<String, Object>> cutpoints = JsonUtil.parse(val, List.class);
        for (Map<String, Object> cutpoint : cutpoints) {
            Object value1 = cutpoint.remove("in_point");
            cutpoint.put("start_time", value1);
            Object value2 = cutpoint.remove("out_point");
            cutpoint.put("end_time", value2);
        }
        return cutpoints;
    }

    public List<String> getTemplate(Map<String, Object> variables) throws Exception {
        List<String> templates = new LinkedList<String>();
        if (variables.containsKey("template")) {
            templates = JsonUtil.parse((String) variables.get("template"), List.class);
        }
        return templates;
    }

    public MCClusterTaskType getType() throws Exception {
        return MCClusterTaskType.Transcode;
    }

}