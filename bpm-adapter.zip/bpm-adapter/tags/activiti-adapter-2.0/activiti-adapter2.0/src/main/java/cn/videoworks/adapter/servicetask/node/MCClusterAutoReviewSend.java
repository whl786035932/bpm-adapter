package cn.videoworks.adapter.servicetask.node;

import cn.videoworks.adapter.servicetask.enumeration.MCClusterTaskType;
import cn.videoworks.adapter.servicetask.supernode.MCClusterSuperSendTask;

import java.util.*;
import java.util.Map.Entry;

public class MCClusterAutoReviewSend extends MCClusterSuperSendTask {

    public Map<String, Object> getParam(Map<String, Object> variables) throws Exception {
        Map<String, Object> paramMap = new HashMap<String, Object>();
        Iterator<Entry<String, Object>> iter = variables.entrySet().iterator();
        while (iter.hasNext()) {
            Map.Entry entry = (Map.Entry) iter.next();
            String key = (String) entry.getKey();
            Object val = entry.getValue();
            if (key.equals("video_url")) {
                paramMap.put("input", val.toString());
            } else if (key.equals("template")) {
                paramMap.put("template", val.toString());
            }
        }
        if (paramMap.containsKey("input") && paramMap.containsKey("template")) {
            return paramMap;
        } else {
            return null;
        }
    }

    public List<String> getTemplate(Map<String, Object> variables) throws Exception {
        List<String> list = new LinkedList<String>();
        String template = (String) variables.get("template");
        if (template == null) return list;
        list.add(template);
        return list;
    }

    public MCClusterTaskType getType() throws Exception {
        return MCClusterTaskType.AutoReview;
    }

}