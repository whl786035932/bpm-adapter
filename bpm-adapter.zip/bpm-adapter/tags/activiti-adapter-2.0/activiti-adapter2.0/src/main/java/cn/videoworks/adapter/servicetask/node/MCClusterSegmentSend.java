package cn.videoworks.adapter.servicetask.node;

import cn.videoworks.adapter.servicetask.enumeration.MCClusterTaskType;
import cn.videoworks.adapter.servicetask.supernode.MCClusterSuperSendTask;

import java.util.*;
import java.util.Map.Entry;

public class MCClusterSegmentSend extends MCClusterSuperSendTask {

    public Map<String, Object> getParam(Map<String, Object> variables) throws Exception {
        Map<String, Object> paramMap = new HashMap<String, Object>();
        Iterator<Entry<String, Object>> iter = variables.entrySet().iterator();
        String format = "";
        String filename = "";
        Map<String, Object> outputMap = new HashMap<String, Object>();
        while (iter.hasNext()) {
            Map.Entry entry = (Map.Entry) iter.next();
            String key = (String) entry.getKey();
            Object val = entry.getValue();
            if (key.equals("video_url")) {
                filename = val.toString().trim();
                String[] segs = filename.split("\\.");
                if (segs.length <= 1) {
                    break;
                } else format = "." + segs[segs.length - 1];
                paramMap.put("input", filename);
                outputMap.put("segment_format", format);
                paramMap.put("output", outputMap);
            } else if (key.equals("segment_time")) {
                outputMap.put("segment_time", Long.parseLong(val.toString()));
            } else if (key.equals("type")) {
                String type = val.toString();
                outputMap.put("type", type);
            } else if (key.equals("m3u8_url")) {
                outputMap.put("filename", val.toString());
            }
        }
        if (paramMap.containsKey("input") && paramMap.containsKey("output")) {
            return paramMap;
        } else {
            return null;
        }
    }

    public List<String> getTemplate(Map<String, Object> variables) throws Exception {
        return new LinkedList<String>();
    }

    public MCClusterTaskType getType() throws Exception {
        return MCClusterTaskType.Segment;
    }

}