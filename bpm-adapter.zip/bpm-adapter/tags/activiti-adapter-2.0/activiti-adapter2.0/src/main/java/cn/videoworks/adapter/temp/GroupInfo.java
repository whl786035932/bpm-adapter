package cn.videoworks.adapter.temp;


/**
 * 用户组实体类.
 *
 * @author LuoChuan
 * @version 1.0.0
 * @since 1.0.0
 */
public class GroupInfo {

	/** 分组ID. */
	private int id;

	/** 分组名称. */
	private String name;

	/** 分组类别. */
	private GroupType category;

	/** 父级分组. */
	private GroupInfo parent;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public GroupType getCategory() {
		return category;
	}

	public void setCategory(GroupType category) {
		this.category = category;
	}

	public GroupInfo getParent() {
		return parent;
	}

	public void setParent(GroupInfo parent) {
		this.parent = parent;
	}
}
