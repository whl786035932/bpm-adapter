package cn.videoworks.adapter.servicetask.supernode;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.activiti.engine.delegate.DelegateExecution;
import org.activiti.engine.delegate.JavaDelegate;
import org.activiti.engine.history.HistoricActivityInstance;
import org.activiti.engine.history.VWHistoricProcessInstance;
import org.activiti.engine.repository.ProcessDefinition;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import cn.videoworks.adapter.exception.AdapterBusinessException;
import cn.videoworks.adapter.exception.HttpException;
import cn.videoworks.adapter.servicetask.dto.MCClusterArcVideoTranscodeSendTaskRequestDto;
import cn.videoworks.adapter.servicetask.dto.MCClusterArcVideoTranscodeSendTaskResponseDto;
import cn.videoworks.adapter.servicetask.dto.MCClusterCheckTaskRequestDto;
import cn.videoworks.adapter.servicetask.dto.MCClusterCheckTaskResponseDto;
import cn.videoworks.adapter.servicetask.dto.MCClusterSendTaskRequestDto;
import cn.videoworks.adapter.servicetask.dto.MCClusterSendTaskResponseDto;
import cn.videoworks.adapter.servicetask.enumeration.MCClusterTaskType;
import cn.videoworks.adapter.util.HttpUtil;
import cn.videoworks.adapter.util.JsonUtil;
import cn.videoworks.adapter.util.PropertiesUtil;
import cn.videoworks.commons.util.json.JsonConverter;

/**
 * 计算集群下发任务模板类 Created by caofeiyi on 2014/7/9.
 */
public abstract class ArcVideoTranscodeSuperSendTask implements JavaDelegate {

	private Logger logger = LoggerFactory
			.getLogger(ArcVideoTranscodeSuperSendTask.class);

	DateFormat df = new SimpleDateFormat("yyyyMMddHHmmss");

	public void execute(DelegateExecution delegateExecution) {
		try {
			logger.debug("开始适配器访问媒资任务");
			MCClusterArcVideoTranscodeSendTaskRequestDto requestDto = buildRequest(delegateExecution);
			String requestJson = JsonUtil.format(requestDto);
			String url = getBaseUrl(delegateExecution.getVariables())+ "api/json/task/launch".trim();
			String responseJson = HttpUtil.httpPost(url, requestJson,
					HttpUtil.HttpRequestType.JSON);
			logger.debug("转码返回参数结果："+responseJson);
			System.out.println("转码返回参数结果："+responseJson);
			MCClusterArcVideoTranscodeSendTaskResponseDto responseDto = JsonUtil.parse(
					responseJson, MCClusterArcVideoTranscodeSendTaskResponseDto.class);
			if ("SUCCESS".equals(responseDto.getResult())) {
				delegateExecution.setVariable("taskId",responseDto.getTaskId());
				delegateExecution.setVariable("errcode", 0);
				delegateExecution.setVariable("error_msg", "下发转码任务成功");
				logger.debug("下发转码任务成功!" + "---" + "请求:" + "(" + requestJson
						+ ")" + "---" + "响应:" + "(" + responseJson + ")");
			} else {
				delegateExecution.setVariable("errcode", 1);
				delegateExecution.setVariable("error_msg", "下发转码任务失败:"+ responseDto.getDescription());
				logger.debug("下发转码任务失败!" + "---" + "请求:" + "(" + requestJson
						+ ")" + "---" + "响应:" + "(" + responseJson + ")");
			}

		} catch (Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage(), e.fillInStackTrace());
			delegateExecution.setVariable("errcode", 1);
			delegateExecution.setVariable("error_msg", "下发转码任务异常");
		}
	}

	public MCClusterArcVideoTranscodeSendTaskRequestDto buildRequest(
			DelegateExecution delegateExecution) throws Exception {
		try {
			Map<String, Object> variables = delegateExecution.getVariables();
			MCClusterArcVideoTranscodeSendTaskRequestDto dto = new MCClusterArcVideoTranscodeSendTaskRequestDto();
			dto.setTaskName(String.valueOf(variables.get("taskName")));
			dto.setTaskPriority(String.valueOf(variables.get("taskPriority")));
			List<String> templateIds=JsonConverter.asList(String.valueOf(variables.get("taskTemplateId")), String.class);
			String templateId="";
			if(templateIds!=null&&templateIds.size()>0){
				templateId=templateIds.get(0);
			}
			dto.setTaskTemplateId(templateId);
			String sourceString=String.valueOf(variables.get("source"));
			List<String> listSource=new ArrayList<String>();
			listSource.add(sourceString);
			dto.setTaskInputUris(listSource);
			
			List<String> targetList=new ArrayList<String>();
			targetList.add(String.valueOf(variables.get("target")));
			dto.setTaskOutputUri(targetList);
			if(variables.containsKey("taskReportUrl")&&!"".equals(String.valueOf(variables.get("taskReportUrl")))
					&&!"null".equals(String.valueOf(variables.get("taskReportUrl")))
					&&String.valueOf(variables.get("taskReportUrl"))!=null){
				dto.setTaskReportUrl(String.valueOf(variables.get("taskReportUrl")));
			}
			dto.setTaskReportUrl(null);
			
			return dto;
		} catch (Exception e) {
			e.printStackTrace();
			throw new AdapterBusinessException();
		}
	}


	public String getBaseUrl(Map<String, Object> variables) throws Exception {
		String baseUrl = "";
		if (variables.containsKey("arcvideo_ip")
				&& variables.get("arcvideo_ip") != null) {
			baseUrl = String.valueOf(variables.get("arcvideo_ip"));
		} else {
			baseUrl = PropertiesUtil.get("arcvideoTranscode");
		}
		if (StringUtils.isBlank(baseUrl)) {
			throw new AdapterBusinessException("读取计算集群URL异常");
		}
		if (!baseUrl.startsWith("http://")) {
			baseUrl = "http://" + baseUrl;
		}
		if (!baseUrl.endsWith("/")) {
			baseUrl = baseUrl + "/";
		}
		return baseUrl.trim();
	}
}
