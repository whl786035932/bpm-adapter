package cn.videoworks.adapter.servicetask.supernode;

import cn.videoworks.adapter.exception.AdapterBusinessException;
import cn.videoworks.adapter.exception.HttpException;
import cn.videoworks.adapter.servicetask.dto.PublisherCheckTaskRequestDto;
import cn.videoworks.adapter.servicetask.dto.PublisherCheckTaskResponseDto;
import cn.videoworks.adapter.servicetask.dto.PublisherCheckTaskResponseTaskDto;
import cn.videoworks.adapter.util.HttpUtil;
import cn.videoworks.adapter.util.JsonUtil;
import cn.videoworks.adapter.util.PropertiesUtil;

import org.activiti.engine.delegate.DelegateExecution;
import org.activiti.engine.delegate.JavaDelegate;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Map;

public abstract class PublisherSuperCheckTask implements JavaDelegate {

    private Logger logger = LoggerFactory.getLogger(PublisherSuperCheckTask.class);

    public void execute(DelegateExecution delegateExecution) {
        try {
            PublisherCheckTaskRequestDto requestDto = buildRequest(delegateExecution.getVariables());
            String requestJson = JsonUtil.format(requestDto);
            String url = getBaseUrl(delegateExecution.getVariables()) + "task/list";
            String responseJson = HttpUtil.httpPost(url, requestJson, HttpUtil.HttpRequestType.JSON);
            PublisherCheckTaskResponseDto responseDto = JsonUtil.parse(responseJson, PublisherCheckTaskResponseDto.class);
            if (responseDto.getStatusCode() == 200) {
                if (responseDto.getData().getTaskList().get(0).getStatus() == 2) {
                    Map<String, Object> variables = setVariables(responseDto.getData().getTaskList().get(0));
                    if (variables != null) {
                        delegateExecution.setVariables(variables);
                    }
                    delegateExecution.setVariable("errcode", 0);
                    delegateExecution.setVariable("error_msg", "发布系统任务成功");
                    logger.debug("发布系统任务成功!" + "---" + "请求:" + "(" + requestJson + ")" + "---" + "响应:" + "(" + responseJson + ")");
                } else if (responseDto.getData().getTaskList().get(0).getStatus() == -1 || responseDto.getData().getTaskList().get(0).getStatus() == -2) {
                    delegateExecution.setVariable("errcode", 1);
                    delegateExecution.setVariable("error_msg", "发布系统任务失败:" + responseDto.getData().getTaskList().get(0).getMessage());
                    logger.debug("发布系统任务失败!" + "---" + "请求:" + "(" + requestJson + ")" + "---" + "响应:" + "(" + responseJson + ")");
                } else {
                    delegateExecution.setVariable("errcode", 2);
                }
            } else {
                throw new AdapterBusinessException("请求异常");
            }
        } catch (HttpException e) {
            logger.error(e.getMessage(), e.fillInStackTrace());
            delegateExecution.setVariable("errcode", 2);
        } catch (Exception e) {
            logger.error(e.getMessage(), e.fillInStackTrace());
            delegateExecution.setVariable("errcode", 1);
            delegateExecution.setVariable("error_msg", "发布系统任务异常");
        }
    }

    public PublisherCheckTaskRequestDto buildRequest(Map<String, Object> variables) throws Exception {
        PublisherCheckTaskRequestDto dto = new PublisherCheckTaskRequestDto();
        dto.setTaskId(String.valueOf(variables.get("currentTaskId")));
        return dto;
    }

    public abstract Map<String, Object> setVariables(PublisherCheckTaskResponseTaskDto responseTaskDto) throws Exception;

    public String getBaseUrl(Map<String, Object> variables) throws Exception {
        String baseUrl = "";
        if (variables.containsKey("publisher_ip") && variables.get("publisher_ip") != null) {
            baseUrl = String.valueOf(variables.get("publisher_ip"));
            if (!baseUrl.endsWith("/")) {
                baseUrl = baseUrl + "/";
            }
            baseUrl = baseUrl + "publish/ws";
        } else {
        	if(variables.containsKey("template") ) {
        		try {
        			baseUrl=PropertiesUtil.get(variables.get("template")+".ip");
				} catch (Exception e) {
					logger.debug("未配置【"+variables.get("template")+".ip】,下发发布任务至【"+PropertiesUtil.get("publisher.ip")+"】");
					baseUrl = PropertiesUtil.get("publisher.ip");
				}
        	}else {
        		baseUrl = PropertiesUtil.get("publisher.ip");
        	}
        }
        if (StringUtils.isBlank(baseUrl)) {
            throw new AdapterBusinessException("读取发布系统URL异常");
        }
        if (!baseUrl.startsWith("http://")) {
            baseUrl = "http://" + baseUrl;
        }
        if (!baseUrl.endsWith("/")) {
            baseUrl = baseUrl + "/";
        }
        return baseUrl;
    }
}
