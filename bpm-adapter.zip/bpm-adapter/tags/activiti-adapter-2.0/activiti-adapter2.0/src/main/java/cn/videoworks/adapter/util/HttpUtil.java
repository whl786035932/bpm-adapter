package cn.videoworks.adapter.util;

import cn.videoworks.adapter.exception.HttpException;
import cn.videoworks.adapter.servicetask.entity.MyHttpDelete;

import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.methods.HttpPut;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.params.CoreConnectionPNames;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by caofeiyi on 2014/7/7.
 */
public class HttpUtil {

    private static Logger logger = LoggerFactory.getLogger(HttpUtil.class);

    /**
     * 发送GET请求
     *
     * @param url
     * @return
     * @throws HttpException
     */
    public static String httpGet(String url) throws HttpException {
        try {
            HttpClient httpClient = new DefaultHttpClient();
            int timeout=10*1000;
            try {
            	timeout=new Integer(PropertiesUtil.get("timeout.time")).intValue()*1000;
			} catch (Exception e) {
				timeout=10*1000;
			}
            httpClient.getParams().setParameter(CoreConnectionPNames.CONNECTION_TIMEOUT,timeout);
            httpClient.getParams().setParameter(CoreConnectionPNames.SO_TIMEOUT,timeout);
            HttpGet getRequest = new HttpGet(url);
            HttpResponse response = httpClient.execute(getRequest);
            InputStream is = response.getEntity().getContent();
            BufferedReader in = new BufferedReader(new InputStreamReader(is));
            StringBuffer buffer = new StringBuffer();
            String line = "";
            while ((line = in.readLine()) != null) {
                buffer.append(line);
            }
            return buffer.toString();
        } catch (Exception e) {
        	e.printStackTrace();
            throw new HttpException("网络连接异常", e.fillInStackTrace());
        }
    }

    /**
     * 发送POST请求
     *
     * @param url
     * @param request
     * @return
     * @throws HttpException
     */
    public static String httpPost(String url, String request, HttpRequestType httpRequestType) throws HttpException {
        try {
            HttpClient httpClient = new DefaultHttpClient();
            int timeout=10*1000;
            try {
            	timeout=new Integer(PropertiesUtil.get("timeout.time")).intValue()*1000;
			} catch (Exception e) {
				timeout=10*1000;
			}
            httpClient.getParams().setParameter(CoreConnectionPNames.CONNECTION_TIMEOUT,timeout);
            httpClient.getParams().setParameter(CoreConnectionPNames.SO_TIMEOUT,timeout);
            HttpPost postRequest = new HttpPost(url);
            StringEntity input = new StringEntity(request, "UTF-8");
            if (httpRequestType == HttpRequestType.JSON) {
                input.setContentType("application/json;charset=UTF-8");
            } else if (httpRequestType == HttpRequestType.XML) {
                input.setContentType("text/xml; charset=UTF-8");
            }
            postRequest.setEntity(input);
            HttpResponse response = httpClient.execute(postRequest);
            InputStream is = response.getEntity().getContent();
            BufferedReader in = new BufferedReader(new InputStreamReader(is));
            StringBuffer buffer = new StringBuffer();
            String line = "";
            while ((line = in.readLine()) != null) {
                buffer.append(line);
            }
            return buffer.toString();
        } catch (Exception e) {
            throw new HttpException("网络连接异常", e.fillInStackTrace());
        }
    }

    /**
     * 发送PUT请求
     *
     * @param url
     * @param request
     * @return
     * @throws HttpException
     */
    public static String httpPut(String url, String request, HttpRequestType httpRequestType) throws HttpException {
        try {
        	HttpClient httpClient = new DefaultHttpClient();
            int timeout=10*1000;
            try {
            	timeout=new Integer(PropertiesUtil.get("timeout.time")).intValue()*1000;
			} catch (Exception e) {
				timeout=10*1000;
			}
            httpClient.getParams().setParameter(CoreConnectionPNames.CONNECTION_TIMEOUT,timeout);
            httpClient.getParams().setParameter(CoreConnectionPNames.SO_TIMEOUT,timeout);
            HttpPut putRequest = new HttpPut(url);
            StringEntity input = new StringEntity(request, "UTF-8");
            if (httpRequestType == HttpRequestType.JSON) {
                input.setContentType("application/json;charset=UTF-8");
            } else if (httpRequestType == HttpRequestType.XML) {
                input.setContentType("text/xml; charset=UTF-8");
            }
            putRequest.setEntity(input);
            HttpResponse response = httpClient.execute(putRequest);
            InputStream is = response.getEntity().getContent();
            BufferedReader in = new BufferedReader(new InputStreamReader(is));
            StringBuffer buffer = new StringBuffer();
            String line = "";
            while ((line = in.readLine()) != null) {
                buffer.append(line);
            }
            return buffer.toString();
        } catch (Exception e) {
            throw new HttpException("网络连接异常", e.fillInStackTrace());
        }
    }
    /**
     * 发送delete请求
     * @param url
     * @param request
     * @return
     * @throws HttpException
     */
    public static String httpDelete(String url, List<NameValuePair> request) throws HttpException {
        try {
        	HttpClient httpClient = new DefaultHttpClient(); 
        	int timeout=10*1000;
            try {
            	timeout=new Integer(PropertiesUtil.get("timeout.time")).intValue()*1000;
			} catch (Exception e) {
				timeout=10*1000;
			}
            httpClient.getParams().setParameter(CoreConnectionPNames.CONNECTION_TIMEOUT,timeout);
            httpClient.getParams().setParameter(CoreConnectionPNames.SO_TIMEOUT,timeout);

        	MyHttpDelete delete = new MyHttpDelete(url); 

        	List<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>(); 

        	delete.setEntity(new UrlEncodedFormEntity(nameValuePairs)); 

        	HttpResponse response = httpClient.execute(delete);
            InputStream is = response.getEntity().getContent();
            BufferedReader in = new BufferedReader(new InputStreamReader(is));
            StringBuffer buffer = new StringBuffer();
            String line = "";
            while ((line = in.readLine()) != null) {
                buffer.append(line);
            }
            return buffer.toString();
        } catch (Exception e) {
            throw new HttpException("网络连接异常", e.fillInStackTrace());
        }
    }

    public enum HttpRequestType {
        XML,
        JSON
    }
}
