package cn.videoworks.adapter.servicetask.dto;

public class ArcDrmSendRequestDto {
	//内容标式id
	private String contentId;
	//需加密文件名称
	private String fileName;
	//需加密文件路径
	private String filePath;
	//加密文件输出路径
	private String outputPath;
	//状态回调url地址
	private String callBackUrl;
	public String getContentId() {
		return contentId;
	}
	public void setContentId(String contentId) {
		this.contentId = contentId;
	}
	public String getFileName() {
		return fileName;
	}
	public void setFileName(String fileName) {
		this.fileName = fileName;
	}
	public String getFilePath() {
		return filePath;
	}
	public void setFilePath(String filePath) {
		this.filePath = filePath;
	}
	public String getOutputPath() {
		return outputPath;
	}
	public void setOutputPath(String outputPath) {
		this.outputPath = outputPath;
	}
	public String getCallBackUrl() {
		return callBackUrl;
	}
	public void setCallBackUrl(String callBackUrl) {
		this.callBackUrl = callBackUrl;
	}
	
	
}
