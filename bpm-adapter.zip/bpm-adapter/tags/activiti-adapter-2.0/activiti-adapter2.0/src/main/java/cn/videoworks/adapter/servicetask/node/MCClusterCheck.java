package cn.videoworks.adapter.servicetask.node;

import cn.videoworks.adapter.exception.AdapterBusinessException;
import cn.videoworks.adapter.exception.HttpException;
import cn.videoworks.adapter.servicetask.dto.MCClusterCheckTaskRequestDto;
import cn.videoworks.adapter.servicetask.dto.MCClusterCheckTaskResponseDto;
import cn.videoworks.adapter.servicetask.supernode.MCClusterSuperCheck;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.HashMap;
import java.util.Map;

public class MCClusterCheck extends MCClusterSuperCheck {

    private Logger logger = LoggerFactory.getLogger(MCClusterCheck.class);

    public MCClusterCheckTaskRequestDto buildRequest(Map<String, Object> variables) throws Exception {
        MCClusterCheckTaskRequestDto requestDto = new MCClusterCheckTaskRequestDto();
        requestDto.setId(String.valueOf(variables.get("taskId")));
        return requestDto;
    }

    public Map<String, Object> setVariables(MCClusterCheckTaskResponseDto responseDto, String requestJson, String responseJson) throws Exception {
        Map<String, Object> variables = new HashMap<String, Object>();
        if (responseDto.getData() == null || responseDto.getData().size() <= 0) {
            throw new AdapterBusinessException("未找到任务");
        }
        variables.put("taskStatus", responseDto.getData().get(0).getStatus().name());
        variables.put("errcode", 0);
        return variables;
    }

    public Map<String, Object> setErrorVariables(Exception exception) {
        Map<String, Object> variables = new HashMap<String, Object>();
        if (exception instanceof HttpException) {
            logger.error(exception.getMessage(), exception.fillInStackTrace());
            variables.put("errcode", 2);
        } else {
            logger.error(exception.getMessage(), exception.fillInStackTrace());
            variables.put("taskStatus", "");
            variables.put("errcode", 0);
        }
        return variables;
    }
}
