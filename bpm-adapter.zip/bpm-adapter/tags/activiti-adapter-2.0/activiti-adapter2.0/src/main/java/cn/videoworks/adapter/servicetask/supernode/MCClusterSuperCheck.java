package cn.videoworks.adapter.servicetask.supernode;

import cn.videoworks.adapter.exception.AdapterBusinessException;
import cn.videoworks.adapter.servicetask.dto.MCClusterCheckTaskRequestDto;
import cn.videoworks.adapter.servicetask.dto.MCClusterCheckTaskResponseDto;
import cn.videoworks.adapter.util.HttpUtil;
import cn.videoworks.adapter.util.JsonUtil;
import cn.videoworks.adapter.util.PropertiesUtil;
import org.activiti.engine.delegate.DelegateExecution;
import org.activiti.engine.delegate.JavaDelegate;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Map;

/**
 * 计算集群查询任务模板类
 * Created by caofeiyi on 2014/8/19.
 */
public abstract class MCClusterSuperCheck implements JavaDelegate {

    private Logger logger = LoggerFactory.getLogger(MCClusterSuperCheck.class);

    public void execute(DelegateExecution delegateExecution) {
        try {
            MCClusterCheckTaskRequestDto requestDto = buildRequest(delegateExecution.getVariables());
            String requestJson = JsonUtil.format(requestDto);
            String url = getBaseUrl(delegateExecution.getVariables()) + "task/status/";
            String responseJson = HttpUtil.httpPost(url, requestJson, HttpUtil.HttpRequestType.JSON);
            MCClusterCheckTaskResponseDto responseDto = JsonUtil.parse(responseJson, MCClusterCheckTaskResponseDto.class);
            Map<String, Object> variables = setVariables(responseDto, requestJson, responseJson);
            if (variables != null) {
                delegateExecution.setVariables(variables);
            }
        } catch (Exception exception) {
            Map<String, Object> variables = setErrorVariables(exception);
            if (variables != null) {
                delegateExecution.setVariables(variables);
            }
        }
    }

    public abstract MCClusterCheckTaskRequestDto buildRequest(Map<String, Object> variables) throws Exception;

    public abstract Map<String, Object> setVariables(MCClusterCheckTaskResponseDto responseDto, String requestJson, String responseJson) throws Exception;

    public abstract Map<String, Object> setErrorVariables(Exception exception);

    public String getBaseUrl(Map<String, Object> variables) throws Exception {
        String baseUrl = "";
        if (variables.containsKey("mccluster_ip") && variables.get("mccluster_ip") != null) {
            baseUrl = String.valueOf(variables.get("mccluster_ip"));
        } else {
            baseUrl = PropertiesUtil.get("mccluster.ip");
        }
        if (StringUtils.isBlank(baseUrl)) {
            throw new AdapterBusinessException("读取计算集群URL异常");
        }
        if (!baseUrl.startsWith("http://")) {
            baseUrl = "http://" + baseUrl;
        }
        if (!baseUrl.endsWith("/")) {
            baseUrl = baseUrl + "/";
        }
        return baseUrl;
    }
}
