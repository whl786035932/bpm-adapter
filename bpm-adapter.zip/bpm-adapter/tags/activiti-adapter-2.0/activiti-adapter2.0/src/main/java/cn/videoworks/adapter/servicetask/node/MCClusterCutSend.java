package cn.videoworks.adapter.servicetask.node;

import cn.videoworks.adapter.servicetask.enumeration.MCClusterTaskType;
import cn.videoworks.adapter.servicetask.supernode.MCClusterSuperSendTask;
import cn.videoworks.adapter.util.JsonUtil;

import java.util.*;
import java.util.Map.Entry;

public class MCClusterCutSend extends MCClusterSuperSendTask {

    public Map<String, Object> getParam(Map<String, Object> variables) throws Exception {
        Map<String, Object> paramMap = new HashMap<String, Object>();
        Iterator<Entry<String, Object>> iter = variables.entrySet().iterator();
        while (iter.hasNext()) {
            Map.Entry entry = (Map.Entry) iter.next();
            String key = (String) entry.getKey();
            Object val = entry.getValue();
            if (key.equals("cutInput")) {
                String cutInput = (String) val;
                List<Map<String, Object>> list = JsonUtil.parse(
                        cutInput, LinkedList.class);
                for (Map<String, Object> temp : list) {
                    List<Map<String, Object>> cutFrames = JsonUtil.parse(String.valueOf(temp.get("cutFrames")), LinkedList.class);
                    List<Map<String, Object>> cutpoints = getCutPoint(cutFrames);
                    temp.remove("cutFrames");
                    temp.put("cutpoints", cutpoints);
                }
                paramMap.put("input", list);
            } else if (key.equals("out_video_url")) {
                String output = (String) val;
                paramMap.put("output", output);
            } else if (key.equals("template")) {
                String template = (String) val;
                paramMap.put("template", template);
            }
        }
        if (paramMap.containsKey("input") && paramMap.containsKey("template")
                && paramMap.containsKey("output")) {
            return paramMap;
        } else {
            return null;
        }
    }


    public List<String> getTemplate(Map<String, Object> variables) throws Exception {
        List<String> list = new LinkedList<String>();
        String template = (String) variables.get("template");
        if (template == null) return list;
        list.add(template);
        return list;
    }

    public MCClusterTaskType getType() throws Exception {
        return MCClusterTaskType.Cut;
    }

    private List<Map<String, Object>> getCutPoint(List<Map<String, Object>> list) throws Exception {
    	
    	List<Map<String, Object>> cutpoints = new LinkedList<Map<String, Object>>();
    	if(list==null){// add by zy 20160323  cut worker 支持没有切点的情况了
    		return cutpoints;
    	}
        if (list.size() % 2 != 0) return null;
        int length = list.size() / 2;
        for (int i = 0; i < length; i++) {
            Map<String, Object> map = new HashMap<String, Object>();
            Number num1 = (Number) list.get(2 * i).get("frame");
            Object endFrameObj = list.get(2 * i + 1).get("frame");
//            Number num2 = (Number) list.get(2 * i + 1).get("frame");
            long startFrame = num1.longValue();
            long endFrame;
            if(endFrameObj!=null){
            	Number num2 = (Number) list.get(2 * i + 1).get("frame");
            	endFrame = num2.longValue();
            	if (startFrame >= endFrame) return null;
            	map.put("end_frame", endFrame);
            	
            }
            map.put("start_frame", startFrame);
            cutpoints.add(map);
        }
        return cutpoints;
    }

}