package cn.videoworks.adapter.servicetask.node;

import cn.videoworks.adapter.exception.JsonException;
import cn.videoworks.adapter.servicetask.enumeration.MCClusterTaskType;
import cn.videoworks.adapter.servicetask.supernode.MCClusterSuperSendTask;
import cn.videoworks.adapter.util.JsonUtil;
import cn.videoworks.commons.util.json.JsonConverter;

import java.util.*;
import java.util.Map.Entry;

public class MCClusterImageSend extends MCClusterSuperSendTask {

    public Map<String, Object> getParam(Map<String, Object> variables) throws Exception {
        String imageFramesStr = variables.get("image_frames").toString();
//        String imageCutRegionStr = variables.get("image_cut_region").toString();
        List<Map<String, Object>> imageFrames = JsonUtil.parse(imageFramesStr, List.class);
        
        Map<String, Object> paramMap = new HashMap<String, Object>();
        Iterator<Entry<String, Object>> iter = variables.entrySet().iterator();
        while (iter.hasNext()) {
            Map.Entry entry = (Map.Entry) iter.next();
            String key = (String) entry.getKey();
            Object val = entry.getValue();
            if (key.equals("video_url")) {
                paramMap.put("input", (String) val);
            } else if (key.equals("output")) {
                List<Map<String, Object>> output = JsonUtil.parse((String) val, List.class);
                for (Map<String, Object> entity : output) {
                	Map<String,Object> timeParam = JsonConverter.parse(entity.get("time").toString(),HashMap.class);
                	//modify by zy 20160302 当entity.get("time").toString()中有属性为空时报错
//                	Map<String,Object> timeParam = (Map<String,Object>)entity.get("time");
                	Map<String,Object> imageCutRegionMap = new HashMap<>();
                    if(timeParam.get("region")==null){
                    	imageCutRegionMap.put("left", 0);
                    	imageCutRegionMap.put("top", 0);
                    	imageCutRegionMap.put("width", 1);
                    	imageCutRegionMap.put("height", 1);
                    }else{
                    	imageCutRegionMap = JsonConverter.parse(timeParam.get("region").toString(),HashMap.class);
                    }
                    entity.put("cutregion", imageCutRegionMap);
                    entity.put("size", timeParam.get("size")!=null?timeParam.get("size").toString():"");
                    entity.put("time",timeParam.get("time"));
                    String filename = (String) entity.remove("output");
                    entity.put("filename", filename);
//                    String time = entity.get("time").toString();
                    for (Map<String, Object> frame : imageFrames) {
                        String timeInImageFrames = frame.get("time").toString();
                        if (timeInImageFrames.equals(String.valueOf(timeParam.get("time")))) {
                            entity.put("frame", frame.get("frame"));
                            break;
                        }
                    }
                }
                paramMap.put("output", output);
            }
        }
        if (paramMap.containsKey("input") || paramMap.containsKey("output")) {
            return paramMap;
        } else {
            return null;
        }
    }

    public List<String> getTemplate(Map<String, Object> variables) throws Exception {
        return new LinkedList<String>();
    }

    public MCClusterTaskType getType() throws Exception {
        return MCClusterTaskType.Image;
    }

}