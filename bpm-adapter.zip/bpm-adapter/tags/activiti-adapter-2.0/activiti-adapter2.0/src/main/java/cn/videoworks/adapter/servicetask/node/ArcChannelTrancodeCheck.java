package cn.videoworks.adapter.servicetask.node;

import java.util.HashMap;
import java.util.Map;

import org.activiti.engine.delegate.DelegateExecution;
import org.activiti.engine.delegate.JavaDelegate;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import cn.videoworks.adapter.exception.AdapterBusinessException;
import cn.videoworks.adapter.servicetask.dto.ArcDrmCheckRequestDto;
import cn.videoworks.adapter.servicetask.dto.ArcDrmSendRequestDto;
import cn.videoworks.adapter.servicetask.dto.MCClusterArcVideoTranscodeCheckTaskRequestDto;
import cn.videoworks.adapter.servicetask.dto.MCClusterArcVideoTranscodeSendTaskRequestDto;
import cn.videoworks.adapter.util.HttpUtil;
import cn.videoworks.adapter.util.JsonUtil;
import cn.videoworks.adapter.util.PropertiesUtil;
/**
 * 虹软直播转码 
 * @author ad
 *
 */
public class ArcChannelTrancodeCheck implements JavaDelegate{
	private Logger logger = LoggerFactory.getLogger(ArcChannelTrancodeCheck.class);
	@Override
	public void execute(DelegateExecution delegateExecution) throws Exception {
		try {
			MCClusterArcVideoTranscodeCheckTaskRequestDto requestDto=buildRequest(delegateExecution);
			String requestJson=JsonUtil.format(requestDto);
			String url=getBaseUrl(delegateExecution.getVariables())+ "Encrypt/getEncryptStatus";
			String responseJson = HttpUtil.httpPost(url, requestJson, HttpUtil.HttpRequestType.JSON);
			HashMap<String,Object> responseMap=JsonUtil.parse(responseJson, HashMap.class);
			if(!responseMap.containsKey("status")){
				logger.debug("响应参数错误:"+responseJson);
				delegateExecution.setVariable("errcode", 1);
		        delegateExecution.setVariable("error_msg", "虹软直播转码失败");
		        return;
			}else{
				String status=String.valueOf(responseMap.get("status"));
				if("0".equals(status)){//转码完成
					delegateExecution.setVariable("errcode", 0);
			        delegateExecution.setVariable("error_msg", "虹软直播转码完成");
			        return;
				}else if("1".equals(status)){//错误
					delegateExecution.setVariable("errcode", 1);
			        delegateExecution.setVariable("error_msg", "虹软直播转码失败");
			        return;
				}else if("2".equals(status)){//转码中
					delegateExecution.setVariable("errcode", 2);
			        delegateExecution.setVariable("error_msg", "虹软直播转码进行中");
			        return;
				}else{
					logger.debug("响应参数错误（状态错误）:"+responseJson);
					delegateExecution.setVariable("errcode", 1);
					delegateExecution.setVariable("error_msg", "加密返回参数错误");
					return;
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
            logger.error(e.getMessage(), e.fillInStackTrace());
            delegateExecution.setVariable("errcode", 1);
            delegateExecution.setVariable("error_msg", "虹软drm加密任务查询异常");
		}
		
	}
	public MCClusterArcVideoTranscodeCheckTaskRequestDto buildRequest(DelegateExecution delegateExecution) throws Exception {
		try {
			Map<String, Object> variables = delegateExecution.getVariables();
			MCClusterArcVideoTranscodeCheckTaskRequestDto dto=new MCClusterArcVideoTranscodeCheckTaskRequestDto();
			dto.setTaskId(String.valueOf(variables.get("taskId")));
			return dto;
		} catch (Exception e) {
			e.printStackTrace();
			throw new AdapterBusinessException();
		}
	}
	public String getBaseUrl(Map<String, Object> variables) throws Exception {
		String baseUrl = "";
		if (variables.containsKey("arcDrmIp")
				&& variables.get("arcDrmIp") != null) {
			baseUrl = String.valueOf(variables.get("arcDrmIp"));
		} else {
			baseUrl = PropertiesUtil.get("arcDrmIp");
		}
		if (StringUtils.isBlank(baseUrl)) {
			throw new AdapterBusinessException("读取drm加密ip异常");
		}
		if (!baseUrl.startsWith("http://")) {
			baseUrl = "http://" + baseUrl;
		}
		if (!baseUrl.endsWith("/")) {
			baseUrl = baseUrl + "/";
		}
		return baseUrl.trim();
	}

}
