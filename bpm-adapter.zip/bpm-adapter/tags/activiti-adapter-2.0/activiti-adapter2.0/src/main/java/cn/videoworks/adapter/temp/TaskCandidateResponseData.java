package cn.videoworks.adapter.temp;


public class TaskCandidateResponseData {
	private String userInfos;

	public String getUserInfos() {
		return userInfos;
	}

	public void setUserInfos(String userInfos) {
		this.userInfos = userInfos;
	}

}
