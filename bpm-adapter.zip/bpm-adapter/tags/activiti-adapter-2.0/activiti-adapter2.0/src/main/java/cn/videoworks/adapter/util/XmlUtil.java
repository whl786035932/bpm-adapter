package cn.videoworks.adapter.util;

import cn.videoworks.adapter.exception.XmlException;
import com.thoughtworks.xstream.XStream;

import org.apache.log4j.chainsaw.Main;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Created by caofeiyi on 2015/1/12.
 */
public class XmlUtil {

    private static Logger logger = LoggerFactory.getLogger(XmlUtil.class);

    /**
     * 将对象转为xml字符串
     *
     * @param object
     * @return
     * @throws XmlException
     */
    public static String format(Object object) throws XmlException {
        XStream xStream = new XStream();
        xStream.processAnnotations(object.getClass());//应用类的注解
        xStream.autodetectAnnotations(true);//自动检测注解
        String xml = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>";
        try {
            xml = xml + xStream.toXML(object);
        } catch (Exception e) {
            throw new XmlException("拼装XML异常", e.fillInStackTrace());
        }
        return xml;
    }

    /**
     * 将xml字符串转为对象
     *
     * @param xml
     * @param clazz
     * @param <T>
     * @return
     * @throws XmlException
     */
    public static <T> T parse(String xml, Class<T> clazz) throws XmlException {
        XStream xStream = new XStream();
        xStream.processAnnotations(clazz);//应用类的注解
        xStream.autodetectAnnotations(true);//自动检测注解
        T object = null;
        try {
            object = (T) xStream.fromXML(xml);
        } catch (Exception e) {
            e.printStackTrace();
            throw new XmlException("解析XML异常", e.fillInStackTrace());
        }
        return object;
    }
}
