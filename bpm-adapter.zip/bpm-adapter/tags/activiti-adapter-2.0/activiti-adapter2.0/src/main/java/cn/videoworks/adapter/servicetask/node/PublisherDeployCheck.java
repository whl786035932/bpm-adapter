package cn.videoworks.adapter.servicetask.node;

import cn.videoworks.adapter.servicetask.dto.PublisherCheckTaskResponseTaskDto;
import cn.videoworks.adapter.servicetask.supernode.PublisherSuperCheckTask;
import cn.videoworks.adapter.util.JsonUtil;
import org.apache.commons.lang3.StringUtils;

import java.util.Map;

public class PublisherDeployCheck extends PublisherSuperCheckTask {

    public Map<String, Object> setVariables(PublisherCheckTaskResponseTaskDto responseTaskDto) throws Exception {
        if (StringUtils.isNotBlank(responseTaskDto.getReturnValue())) {
            return JsonUtil.parse(responseTaskDto.getReturnValue(), Map.class);
        }
        return null;
    }
}
