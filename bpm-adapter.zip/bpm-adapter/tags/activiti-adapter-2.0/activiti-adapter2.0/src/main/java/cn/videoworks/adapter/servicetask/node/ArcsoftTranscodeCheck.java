package cn.videoworks.adapter.servicetask.node;

import cn.videoworks.adapter.exception.AdapterBusinessException;
import cn.videoworks.adapter.exception.HttpException;
import cn.videoworks.adapter.servicetask.dto.ArcsoftSendTaskResponseDto;
import cn.videoworks.adapter.servicetask.enumeration.ArcsoftTaskStatus;
import cn.videoworks.adapter.util.HttpUtil;
import cn.videoworks.adapter.util.PropertiesUtil;
import org.activiti.engine.delegate.DelegateExecution;
import org.activiti.engine.delegate.JavaDelegate;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import java.io.ByteArrayInputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * Created by caofeiyi on 2015/1/13.
 */
public class ArcsoftTranscodeCheck implements JavaDelegate {

    private Logger logger = LoggerFactory.getLogger(ArcsoftTranscodeCheck.class);

    public void execute(DelegateExecution delegateExecution) {
        try {
            String url = getBaseUrl(delegateExecution.getVariables()) + delegateExecution.getVariables().get("currentTaskId");
            String responseXML = HttpUtil.httpGet(url);
            ArcsoftSendTaskResponseDto responseDto = readResponse(responseXML);
            if (responseDto.getErrors() == null || responseDto.getErrors().size() <= 0) {
                if (responseDto.getStatus() == ArcsoftTaskStatus.COMPLETED) {
                    delegateExecution.setVariable("errcode", 0);
                    delegateExecution.setVariable("error_msg", "虹软转码任务成功");
                    System.out.println("虹软转码任务成功!" + "---" + "请求:" + "(" + url + ")" + "---" + "响应:" + "(" + responseXML + ")");
                    logger.debug("虹软转码任务成功!" + "---" + "请求:" + "(" + url + ")" + "---" + "响应:" + "(" + responseXML + ")");
                } else if (responseDto.getStatus() == ArcsoftTaskStatus.ERROR || responseDto.getStatus() == ArcsoftTaskStatus.CANCELLED) {
                    delegateExecution.setVariable("errcode", 1);
                    delegateExecution.setVariable("error_msg", "虹软转码任务失败");
                    System.out.println("虹软转码任务失败!" + "---" + "请求:" + "(" + url + ")" + "---" + "响应:" + "(" + responseXML + ")");
                    logger.debug("虹软转码任务失败!" + "---" + "请求:" + "(" + url + ")" + "---" + "响应:" + "(" + responseXML + ")");
                } else {
                    delegateExecution.setVariable("errcode", 2);
                }
            } else {
                delegateExecution.setVariable("errcode", 1);
                delegateExecution.setVariable("error_msg", "虹软转码任务异常:" + responseDto.getErrors().toString());
                System.out.println("虹软转码任务异常!" + "---" + "请求:" + "(" + url + ")" + "---" + "响应:" + "(" + responseXML + ")");
            }
        } catch (HttpException e) {
            e.printStackTrace();
            logger.error(e.getMessage(), e.fillInStackTrace());
            delegateExecution.setVariable("errcode", 2);
        } catch (Exception e) {
            e.printStackTrace();
            logger.error(e.getMessage(), e.fillInStackTrace());
            delegateExecution.setVariable("errcode", 1);
            delegateExecution.setVariable("error_msg", "虹软转码任务异常");
        }
    }

    public ArcsoftSendTaskResponseDto readResponse(String responseXML) throws Exception {
        ArcsoftSendTaskResponseDto responseDto = new ArcsoftSendTaskResponseDto();
        DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
        DocumentBuilder builder = factory.newDocumentBuilder();
        Document doc = builder.parse(new ByteArrayInputStream(responseXML.getBytes()));
        Element root = doc.getDocumentElement();
        String rootName = root.getTagName();
        if ("task".equals(rootName)) {
            String href = root.getAttributes().getNamedItem("href").getNodeValue();
            responseDto.setHref(href);
            for (Node node = root.getFirstChild(); node != null; node = node.getNextSibling()) {
                if (node.getNodeType() == Node.ELEMENT_NODE) {
                    if (node.getNodeName().equals("status")) {
                        String name = node.getFirstChild().getNodeValue();
                        switch (name.toUpperCase()) {
                            case "COMPLETED":
                                responseDto.setStatus(ArcsoftTaskStatus.COMPLETED);
                                break;
                            case "CANCELLED":
                                responseDto.setStatus(ArcsoftTaskStatus.CANCELLED);
                                break;
                            case "ERROR":
                                responseDto.setStatus(ArcsoftTaskStatus.ERROR);
                                break;
                            case "PENDING":
                                responseDto.setStatus(ArcsoftTaskStatus.PENDING);
                                break;
                            case "RUNNING":
                                responseDto.setStatus(ArcsoftTaskStatus.RUNNING);
                                break;
                            default:
                                break;
                        }
                    }
                }
            }
        }
        if ("errors".equals(rootName)) {
            List<String> errors = new ArrayList<String>();
            for (Node node = root.getFirstChild(); node != null; node = node.getNextSibling()) {
                if (node.getNodeType() == Node.ELEMENT_NODE) {
                    if (node.getNodeName().equals("error")) {
                        String error = node.getFirstChild().getNodeValue();
                        errors.add(error);
                    }
                }
            }
            responseDto.setErrors(errors);
        }
        return responseDto;
    }

    public String getBaseUrl(Map<String, Object> variables) throws Exception {
        String baseUrl = "";
        baseUrl = PropertiesUtil.get("arcsoft.ip");
        if (StringUtils.isBlank(baseUrl)) {
            throw new AdapterBusinessException("读取虹软URL异常");
        }
        if (!baseUrl.startsWith("http://")) {
            baseUrl = "http://" + baseUrl;
        }
        return baseUrl;
    }
}
