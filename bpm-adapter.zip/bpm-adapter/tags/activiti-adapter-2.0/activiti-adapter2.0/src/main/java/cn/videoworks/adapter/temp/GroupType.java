package cn.videoworks.adapter.temp;


/**
 * 分组类别.
 *
 * @author LuoChuan
 * @version 1.0.0
 * @since 1.0.0
 */
public class GroupType {

	/** 分组ID. */
	private int id;

	/** 分组名称. */
	private String name;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
}
