package cn.videoworks.adapter.servicetask.node;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.activiti.engine.delegate.DelegateExecution;
import org.activiti.engine.delegate.JavaDelegate;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import cn.videoworks.adapter.exception.AdapterBusinessException;
import cn.videoworks.adapter.util.HttpUtil;
import cn.videoworks.adapter.util.JsonUtil;
import cn.videoworks.adapter.util.PropertiesUtil;

/**
 * 媒资同步下游（频道删除）
 * @author ad
 *
 */
public class SynchronizationDeleteChannel implements JavaDelegate {
	private Logger logger = LoggerFactory.getLogger(SynchronizationDeleteMediaAsset.class);

	@Override
	public void execute(DelegateExecution delegateExecution) throws Exception {
		try {
			Map<String,Object> requestDto = buildRequest(delegateExecution);
			String requestJson = JsonUtil.format(requestDto);
			String url = getBaseUrl(delegateExecution.getVariables())
					+ "com.sdtv.sdp.media.cmp.epgsync";
			String responseJson = HttpUtil.httpPost(url, requestJson,
					HttpUtil.HttpRequestType.JSON);
			HashMap<String, Object> responseMap = JsonUtil.parse(responseJson,
					HashMap.class);
			if (responseMap.containsKey("statusCode")) {
				if ("200".equals(responseMap.get("statusCode").toString())) {
					delegateExecution.setVariable("errcode", 0);
					delegateExecution.setVariable("error_msg", "媒资同步下游（频道删除）成功");
					return;
				}else if("500".equals(responseMap.get("statusCode").toString())){
					logger.debug("媒资同步下游（频道删除）任务失败：" + responseJson);
					delegateExecution.setVariable("errcode", 1);
					delegateExecution.setVariable("error_msg", "媒资同步下游（频道删除）任务失败");
					return;
				} else {
					logger.debug("媒资同步下游（频道删除）返回参数有误：" + responseJson);
					delegateExecution.setVariable("errcode", 1);
					delegateExecution.setVariable("error_msg", "媒资同步下游（频道删除）返回参数有误");
					return;
				}
			} else {
				logger.debug("媒资同步下游（频道删除）异常：" + responseJson);
				delegateExecution.setVariable("errcode", 1);
				delegateExecution.setVariable("error_msg", "媒资同步下游（频道删除）异常");
				return;
			}

		} catch (Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage(), e.fillInStackTrace());
			delegateExecution.setVariable("errcode", 1);
			delegateExecution.setVariable("error_msg", "媒资同步下游（频道删除）异常");
		}

	}

	public Map<String,Object> buildRequest(DelegateExecution delegateExecution)
			throws Exception {
		try {
			Map<String, Object> variables = delegateExecution.getVariables();
			Map<String,Object> map=new HashMap<>();
			String mamId=String.valueOf(variables.get("mamId"));
			List<String> channelIds=new ArrayList<>();
			channelIds.add(mamId);
			map.put("channelIds", channelIds);
			return map;
		} catch (Exception e) {
			e.printStackTrace();
			throw new AdapterBusinessException();
		}
	}

	public String getBaseUrl(Map<String, Object> variables) throws Exception {
		String baseUrl = "";
		if (variables.containsKey("ip")
				&& variables.get("ip") != null) {
			baseUrl = String.valueOf(variables.get("ip"));
		} else {
			baseUrl = PropertiesUtil.get("SynchronizationDeleteChannel.ip");
		}
		if (StringUtils.isBlank(baseUrl)) {
			throw new AdapterBusinessException("读取媒资同步下游频道删除ip异常");
		}
		if (!baseUrl.startsWith("http://")) {
			baseUrl = "http://" + baseUrl;
		}
		if (!baseUrl.endsWith("/")) {
			baseUrl = baseUrl + "/";
		}
		return baseUrl.trim();
	}
}
