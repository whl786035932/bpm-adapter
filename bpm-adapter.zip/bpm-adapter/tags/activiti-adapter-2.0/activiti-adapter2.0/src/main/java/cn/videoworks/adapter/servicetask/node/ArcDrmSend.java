package cn.videoworks.adapter.servicetask.node;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import org.activiti.engine.delegate.DelegateExecution;
import org.activiti.engine.delegate.JavaDelegate;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import cn.videoworks.adapter.exception.AdapterBusinessException;
import cn.videoworks.adapter.servicetask.dto.ArcDrmSendRequestDto;
import cn.videoworks.adapter.servicetask.dto.MCClusterArcVideoTranscodeSendTaskRequestDto;
import cn.videoworks.adapter.util.HttpUtil;
import cn.videoworks.adapter.util.JsonUtil;
import cn.videoworks.adapter.util.PropertiesUtil;

/**
 * 虹软drm加密
 * 
 * @author ad
 * 
 */
public class ArcDrmSend implements JavaDelegate {
	private Logger logger = LoggerFactory.getLogger(ArcDrmSend.class);

	@Override
	public void execute(DelegateExecution delegateExecution) throws Exception {
		try {
			ArcDrmSendRequestDto requestDto = buildRequest(delegateExecution);
			String requestJson = JsonUtil.format(requestDto);
			String url = getBaseUrl(delegateExecution.getVariables())
					+ "Encrypt/vodFileRequest";
			String responseJson = HttpUtil.httpPost(url, requestJson,
					HttpUtil.HttpRequestType.JSON);
			HashMap<String, Object> responseMap = JsonUtil.parse(responseJson,
					HashMap.class);
			if (responseMap.containsKey("status")) {
				if ("0".equals(responseMap.get("status").toString())) {
					delegateExecution.setVariable("errcode", 0);
					delegateExecution.setVariable("error_msg", "虹软drm加密任务下发成功");
					delegateExecution.setVariable("contentId", requestDto.getContentId());
					return;
				} else {
					logger.debug("下发drm加密返回异常参数：" + responseJson);
					delegateExecution.setVariable("errcode", 1);
					delegateExecution.setVariable("error_msg", "虹软drm加密任务下发异常");
					return;
				}
			} else {
				logger.debug("下发drm加密返回异常参数：" + responseJson);
				delegateExecution.setVariable("errcode", 1);
				delegateExecution.setVariable("error_msg", "虹软drm加密任务下发异常");
				return;
			}

		} catch (Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage(), e.fillInStackTrace());
			delegateExecution.setVariable("errcode", 1);
			delegateExecution.setVariable("error_msg", "虹软drm加密任务下发异常");
		}

	}

	public ArcDrmSendRequestDto buildRequest(DelegateExecution delegateExecution)
			throws Exception {
		try {
			Map<String, Object> variables = delegateExecution.getVariables();
			ArcDrmSendRequestDto dto = new ArcDrmSendRequestDto();
			dto.setContentId(String.valueOf(variables.get("uuid")));
			String[] fileNames=String.valueOf(variables.get("outputPath")).split("/");
			dto.setFileName(fileNames[fileNames.length-1]);
			dto.setFilePath(String.valueOf(variables.get("drm_http_url")));
			dto.setOutputPath(String.valueOf(variables.get("outputPath")).replace("vwfs://", PropertiesUtil.get("arcDrmVwfs")));
			dto.setCallBackUrl("isNull");
			return dto;
		} catch (Exception e) {
			e.printStackTrace();
			throw new AdapterBusinessException();
		}
	}

	public String getBaseUrl(Map<String, Object> variables) throws Exception {
		String baseUrl = "";
		if (variables.containsKey("arcDrmIp")
				&& variables.get("arcDrmIp") != null) {
			baseUrl = String.valueOf(variables.get("arcDrmIp"));
		} else {
			baseUrl = PropertiesUtil.get("arcDrmIp");
		}
		if (StringUtils.isBlank(baseUrl)) {
			throw new AdapterBusinessException("读取drm加密ip异常");
		}
		if (!baseUrl.startsWith("http://")) {
			baseUrl = "http://" + baseUrl;
		}
		if (!baseUrl.endsWith("/")) {
			baseUrl = baseUrl + "/";
		}
		return baseUrl.trim();
	}

}
