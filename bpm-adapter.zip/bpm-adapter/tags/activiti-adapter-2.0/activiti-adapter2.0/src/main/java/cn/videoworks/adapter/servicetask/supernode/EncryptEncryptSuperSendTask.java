package cn.videoworks.adapter.servicetask.supernode;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.activiti.engine.delegate.DelegateExecution;
import org.activiti.engine.delegate.JavaDelegate;
import org.activiti.engine.history.HistoricActivityInstance;
import org.activiti.engine.history.VWHistoricProcessInstance;
import org.activiti.engine.repository.ProcessDefinition;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import cn.videoworks.adapter.exception.AdapterBusinessException;
import cn.videoworks.adapter.exception.HttpException;
import cn.videoworks.adapter.servicetask.dto.EncryptEncryptSendRequestDto;
import cn.videoworks.adapter.servicetask.dto.EncryptEncryptSendResponseDto;
import cn.videoworks.adapter.servicetask.dto.MCClusterArcVideoTranscodeSendTaskRequestDto;
import cn.videoworks.adapter.servicetask.dto.MCClusterArcVideoTranscodeSendTaskResponseDto;
import cn.videoworks.adapter.servicetask.dto.MCClusterCheckTaskRequestDto;
import cn.videoworks.adapter.servicetask.dto.MCClusterCheckTaskResponseDto;
import cn.videoworks.adapter.servicetask.dto.MCClusterSendTaskRequestDto;
import cn.videoworks.adapter.servicetask.dto.MCClusterSendTaskResponseDto;
import cn.videoworks.adapter.servicetask.enumeration.MCClusterTaskType;
import cn.videoworks.adapter.util.HttpUtil;
import cn.videoworks.adapter.util.JsonUtil;
import cn.videoworks.adapter.util.PropertiesUtil;
import cn.videoworks.commons.util.json.JsonConverter;

/**
 * 加密系统下发任务模板类 Created by liran on 2015/12/9.
 */
public abstract class EncryptEncryptSuperSendTask implements JavaDelegate {

	private Logger logger = LoggerFactory
			.getLogger(EncryptEncryptSuperSendTask.class);

	DateFormat df = new SimpleDateFormat("yyyyMMddHHmmss");

	public void execute(DelegateExecution delegateExecution) {
		try{
			EncryptEncryptSendRequestDto requestDto = buildRequest(delegateExecution);
			String requestJson = JsonUtil.format(requestDto);
			String url = getBaseUrl(delegateExecution.getVariables())
					+ "api/encrypt";
			String responseJson = HttpUtil.httpPost(url, requestJson,
					HttpUtil.HttpRequestType.JSON);
			EncryptEncryptSendResponseDto responseDto = JsonUtil.parse(
					responseJson, EncryptEncryptSendResponseDto.class);
			if (responseDto!=null && responseDto.getStatusCode()==200 && null != responseDto.getData()) {
				delegateExecution.setVariable("taskId",responseDto.getData().get("id"));
				delegateExecution.setVariable("errcode", 0);
				delegateExecution.setVariable("error_msg", "下发加密任务成功");
//				logger.debug("下发加密任务成功!" + "---" + "请求:" + "(" + requestJson
//						+ ")" + "---" + "响应:" + "(" + responseJson + ")");
			} else {
				delegateExecution.setVariable("errcode", 1);
				delegateExecution.setVariable("error_msg", "下发加密任务失败:"+ responseDto.getMessage());
//				logger.debug("下发加密任务失败!" + "---" + "请求:" + "(" + requestJson
//						+ ")" + "---" + "响应:" + "(" + responseJson + ")");
			}
		} catch (Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage(), e.fillInStackTrace());
			delegateExecution.setVariable("errcode", 1);
			delegateExecution.setVariable("error_msg", "下发加密任务异常");
		}
		
	}

	public EncryptEncryptSendRequestDto buildRequest(
			DelegateExecution delegateExecution) throws Exception {
		try {
			Map<String, Object> variables = delegateExecution.getVariables();
			EncryptEncryptSendRequestDto dto = new EncryptEncryptSendRequestDto();
			dto.setVersion((Integer)variables.get("version"));
			dto.setName((String) variables.get("name"));
			dto.setInput((String) variables.get("input"));
			dto.setOutput((String) variables.get("output"));
			return dto;
		} catch (Exception e) {
			e.printStackTrace();
			throw new AdapterBusinessException();
		}
	}


	public String getBaseUrl(Map<String, Object> variables) throws Exception {
		String baseUrl = "";
		if (variables.containsKey("encrypt_ip")
				&& variables.get("encrypt_ip") != null) {
			baseUrl = String.valueOf(variables.get("encrypt_ip"));
		} else {
			baseUrl = PropertiesUtil.get("encrypt.ip");
		}
		if (StringUtils.isBlank(baseUrl)) {
			throw new AdapterBusinessException("读取计算集群URL异常");
		}
		if (!baseUrl.startsWith("http://")) {
			baseUrl = "http://" + baseUrl;
		}
		if (!baseUrl.endsWith("/")) {
			baseUrl = baseUrl + "/";
		}
		return baseUrl;
	}
}
