package cn.videoworks.adapter.servicetask.node;

import cn.videoworks.adapter.servicetask.enumeration.PublisherTaskType;
import cn.videoworks.adapter.servicetask.supernode.PublisherSuperSendTask;

import org.activiti.engine.delegate.DelegateExecution;
import org.activiti.engine.history.VWHistoricProcessInstance;
import org.apache.commons.lang3.StringUtils;

import java.util.Map;

public class PublisherDeploySend extends PublisherSuperSendTask {

	@Override
	public String getNameSurfix() throws Exception {
		return "Deploy";
	}

	public PublisherTaskType getTaskType() throws Exception {
		return PublisherTaskType.add;
	}

	public String getCustomer(Map<String, Object> variables) throws Exception {
		String customer = "";
		if (variables.get("customer") != null
				&& StringUtils.isNotBlank(String.valueOf(variables
						.get("customer")))) {
			customer = String.valueOf(variables.get("customer"));
		} else {
			customer = String.valueOf(variables.get("template"));
		}
		return customer;
	}

	public String getCatalogInfo(Map<String, Object> variables)
			throws Exception {
		return String.valueOf(variables.get("catalog"));
	}

	public String getVideoName(Map<String, Object> variables) {
		String video_url = "";
		if (variables.containsKey("video_url")
				&& variables.get("video_url") != null) {
			video_url = String.valueOf(variables.get("video_url"));
		}
		if (video_url.contains("[") && video_url.contains("]")) {
			video_url = video_url.substring(2, video_url.length() - 2);
		}
		return video_url;
	}

	public String getStrategy(Map<String, Object> variables) throws Exception {
		return String.valueOf(variables.get("template"));
	}

	public String getUsername(DelegateExecution delegateExecution)
			throws Exception {
		VWHistoricProcessInstance childProcess = delegateExecution
				.getEngineServices().getHistoryService()
				.createVWHistoricProcessInstanceQuery()
				.processInstanceId(delegateExecution.getProcessInstanceId())
				.singleResult();
		VWHistoricProcessInstance process = delegateExecution
				.getEngineServices().getHistoryService()
				.createVWHistoricProcessInstanceQuery()
				.processInstanceId(childProcess.getSuperProcessInstanceId())
				.singleResult();
		return process.getStartUserId();
	}

	public String getCallBackUrl(Map<String, Object> variables)throws Exception{
		return String.valueOf(variables.get("callBackUrl"));
	}

	public String getPreparId(Map<String, Object> variables) throws Exception {
		return String.valueOf(variables.get("prepareId"));
	}

	public String getAlias(Map<String, Object> variables)
			throws Exception {
		if(variables.containsKey("alias")){
			return String.valueOf(variables.get("alias"));
		}else{
			return "";
		}
		
	}

}
