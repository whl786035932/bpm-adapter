package cn.videoworks.adapter.servicetask.node;

import java.util.Map;

import org.activiti.engine.delegate.DelegateExecution;
import org.activiti.engine.delegate.JavaDelegate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import cn.videoworks.adapter.exception.SystemConfigException;
import cn.videoworks.adapter.util.HttpUtil;
import cn.videoworks.adapter.util.JsonUtil;
import cn.videoworks.adapter.util.PropertiesUtil;

/**
 * 上传媒资内容到百度VOD任务查询
 * @author ad
 *
 */
public class BaiduVodUploadContentCheck implements JavaDelegate{
	private Logger logger = LoggerFactory.getLogger(BaiduVodUploadContentCheck.class);
	/**
	 * 媒资id就是上传任务的id
	 */
	@Override
	public void execute(DelegateExecution delegateExecution) throws Exception {
		try {
			String taskId=String.valueOf(delegateExecution.getVariables().get("taskId"));
			String url=buildRequestUrl(delegateExecution);
			String responseJson=HttpUtil.httpGet(url);
			Map<String,Object> responseMap=JsonUtil.parse(responseJson, Map.class);
			int statusCode=Integer.valueOf(String.valueOf(responseMap.get("statusCode")).indexOf(".")>=0?String.valueOf(responseMap.get("statusCode")).substring(0, String.valueOf(responseMap.get("statusCode")).indexOf(".")):String.valueOf(responseMap.get("statusCode")));
			String msg=String.valueOf(responseMap.get("message"));
			if(statusCode==200){
				logger.info("开始检测媒资【"+String.valueOf(delegateExecution.getVariables().get("mamId"))+"】【"+String.valueOf(delegateExecution.getVariables().get("title"))+"】上传到百度VOD任务状态结果");
				/**
				 * 0：上传中（上传文件到百度）
				 * 1：上传成功等待百度回调（百度开始做任务了）
				 * -1：任务失败
				 * 2：任务成功
				 */
				String taskStatusStr=String.valueOf(((Map<String,Object>)(responseMap.get("body"))).get("taskStatus"));
				taskStatusStr=taskStatusStr.indexOf(".")>=0?taskStatusStr.substring(0, taskStatusStr.indexOf(".")):taskStatusStr;
				int taskStatus=Integer.valueOf(taskStatusStr);
				if(taskStatus==2){
					delegateExecution.setVariable("baidu_target_url", String.valueOf(((Map<String,Object>)(responseMap.get("body"))).get("cdnUrl")));
					delegateExecution.setVariable("errcode", 0);
		            delegateExecution.setVariable("error_msg", "上传到百度VOD任务成功");
		            logger.info("上传到百度VOD任务成功【"+taskId+"】");
				}else if(taskStatus==-1||taskStatus==-2){
					delegateExecution.setVariable("errcode", 1);
					delegateExecution.setVariable("error_msg", "检测上传百度VOD任务失败:"+msg);
					logger.info("上传到百度VOD任务失败【"+taskId+"】");
				}else{
					delegateExecution.setVariable("errcode", 2);
				}
			}else{
				delegateExecution.setVariable("errcode", 1);
	            delegateExecution.setVariable("error_msg", "检测上传百度VOD任务状态请求失败");
	            logger.info("检测上传百度VOD任务状态请求失败");
			}	
		} catch (Exception e) {
			delegateExecution.setVariable("errcode", 1);
            delegateExecution.setVariable("error_msg", "检测上传百度VOD任务状态请求异常");
            logger.error("检测上传百度VOD任务状态请求异常",e.fillInStackTrace());
		}
	}
	
	private String buildRequestUrl(DelegateExecution delegateExecution) throws Exception{
		String taskId=String.valueOf(delegateExecution.getVariables().get("taskId"));
		String voidServerAddress=PropertiesUtil.get("baidu.vod.server");
		String url="http://"+voidServerAddress+"/forward2bdvod/api/taskStatus/"+taskId;
		return url;
	}

}
