package cn.videoworks.adapter.exception;

/**
 * Created by caofeiyi on 2014/7/10.
 */
public class AdapterBusinessException extends Exception {
    public AdapterBusinessException() {
        super();
    }

    public AdapterBusinessException(String message) {
        super(message);
    }

    public AdapterBusinessException(String message, Throwable cause) {
        super(message, cause);
    }

    public AdapterBusinessException(Throwable cause) {
        super(cause);
    }

    public AdapterBusinessException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
        super(message, cause, enableSuppression, writableStackTrace);
    }
}
