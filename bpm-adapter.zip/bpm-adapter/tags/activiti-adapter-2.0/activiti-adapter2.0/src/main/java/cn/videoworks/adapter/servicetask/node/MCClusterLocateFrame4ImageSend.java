package cn.videoworks.adapter.servicetask.node;

import cn.videoworks.adapter.servicetask.enumeration.MCClusterTaskType;
import cn.videoworks.adapter.servicetask.supernode.MCClusterSuperSendTask;
import cn.videoworks.adapter.util.JsonUtil;

import java.util.*;

public class MCClusterLocateFrame4ImageSend extends MCClusterSuperSendTask {

    public Map<String, Object> getParam(Map<String, Object> variables) throws Exception {
        Map<String, Object> paramMap = new HashMap<String, Object>();
        Iterator<Map.Entry<String, Object>> iter = variables.entrySet().iterator();
        while (iter.hasNext()) {
            Map.Entry entry = (Map.Entry) iter.next();
            String key = (String) entry.getKey();
            Object val = entry.getValue();
            if (key.equals("frames")) {
                String frames = (String) val;
                if (frames == null) return null;
                List<Map<String, Object>> list = JsonUtil.parse(frames, LinkedList.class);
                paramMap.put("frameinfo", list);
            } else if (key.equals("video_url")) {
                String videoUrl = (String) val;
                if (videoUrl == null) return null;
                paramMap.put("input", videoUrl);
            }
        }
        if (paramMap.containsKey("frameinfo") && paramMap.containsKey("input")) {
            return paramMap;
        } else {
            return null;
        }
    }

    public List<String> getTemplate(Map<String, Object> variables) throws Exception {
        return new LinkedList<String>();
    }

    public MCClusterTaskType getType() throws Exception {
        return MCClusterTaskType.LocateFrame;
    }

}
