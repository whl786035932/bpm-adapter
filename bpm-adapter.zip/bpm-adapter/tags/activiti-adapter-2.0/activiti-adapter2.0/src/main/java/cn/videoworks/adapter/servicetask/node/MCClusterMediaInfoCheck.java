package cn.videoworks.adapter.servicetask.node;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import cn.videoworks.adapter.servicetask.supernode.MCClusterSuperCheckTask;
import cn.videoworks.adapter.util.JsonUtil;

public class MCClusterMediaInfoCheck extends MCClusterSuperCheckTask {

	public Map<String, String> getOutput(Map<String, Object> map)
			throws Exception {
		Map<String, String> variables = new HashMap<String, String>();
		MaPhysicalFile file = getMaPhysicalFile((Map<String, Object>) map
				.get("message"));
		variables.put("out_videoinfo", JsonUtil.format(file));
		return variables;
	}

	private MaPhysicalFile getMaPhysicalFile(Map<String, Object> map)
			throws Exception {
		MaPhysicalFile maPhysicalFile = new MaPhysicalFile();
		maPhysicalFile.codeTemplate = "SOURCE";
		if (map.containsKey("stream_param") && map.get("stream_param") != null) {
			Map<String, Object> streamParam = (Map<String, Object>) map
					.get("stream_param");
			if (streamParam.containsKey("extname")
					&& streamParam.get("extname") != null) {
				maPhysicalFile.format = String.valueOf(streamParam
						.get("extname"));
			}
			if (streamParam.containsKey("filesize")
					&& streamParam.get("filesize") != null) {
				maPhysicalFile.fileSize = new BigDecimal(
						String.valueOf(streamParam.get("filesize")))
						.longValue();
			}
			if (streamParam.containsKey("muxrate")
					&& streamParam.get("muxrate") != null) {
				maPhysicalFile.muxrate = String.valueOf(streamParam
						.get("muxrate"));
			}
			if (streamParam.containsKey("duration")
					&& streamParam.get("duration") != null) {
				maPhysicalFile.duration = new BigDecimal(
						String.valueOf(streamParam.get("duration")))
						.longValue();
			}
			if (streamParam.containsKey("extend_options")
					&& streamParam.get("extend_options") != null) {
				Map<String, Object> streamExtendOptions = (Map<String, Object>) streamParam
						.get("extend_options");
				if (streamExtendOptions.containsKey("servicename")
						&& streamExtendOptions.get("servicename") != null) {
					maPhysicalFile.name = String.valueOf(streamExtendOptions
							.get("servicename"));
				}
			}
		}

		if (map.containsKey("video_param") && map.get("video_param") != null) {
			Map<String, Object> videoParam = (Map<String, Object>) map
					.get("video_param");
			if (videoParam.containsKey("codec")
					&& videoParam.get("codec") != null) {
				maPhysicalFile.videoCode = String.valueOf(videoParam
						.get("codec"));
			}
			if (videoParam.containsKey("fps") && videoParam.get("fps") != null) {
				try {
					List frameList = (List) ((Map<String, Object>) map
							.get("video_param")).get("fps");
					if (frameList.size() == 0)
						maPhysicalFile.frameRate = 0.0f;
					else {
						maPhysicalFile.frameRate = new BigDecimal(
								String.valueOf(frameList.get(0))).floatValue();
					}
				} catch (Exception e) {
					maPhysicalFile.frameRate = 0.0f;
				}
			}
			if (videoParam.containsKey("width")
					&& videoParam.get("width") != null) {
				maPhysicalFile.width = new BigDecimal(String.valueOf(videoParam
						.get("width"))).intValue();
			}
			if (videoParam.containsKey("height")
					&& videoParam.get("height") != null) {
				maPhysicalFile.height = new BigDecimal(
						String.valueOf(videoParam.get("height"))).intValue();
			}
			if (videoParam.containsKey("aspect")
					&& videoParam.get("aspect") != null) {
				maPhysicalFile.screenRatio = String.valueOf(videoParam
						.get("aspect"));
			}
			if (videoParam.containsKey("bitrate")
					&& videoParam.get("bitrate") != null) {
				maPhysicalFile.videoBitRate = String.valueOf(videoParam
						.get("bitrate"));
			}
			if (videoParam.containsKey("scan_type")
					&& videoParam.get("scan_type") != null) {
				String scanMode = String.valueOf(videoParam.get("scan_type"));
				try {
					maPhysicalFile.scanMode = ScanMode.valueOf(scanMode
							.toUpperCase());
				} catch (Exception e) {
					maPhysicalFile.scanMode = ScanMode.PROGRESSIVE;
				}
			}
			if (videoParam.containsKey("extend_options")
					&& videoParam.get("extend_options") != null) {
				Map<String, Object> videoExtendOptions = (Map<String, Object>) videoParam
						.get("extend_options");
				if (videoExtendOptions.containsKey("video_standard")
						&& videoExtendOptions.get("video_standard") != null) {
					maPhysicalFile.videoStandard = String
							.valueOf(videoExtendOptions.get("video_standard"));
				}
				if (videoExtendOptions.containsKey("video_scan_order")
						&& videoExtendOptions.get("video_scan_order") != null) {
					maPhysicalFile.scanOrder = String
							.valueOf(videoExtendOptions.get("video_scan_order"));
				}
			}
		}
		if (map.containsKey("audio_param") && map.get("audio_param") != null) {
			Map<String, Object> audioParam = (Map<String, Object>) map
					.get("audio_param");
			if (audioParam.containsKey("codec")
					&& audioParam.get("codec") != null) {
				maPhysicalFile.audioCode = String.valueOf(audioParam
						.get("codec"));
			}
			if (audioParam.containsKey("bitrate")
					&& audioParam.get("bitrate") != null) {
				maPhysicalFile.audioBitRate = String.valueOf(audioParam
						.get("bitrate"));
			}
			if (audioParam.containsKey("channels")
					&& audioParam.get("channels") != null) {
				maPhysicalFile.trackCount = new BigDecimal(
						String.valueOf(audioParam.get("channels"))).intValue();
			}
			if (audioParam.containsKey("samplerate")
					&& audioParam.get("samplerate") != null) {
				try {
					List sampleList = (List) audioParam.get("samplerate");
					if (sampleList.size() == 0)
						maPhysicalFile.samplingRate = 0;
					else
						maPhysicalFile.samplingRate = new BigDecimal(
								String.valueOf(sampleList.get(0))).intValue();
				} catch (Exception e) {
					maPhysicalFile.samplingRate = 0;
				}
			}
			if (audioParam.containsKey("extend_options")
					&& audioParam.get("extend_options") != null) {
				Map<String, Object> audioExtendOptions = (Map<String, Object>) audioParam
						.get("extend_options");
				if (audioExtendOptions.containsKey("audio_bitrate_mode")
						&& audioExtendOptions.get("audio_bitrate_mode") != null) {
					maPhysicalFile.audioBitrateMode = String
							.valueOf(audioExtendOptions
									.get("audio_bitrate_mode"));
				}
			}
		}
		return maPhysicalFile;
	}

	private class MaPhysicalFile {

		/** 物理文件名称 */
		private String name;

		/** 物理文件地址 */
		private String sourceUrl;

		/** 目标文件地址 */
		private String targetUrl;

		/** 采用编码模版名称 */
		private String codeTemplate;

		/** 封装格式 */
		private String format;

		/** 视频编码 */
		private String videoCode;

		/** 视频码率 */
		private String videoBitRate;

		/** 视频宽(px) */
		private int width;

		/** 视频高(px) */
		private int height;

		/** 时长 */
		private long duration;

		/** 画面比例 */
		private String screenRatio;

		/** 视频帧率 */
		private float frameRate;

		/** 扫描方式 */
		private ScanMode scanMode;

		/** 扫描顺序 */
		private String scanOrder;

		/** 制式 */
		private String videoStandard;

		/** 音频编码 */
		private String audioCode;

		/** 音频码率 */
		private String audioBitRate;

		/** 音频采样率 */
		private int samplingRate;

		/** 音轨 */
		private int trackCount;

		/** 音频码率模式 */
		private String audioBitrateMode;

		/** 文件大小(单位是k) */
		private long fileSize;

		/** 清晰度 */
		private String definition;

		/** 复合码率 */
		private String muxrate;

		public String getName() {
			return name;
		}

		public void setName(String name) {
			this.name = name;
		}

		public String getSourceUrl() {
			return sourceUrl;
		}

		public void setSourceUrl(String sourceUrl) {
			this.sourceUrl = sourceUrl;
		}

		public String getTargetUrl() {
			return targetUrl;
		}

		public void setTargetUrl(String targetUrl) {
			this.targetUrl = targetUrl;
		}

		public String getCodeTemplate() {
			return codeTemplate;
		}

		public void setCodeTemplate(String codeTemplate) {
			this.codeTemplate = codeTemplate;
		}

		public String getFormat() {
			return format;
		}

		public void setFormat(String format) {
			this.format = format;
		}

		public String getVideoCode() {
			return videoCode;
		}

		public void setVideoCode(String videoCode) {
			this.videoCode = videoCode;
		}

		public String getVideoBitRate() {
			return videoBitRate;
		}

		public void setVideoBitRate(String videoBitRate) {
			this.videoBitRate = videoBitRate;
		}

		public int getWidth() {
			return width;
		}

		public void setWidth(int width) {
			this.width = width;
		}

		public int getHeight() {
			return height;
		}

		public void setHeight(int height) {
			this.height = height;
		}

		public long getDuration() {
			return duration;
		}

		public void setDuration(long duration) {
			this.duration = duration;
		}

		public String getScreenRatio() {
			return screenRatio;
		}

		public void setScreenRatio(String screenRatio) {
			this.screenRatio = screenRatio;
		}

		public float getFrameRate() {
			return frameRate;
		}

		public void setFrameRate(float frameRate) {
			this.frameRate = frameRate;
		}

		public ScanMode getScanMode() {
			return scanMode;
		}

		public void setScanMode(ScanMode scanMode) {
			this.scanMode = scanMode;
		}

		public String getScanOrder() {
			return scanOrder;
		}

		public void setScanOrder(String scanOrder) {
			this.scanOrder = scanOrder;
		}

		public String getVideoStandard() {
			return videoStandard;
		}

		public void setVideoStandard(String videoStandard) {
			this.videoStandard = videoStandard;
		}

		public String getAudioCode() {
			return audioCode;
		}

		public void setAudioCode(String audioCode) {
			this.audioCode = audioCode;
		}

		public String getAudioBitRate() {
			return audioBitRate;
		}

		public void setAudioBitRate(String audioBitRate) {
			this.audioBitRate = audioBitRate;
		}

		public int getSamplingRate() {
			return samplingRate;
		}

		public void setSamplingRate(int samplingRate) {
			this.samplingRate = samplingRate;
		}

		public int getTrackCount() {
			return trackCount;
		}

		public void setTrackCount(int trackCount) {
			this.trackCount = trackCount;
		}

		public String getAudioBitrateMode() {
			return audioBitrateMode;
		}

		public void setAudioBitrateMode(String audioBitrateMode) {
			this.audioBitrateMode = audioBitrateMode;
		}

		public long getFileSize() {
			return fileSize;
		}

		public void setFileSize(long fileSize) {
			this.fileSize = fileSize;
		}

		public String getDefinition() {
			return definition;
		}

		public void setDefinition(String definition) {
			this.definition = definition;
		}

		public String getMuxrate() {
			return muxrate;
		}

		public void setMuxrate(String muxrate) {
			this.muxrate = muxrate;
		}
	}

	private enum ScanMode {
		// 逐行扫描，隔行扫描
		PROGRESSIVE, INTERLACED;
	}
}