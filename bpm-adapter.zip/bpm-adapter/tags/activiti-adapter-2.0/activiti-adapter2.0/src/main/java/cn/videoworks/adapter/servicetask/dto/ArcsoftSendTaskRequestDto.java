package cn.videoworks.adapter.servicetask.dto;

import com.thoughtworks.xstream.annotations.XStreamAlias;
import com.thoughtworks.xstream.annotations.XStreamAsAttribute;

/**
 * Created by caofeiyi on 2015/1/12.
 */
@XStreamAlias("task")
public class ArcsoftSendTaskRequestDto {
    @XStreamAlias("name")
    private String name;
    @XStreamAlias("encodingoption")
    private String encodingoption;
    @XStreamAlias("priority")
    private int priority;
    @XStreamAlias("profile")
    private Profile profile;
    @XStreamAlias("inputfile")
    private InputFile inputFile;
    @XStreamAlias("outputfile")
    private OutputFile outputFile;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEncodingoption() {
        return encodingoption;
    }

    public void setEncodingoption(String encodingoption) {
        this.encodingoption = encodingoption;
    }

    public int getPriority() {
        return priority;
    }

    public void setPriority(int priority) {
        this.priority = priority;
    }

    public Profile getProfile() {
        return profile;
    }

    public void setProfile(Profile profile) {
        this.profile = profile;
    }

    public InputFile getInputFile() {
        return inputFile;
    }

    public void setInputFile(InputFile inputFile) {
        this.inputFile = inputFile;
    }

    public OutputFile getOutputFile() {
        return outputFile;
    }

    public void setOutputFile(OutputFile outputFile) {
        this.outputFile = outputFile;
    }

    public static class Profile {
        @XStreamAsAttribute
        @XStreamAlias("id")
        private String id;

        public String getId() {
            return id;
        }

        public void setId(String id) {
            this.id = id;
        }

        public Profile() {
        }

        public Profile(String id) {
            this.id = id;
        }
    }

    public static class InputFile {
        @XStreamAlias("uri")
        private String uri;

        public String getUri() {
            return uri;
        }

        public void setUri(String uri) {
            this.uri = uri;
        }

        public InputFile() {
        }

        public InputFile(String uri) {
            this.uri = uri;
        }
    }

    public static class OutputFile {
        @XStreamAlias("uri")
        private String uri;

        public String getUri() {
            return uri;
        }

        public void setUri(String uri) {
            this.uri = uri;
        }

        public OutputFile() {
        }

        public OutputFile(String uri) {
            this.uri = uri;
        }
    }
}

