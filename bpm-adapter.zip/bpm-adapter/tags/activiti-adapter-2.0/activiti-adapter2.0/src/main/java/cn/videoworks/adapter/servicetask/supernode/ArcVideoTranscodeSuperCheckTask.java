package cn.videoworks.adapter.servicetask.supernode;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.activiti.engine.delegate.DelegateExecution;
import org.activiti.engine.delegate.JavaDelegate;
import org.activiti.engine.history.HistoricActivityInstance;
import org.activiti.engine.history.VWHistoricProcessInstance;
import org.activiti.engine.repository.ProcessDefinition;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import cn.videoworks.adapter.exception.AdapterBusinessException;
import cn.videoworks.adapter.exception.HttpException;
import cn.videoworks.adapter.servicetask.dto.MCClusterArcVideoTranscodeCheckTaskRequestDto;
import cn.videoworks.adapter.servicetask.dto.MCClusterArcVideoTranscodeCheckTaskResponseDto;
import cn.videoworks.adapter.servicetask.dto.MCClusterArcVideoTranscodeSendTaskRequestDto;
import cn.videoworks.adapter.servicetask.dto.MCClusterArcVideoTranscodeSendTaskResponseDto;
import cn.videoworks.adapter.servicetask.dto.MCClusterCheckTaskRequestDto;
import cn.videoworks.adapter.servicetask.dto.MCClusterCheckTaskResponseDto;
import cn.videoworks.adapter.servicetask.dto.MCClusterSendTaskRequestDto;
import cn.videoworks.adapter.servicetask.dto.MCClusterSendTaskResponseDto;
import cn.videoworks.adapter.servicetask.enumeration.MCClusterTaskType;
import cn.videoworks.adapter.util.HttpUtil;
import cn.videoworks.adapter.util.JsonUtil;
import cn.videoworks.adapter.util.PropertiesUtil;

/**
 * 计算集群下发任务模板类 Created by caofeiyi on 2014/7/9.
 */
public abstract class ArcVideoTranscodeSuperCheckTask implements JavaDelegate {

	private Logger logger = LoggerFactory
			.getLogger(ArcVideoTranscodeSuperCheckTask.class);

	DateFormat df = new SimpleDateFormat("yyyyMMddHHmmss");

	public void execute(DelegateExecution delegateExecution) {
		try {

			MCClusterArcVideoTranscodeCheckTaskRequestDto requestDto = buildRequest(delegateExecution);
			String requestJson = JsonUtil.format(requestDto);
			String url = getBaseUrl(delegateExecution.getVariables())
					+"api/json/task/progress";
			String responseJson = HttpUtil.httpPost(url, requestJson,
					HttpUtil.HttpRequestType.JSON);
			logger.debug("查询转码任务id:"+requestJson);
			logger.debug("查询转码任务路径:"+url);
			logger.debug("查询转码任务结果:"+responseJson);
			MCClusterArcVideoTranscodeCheckTaskResponseDto responseDto = JsonUtil.parse(
					responseJson, MCClusterArcVideoTranscodeCheckTaskResponseDto.class);
			if ("COMPLETED".equals(responseDto.getTaskStatus())) {
				delegateExecution.setVariable("errcode", 0);
				delegateExecution.setVariable("error_msg", "转码任务成功");
				logger.debug("转码任务任务成功!" + "---" + "请求:" + "(" + requestJson
						+ ")" + "---" + "响应:" + "(" + responseJson + ")");
			} else if("ERROR".equals(responseDto.getTaskStatus())){
				delegateExecution.setVariable("errcode", 1);
				delegateExecution.setVariable("error_msg", "转码任务异常");
			}else {
				delegateExecution.setVariable("errcode", 2);
				logger.debug("任务状态：【"+responseDto.getTaskStatus()+"】转码完成度为：【"+responseDto.getTaskProgress().getProgress()+"%】");
			}

		} catch (Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage(), e.fillInStackTrace());
			delegateExecution.setVariable("errcode", 1);
			delegateExecution.setVariable("error_msg", "转码任务异常");
		}
	}

	public MCClusterArcVideoTranscodeCheckTaskRequestDto buildRequest(
			DelegateExecution delegateExecution) throws Exception {
		try {
			Map<String, Object> variables = delegateExecution.getVariables();
			MCClusterArcVideoTranscodeCheckTaskRequestDto dto = new MCClusterArcVideoTranscodeCheckTaskRequestDto();
			dto.setTaskId(String.valueOf(variables.get("taskId")));
			return dto;
		} catch (Exception e) {
			e.printStackTrace();
			throw new AdapterBusinessException();
		}
	}


	public String getBaseUrl(Map<String, Object> variables) throws Exception {
		String baseUrl = "";
		if (variables.containsKey("arcvideo_ip")
				&& variables.get("arcvideo_ip") != null) {
			baseUrl = String.valueOf(variables.get("arcvideo_ip"));
		} else {
			baseUrl = PropertiesUtil.get("arcvideoTranscode");
		}
		if (StringUtils.isBlank(baseUrl)) {
			throw new AdapterBusinessException("读取计算集群URL异常");
		}
		if (!baseUrl.startsWith("http://")) {
			baseUrl = "http://" + baseUrl;
		}
		if (!baseUrl.endsWith("/")) {
			baseUrl = baseUrl + "/";
		}
		return baseUrl;
	}
}
