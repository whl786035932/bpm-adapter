package cn.videoworks.adapter.temp;

import java.util.List;

import org.activiti.engine.HistoryService;
import org.activiti.engine.delegate.DelegateExecution;
import org.activiti.engine.delegate.JavaDelegate;
import org.activiti.engine.history.VWHistoricProcessInstance;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import cn.videoworks.adapter.exception.AdapterBusinessException;
import cn.videoworks.adapter.util.HttpUtil;
import cn.videoworks.adapter.util.JsonUtil;
import cn.videoworks.adapter.util.PropertiesUtil;
import cn.videoworks.commons.util.json.JsonConverter;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

public class TaskCandidate4VF implements JavaDelegate {

	private Logger logger = LoggerFactory.getLogger(TaskCandidate.class);

	public void execute(DelegateExecution delegateExecution) {
		try {
			Gson gson = new Gson();
			final String groupType = "拆条-审核业务";
			String candidateGroup = "";
			// cas系统URL
			String casBaseUrl = "http://" + PropertiesUtil.get("cas.ip");
			HistoryService historyService = delegateExecution
					.getEngineServices().getHistoryService();
			// 主流程ID
			String processId = historyService
					.createVWHistoricProcessInstanceQuery()
					.processInstanceId(delegateExecution.getProcessInstanceId())
					.singleResult().getSuperProcessInstanceId();
			// 主流程
			VWHistoricProcessInstance process = historyService
					.createVWHistoricProcessInstanceQuery()
					.processInstanceId(processId).singleResult();
			String processStartUserId = process.getStartUserId();
			if (StringUtils.isNotBlank(processStartUserId)) {
				String responseJson = HttpUtil.httpPost(casBaseUrl
						+ "/user/getUsersByUsernames",
						JsonUtil.format(new String[] { processStartUserId }),
						HttpUtil.HttpRequestType.JSON);
				logger.debug("查询[" + processStartUserId + "]用户信息："
						+ responseJson);
				TaskCandidateResponse response = JsonUtil.parse(responseJson,
						TaskCandidateResponse.class);
				List<UserInfo> users = null;
				logger.debug(JsonConverter.format(response));
				if (response != null && response.getStatusCode() == 200) {
					users = JsonConverter.asList(response.getData()
							.getUserInfos(), UserInfo.class);
				} else {
					throw new AdapterBusinessException("连接CAS系统异常,CAS地址:"
							+ casBaseUrl);
				}
				if (users != null && users.size() > 0) {
					UserInfo userInfo = users.get(0);
					logger.debug(JsonConverter.format(userInfo));
					logger.debug(JsonConverter.format(userInfo.getGroups()));
					if (userInfo != null && userInfo.getGroups() != null
							&& userInfo.getGroups().size() > 0) {
						for (GroupInfo groupInfo : userInfo.getGroups()) {
							if (groupInfo != null
									&& groupInfo.getCategory() != null
									&& groupType.equals(groupInfo.getCategory()
											.getName())) {
								candidateGroup = groupInfo.getName();
								break;
							}
						}
					}
				}
			}
			logger.debug("流程[" + process.getId() + "]的审核任务将分配到["
					+ candidateGroup + "]组");
			delegateExecution.setVariable("taskCandidateGroup", candidateGroup);
			delegateExecution.setVariable("errcode", 0);
			delegateExecution.setVariable("error_msg", "任务分配成功");
		} catch (Exception e) { }
	}
}
