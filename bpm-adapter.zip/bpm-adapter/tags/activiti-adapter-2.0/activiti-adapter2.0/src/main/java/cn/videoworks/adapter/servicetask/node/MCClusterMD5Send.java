package cn.videoworks.adapter.servicetask.node;

import cn.videoworks.adapter.servicetask.enumeration.MCClusterTaskType;
import cn.videoworks.adapter.servicetask.supernode.MCClusterSuperSendTask;
import cn.videoworks.adapter.util.JsonUtil;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by caofeiyi on 2015/3/5.
 */
public class MCClusterMD5Send extends MCClusterSuperSendTask {
    public Map<String, Object> getParam(Map<String, Object> variables) throws Exception {
        Map<String, Object> paramMap = new HashMap<String, Object>();
        if (variables != null && variables.containsKey("files") && variables.get("files") != null) {
            List<String> files = JsonUtil.parse(String.valueOf(variables.get("files")), List.class);
            if (files != null && files.size() > 0) {
                paramMap.put("filenames", files);
                return paramMap;
            }
        }
        return null;
    }

    public List<String> getTemplate(Map<String, Object> variables) throws Exception {
        return new ArrayList<String>();
    }

    public MCClusterTaskType getType() throws Exception {
        return MCClusterTaskType.Md5;
    }
}
