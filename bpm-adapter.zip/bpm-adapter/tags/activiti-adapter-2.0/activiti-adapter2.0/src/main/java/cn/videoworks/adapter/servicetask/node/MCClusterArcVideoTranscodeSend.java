package cn.videoworks.adapter.servicetask.node;

import cn.videoworks.adapter.servicetask.supernode.ArcVideoTranscodeSuperSendTask;

/**
 * 虹软转码任务下发
 * 
 * @author ad
 * 
 */
public class MCClusterArcVideoTranscodeSend  extends ArcVideoTranscodeSuperSendTask{

}
