package cn.videoworks.adapter.servicetask.node;

import cn.videoworks.adapter.servicetask.supernode.MCClusterSuperCheckTask;
import cn.videoworks.adapter.util.JsonUtil;

import java.util.HashMap;
import java.util.Map;

/**
 * Created by caofeiyi on 2015/3/5.
 */
public class MCClusterMD5Check extends MCClusterSuperCheckTask {
    public Map<String, String> getOutput(Map<String, Object> map) throws Exception {
        Map<String, String> variables = new HashMap<String, String>();
        variables.put("out_md5", JsonUtil.format(((Map) map.get("message")).get("md5infos")));
        return variables;
    }
}
