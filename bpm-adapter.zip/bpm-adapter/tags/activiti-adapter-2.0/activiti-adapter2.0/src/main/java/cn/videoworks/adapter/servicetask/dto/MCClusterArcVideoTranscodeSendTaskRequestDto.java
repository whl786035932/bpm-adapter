package cn.videoworks.adapter.servicetask.dto;

import java.util.List;

public class MCClusterArcVideoTranscodeSendTaskRequestDto {
	//任务名称
	private String taskName;
	private String taskPriority;//任务优先级
	private String taskTemplateId;//任务模板id
	private List<String> taskInputUris;//要转码文件的url
	private List<String> taskOutputUri;//转码后输出文件Uri
	private String taskReportUrl;//状态报告Url，不传就没有转码上报
	public String getTaskName() {
		return taskName;
	}
	public void setTaskName(String taskName) {
		this.taskName = taskName;
	}
	public String getTaskPriority() {
		return taskPriority;
	}
	public void setTaskPriority(String taskPriority) {
		this.taskPriority = taskPriority;
	}
	public String getTaskTemplateId() {
		return taskTemplateId;
	}
	public void setTaskTemplateId(String taskTemplateId) {
		this.taskTemplateId = taskTemplateId;
	}
	
	public List<String> getTaskInputUris() {
		return taskInputUris;
	}
	public void setTaskInputUris(List<String> taskInputUris) {
		this.taskInputUris = taskInputUris;
	}
	
	public List<String> getTaskOutputUri() {
		return taskOutputUri;
	}
	public void setTaskOutputUri(List<String> taskOutputUri) {
		this.taskOutputUri = taskOutputUri;
	}
	public String getTaskReportUrl() {
		return taskReportUrl;
	}
	public void setTaskReportUrl(String taskReportUrl) {
		this.taskReportUrl = taskReportUrl;
	}
	
}
