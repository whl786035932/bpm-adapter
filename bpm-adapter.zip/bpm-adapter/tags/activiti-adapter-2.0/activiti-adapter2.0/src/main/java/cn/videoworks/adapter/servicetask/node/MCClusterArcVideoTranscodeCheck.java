package cn.videoworks.adapter.servicetask.node;

import cn.videoworks.adapter.servicetask.supernode.ArcVideoTranscodeSuperCheckTask;

public class MCClusterArcVideoTranscodeCheck  extends ArcVideoTranscodeSuperCheckTask{
	
}
