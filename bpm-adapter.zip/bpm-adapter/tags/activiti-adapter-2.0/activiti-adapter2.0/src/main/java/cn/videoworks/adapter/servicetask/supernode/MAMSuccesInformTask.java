package cn.videoworks.adapter.servicetask.supernode;

import cn.videoworks.adapter.exception.AdapterBusinessException;
import cn.videoworks.adapter.servicetask.dto.ApplicationActualTaskRequestDto;
import cn.videoworks.adapter.servicetask.dto.ApplicationActualTaskResponseDto;
import cn.videoworks.adapter.servicetask.enumeration.ApplicationActualTaskResult;
import cn.videoworks.adapter.servicetask.enumeration.ApplicationActualTaskType;
import cn.videoworks.adapter.util.HttpUtil;
import cn.videoworks.adapter.util.JsonUtil;
import cn.videoworks.adapter.util.PropertiesUtil;
import org.activiti.engine.delegate.DelegateExecution;
import org.activiti.engine.delegate.JavaDelegate;
import org.activiti.engine.history.VWHistoricTaskInstance;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 视频工厂成功通知操作类. Created by caofeiyi on 2014/8/1.
 */
public abstract class MAMSuccesInformTask implements JavaDelegate {

	private Logger logger = LoggerFactory.getLogger(MAMSuccesInformTask.class);

	public void execute(DelegateExecution delegateExecution) {
		try {
			Map<String, Object> requestDto = buildRequest(delegateExecution);
			String requestJson = JsonUtil.format(requestDto);
			// 拼接url
			String url = "http://" + PropertiesUtil.get("videofactory.ip")
					+ "vfStartCimpReceiveTask";

			// String url = "http://"
			// +"10.2.16.172:9080/videofact/workflowAutoTask/vfStartCimpReceiveTask";
			logger.debug("链接url:" + url);
			String responseJson = HttpUtil.httpPost(url, requestJson,
					HttpUtil.HttpRequestType.JSON);
			logger.debug("返回结果:" + responseJson);
			ApplicationActualTaskResponseDto responseDto = JsonUtil.parse(
					responseJson, ApplicationActualTaskResponseDto.class);
			if (responseDto.getStatusCode() == 200) {
				if (responseDto.getData().getResult() == ApplicationActualTaskResult.SUCCESS) {
					Map<String, String> variables = setVariables(responseDto);
					if (variables != null) {
						delegateExecution.setVariables(variables);
					}
					delegateExecution.setVariable("errcode", 0);
					delegateExecution.setVariable("error_msg", "任务成功");
					logger.debug("任务成功!" + "---" + "请求:" + "(" + requestJson
							+ ")" + "---" + "响应:" + "(" + responseJson + ")");
				} else {
					delegateExecution.setVariable("errcode", 1);
					delegateExecution.setVariable("error_msg", "任务失败:"
							+ responseDto.getData().getResultMessage());
					logger.debug("任务失败!" + "---" + "请求:" + "(" + requestJson
							+ ")" + "---" + "响应:" + "(" + responseJson + ")");
				}
			} else {
				delegateExecution.setVariable("errcode", 1);
				delegateExecution.setVariable("error_msg", "请求异常");
				throw new AdapterBusinessException("请求异常");
			}
		} catch (Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage(), e.fillInStackTrace());
			delegateExecution.setVariable("errcode", 1);
			delegateExecution.setVariable("error_msg", "任务异常");
		}
	}

	public Map<String, Object> buildRequest(DelegateExecution delegateExecution)
			throws Exception {
		Map<String, Object> result = new HashMap<String, Object>();
		Map<String, Object> dto = new HashMap<String, Object>();
		// 参数
		String auditresult = String.valueOf(delegateExecution.getVariables()
				.get("auditresult"));
		Integer auditresulti = null;
		if (auditresult != null) {
			auditresulti = new Integer(auditresult);
		}
		result.put("review_result", auditresulti);
		logger.debug("第一参数:auditresult="
				+ delegateExecution.getVariables().get("auditresult"));
		result.put(
				"review_msg",
				delegateExecution.getVariables().get("audit_msg") == null ? ""
						: String.valueOf(delegateExecution.getVariables().get(
								"audit_msg")));
		logger.debug("第二参数:audit_msg="
				+ delegateExecution.getVariables().get("audit_msg"));
		// 定义流程id
		String processDefinitionId = delegateExecution.getProcessDefinitionId();
		String prepareWorkflowId = String.valueOf(delegateExecution
				.getVariables().get("prepare_workflow_id"));
		logger.debug("参数prepareWorkflowId:"
				+ String.valueOf(delegateExecution.getVariables().get(
						"prepare_workflow_id")));

		// 流程id
		String processInstanceId = delegateExecution.getId();
		// dto.put("processDefinitionId", processDefinitionId);
		// dto.put("processInstanceId", processInstanceId);
		dto.put("prepare_workflow_id", prepareWorkflowId);
		dto.put("data", result);
		return dto;
	}

	public Map<String, String> setVariables(
			ApplicationActualTaskResponseDto responseDto) throws Exception {
		return responseDto.getData().getData();
	}
}
