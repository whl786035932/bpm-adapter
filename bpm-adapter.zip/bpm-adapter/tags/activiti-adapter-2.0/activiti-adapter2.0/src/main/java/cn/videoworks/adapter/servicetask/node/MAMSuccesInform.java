package cn.videoworks.adapter.servicetask.node;

import cn.videoworks.adapter.servicetask.supernode.MAMSuccesInformTask;

public class MAMSuccesInform extends MAMSuccesInformTask {

}