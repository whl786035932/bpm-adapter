package cn.videoworks.adapter.servicetask.enumeration;

/**
 * Created by caofeiyi on 2015/1/12.
 */
public enum ArcsoftTaskStatus {
    RUNNING,
    WAITING,
    PENDING,
    COMPLETED,
    ERROR,
    CANCELLED
}
