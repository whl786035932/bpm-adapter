package cn.videoworks.adapter.servicetask.node;

import cn.videoworks.adapter.servicetask.supernode.MCClusterSuperCheckTask;

import java.util.Map;

public class MCClusterSubtitleRecognitionCheck extends MCClusterSuperCheckTask {

    public Map<String, String> getOutput(Map<String, Object> map)
            throws Exception {
        //TODO
        return null;
    }
}