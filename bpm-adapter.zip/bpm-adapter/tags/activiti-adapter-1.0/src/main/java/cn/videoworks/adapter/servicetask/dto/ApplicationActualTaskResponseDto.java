package cn.videoworks.adapter.servicetask.dto;

public class ApplicationActualTaskResponseDto {
    private int statusCode;
    private String message;
    private ApplicationActualTaskResponseDataDto data;

    public int getStatusCode() {
        return statusCode;
    }

    public void setStatusCode(int statusCode) {
        this.statusCode = statusCode;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public ApplicationActualTaskResponseDataDto getData() {
        return data;
    }

    public void setData(ApplicationActualTaskResponseDataDto data) {
        this.data = data;
    }
}
