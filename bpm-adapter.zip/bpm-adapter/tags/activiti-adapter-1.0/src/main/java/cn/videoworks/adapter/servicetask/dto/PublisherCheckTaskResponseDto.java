package cn.videoworks.adapter.servicetask.dto;

/**
 * Created by caofeiyi on 2014/7/14.
 */
public class PublisherCheckTaskResponseDto {
    private int statusCode;
    private String message;
    private PublisherCheckTaskResponseDataDto data;

    public int getStatusCode() {
        return statusCode;
    }

    public void setStatusCode(int statusCode) {
        this.statusCode = statusCode;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public PublisherCheckTaskResponseDataDto getData() {
        return data;
    }

    public void setData(PublisherCheckTaskResponseDataDto data) {
        this.data = data;
    }
}
