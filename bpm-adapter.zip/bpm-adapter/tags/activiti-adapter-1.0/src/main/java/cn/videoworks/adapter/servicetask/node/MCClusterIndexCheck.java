package cn.videoworks.adapter.servicetask.node;

import cn.videoworks.adapter.servicetask.supernode.MCClusterSuperCheckTask;

import java.util.Map;

public class MCClusterIndexCheck extends MCClusterSuperCheckTask {

    public Map<String, String> getOutput(Map<String, Object> map)
            throws Exception {
        return null;
    }
}