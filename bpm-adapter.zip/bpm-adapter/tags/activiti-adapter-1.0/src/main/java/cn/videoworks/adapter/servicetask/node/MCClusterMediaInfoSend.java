package cn.videoworks.adapter.servicetask.node;

import cn.videoworks.adapter.servicetask.enumeration.MCClusterTaskType;
import cn.videoworks.adapter.servicetask.supernode.MCClusterSuperSendTask;

import java.util.*;
import java.util.Map.Entry;

public class MCClusterMediaInfoSend extends MCClusterSuperSendTask {

    public Map<String, Object> getParam(Map<String, Object> variables) throws Exception {
        Map<String, Object> paramMap = new HashMap<String, Object>();
        Iterator<Entry<String, Object>> iter = variables.entrySet().iterator();
        while (iter.hasNext()) {
            Map.Entry entry = (Map.Entry) iter.next();
            String key = (String) entry.getKey();
            Object val = entry.getValue();
            if (key.equals("video_url")) {
                paramMap.put("input", (String) val);
            }
        }
        if (paramMap.containsKey("input")) {
            return paramMap;
        } else {
            return null;
        }
    }

    public List<String> getTemplate(Map<String, Object> variables) throws Exception {
        return new LinkedList<String>();
    }

    public MCClusterTaskType getType() throws Exception {
        return MCClusterTaskType.MediaInfo;
    }

    public int getPriority() throws Exception {
        return 10;
    }
}