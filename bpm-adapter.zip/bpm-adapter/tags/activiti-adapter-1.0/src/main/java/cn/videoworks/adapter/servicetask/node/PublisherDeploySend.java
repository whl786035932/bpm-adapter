package cn.videoworks.adapter.servicetask.node;

import cn.videoworks.adapter.servicetask.enumeration.PublisherTaskType;
import cn.videoworks.adapter.servicetask.supernode.PublisherSuperSendTask;
import org.apache.commons.lang3.StringUtils;

import java.util.Map;

public class PublisherDeploySend extends PublisherSuperSendTask {

    @Override
    public String getNameSurfix() throws Exception {
        return "Deploy";
    }

    public int getPriority() {
        return 5;
    }

    public PublisherTaskType getTaskType() throws Exception {
        return PublisherTaskType.add;
    }

    public String getCustomer(Map<String, Object> variables) {
        String customer = "";
        if (variables.get("customer") != null && StringUtils.isNotBlank(String.valueOf(variables.get("customer")))) {
            customer = String.valueOf(variables.get("customer"));
        } else {
            customer = String.valueOf(variables.get("template"));
        }
        return customer;
    }

    public String getCatalogInfo(Map<String, Object> variables) {
        return String.valueOf(variables.get("catalog"));
    }

    public String getVideoName(Map<String, Object> variables) {
        String video_url = String.valueOf(variables.get("video_url"));
        if (video_url.contains("[") && video_url.contains("]"))
            video_url = video_url.substring(2, video_url.length() - 2);
        return video_url;
    }

    public String getStrategy(Map<String, Object> variables) {
        return String.valueOf(variables.get("template"));
    }
}
