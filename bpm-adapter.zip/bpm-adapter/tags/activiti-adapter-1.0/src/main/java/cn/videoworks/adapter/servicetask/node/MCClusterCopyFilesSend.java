package cn.videoworks.adapter.servicetask.node;

import cn.videoworks.adapter.servicetask.enumeration.MCClusterTaskType;
import cn.videoworks.adapter.servicetask.supernode.MCClusterSuperSendTask;
import cn.videoworks.adapter.util.JsonUtil;

import java.util.*;
import java.util.Map.Entry;

public class MCClusterCopyFilesSend extends MCClusterSuperSendTask {

    public Map<String, Object> getParam(Map<String, Object> variables) throws Exception {
        Map<String, Object> paramMap = new HashMap<String, Object>();
        Iterator<Entry<String, Object>> iter = variables.entrySet().iterator();
        while (iter.hasNext()) {
            Map.Entry entry = (Map.Entry) iter.next();
            String key = (String) entry.getKey();
            Object val = entry.getValue();
            if (key.equals("files")) {
                List<Map<String, Object>> files = (List<Map<String, Object>>) JsonUtil.parse((String) val, List.class);
                for (Map<String, Object> entity : files) {
                    String from = (String) entity.remove("from");
                    entity.put("src_file", from);
                    String to = (String) entity.remove("to");
                    entity.put("dst_file", to);
                }
                paramMap.put("files", files);
            }
        }
        if (paramMap.containsKey("files")) {
            return paramMap;
        } else {
            return null;
        }
    }


    public List<String> getTemplate(Map<String, Object> variables) throws Exception {
        return new LinkedList<String>();
    }

    public MCClusterTaskType getType() throws Exception {
        return MCClusterTaskType.CopyFiles;
    }

    public int getPriority() throws Exception {
        return 10;
    }
}