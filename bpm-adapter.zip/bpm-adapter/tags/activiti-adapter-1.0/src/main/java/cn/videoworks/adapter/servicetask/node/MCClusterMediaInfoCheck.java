package cn.videoworks.adapter.servicetask.node;

import cn.videoworks.adapter.servicetask.supernode.MCClusterSuperCheckTask;
import cn.videoworks.adapter.util.JsonUtil;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class MCClusterMediaInfoCheck extends MCClusterSuperCheckTask {

    public Map<String, String> getOutput(Map<String, Object> map)
            throws Exception {
        Map<String, String> variables = new HashMap<String, String>();
        MaPhysicalFile file = getMaPhysicalFile((Map<String, Object>) map.get("message"));
        variables.put("out_videoinfo", JsonUtil.format(file));
        return variables;
    }

    private MaPhysicalFile getMaPhysicalFile(Map<String, Object> map) throws Exception {
        MaPhysicalFile maPhysicalFile = new MaPhysicalFile();
        maPhysicalFile.codeTemplate = "SOURCE";
        maPhysicalFile.format = (String) ((Map<String, Object>) map.get("stream_param")).get("extname");
        maPhysicalFile.videoCode = (String) ((Map<String, Object>) map.get("video_param")).get("codec");
        maPhysicalFile.videoBitRate = String.valueOf(((Map<String, Object>) map.get("video_param")).get("bitrate"));
        maPhysicalFile.audioCode = (String) ((Map<String, Object>) map.get("audio_param")).get("codec");
        maPhysicalFile.width = new BigDecimal(String.valueOf(((Map<String, Object>) map.get("video_param")).get("width"))).intValue();
        maPhysicalFile.height = new BigDecimal(String.valueOf(((Map<String, Object>) map.get("video_param")).get("height"))).intValue();
        maPhysicalFile.duration = new BigDecimal(String.valueOf(((Map<String, Object>) map.get("stream_param")).get("duration"))).longValue();
        maPhysicalFile.screenRatio = (String) ((Map<String, Object>) map.get("video_param")).get("aspect");
        try {
            List frameList = (List) ((Map<String, Object>) map.get("video_param")).get("fps");
            if (frameList.size() == 0)
                maPhysicalFile.frameRate = 0.0f;
            else {
                maPhysicalFile.frameRate = ((Double) frameList.get(0)).floatValue();
            }
        } catch (Exception e) {
            maPhysicalFile.frameRate = 0.0f;
        }
        maPhysicalFile.audioBitRate = String.valueOf(((Map<String, Object>) map.get("audio_param")).get("bitrate"));

        try {
            List sampleList = (List) ((Map<String, Object>) map.get("audio_param")).get("samplerate");
            if (sampleList.size() == 0)
                maPhysicalFile.samplingRate = 0;
            else
                maPhysicalFile.samplingRate = (Integer) sampleList.get(0);
        } catch (Exception e) {
            maPhysicalFile.samplingRate = 0;
        }
        maPhysicalFile.trackCount = new BigDecimal(String.valueOf(((Map<String, Object>) map.get("audio_param")).get("channels"))).intValue();
        String scanMode = (String) ((Map<String, Object>) map.get("video_param")).get("scan_type");
        try {
            maPhysicalFile.scanMode = ScanMode.valueOf(scanMode.toUpperCase());
        } catch (Exception e) {
            maPhysicalFile.scanMode = ScanMode.PROGRESSIVE;
        }
        return maPhysicalFile;
    }

    private class MaPhysicalFile {
        /**
         * 物理文件地址
         */
        private String sourceUrl;

        /**
         * 目标文件地址
         */
        private String targetUrl;

        /**
         * 采用编码模版名称
         */
        private String codeTemplate;

        /**
         * 封装格式
         */
        private String format;

        /**
         * 视频编码
         */
        private String videoCode;

        /**
         * 视频码率
         */
        private String videoBitRate;

        /**
         * 视频宽(px)
         */
        private int width;

        /**
         * 视频高(px)
         */
        private int height;

        /**
         * 时长
         */
        private long duration;

        /**
         * 画面比例
         */
        private String screenRatio;

        /**
         * 视频帧率
         */
        private float frameRate;

        /**
         * 扫描方式
         */
        private ScanMode scanMode;

        /**
         * 音频编码
         */
        private String audioCode;

        /**
         * 音频码率
         */
        private String audioBitRate;

        /**
         * 音频采样率
         */
        private int samplingRate;

        /**
         * 音轨
         */
        private int trackCount;

        /**
         * @return the sourceUrl
         */
        public String getSourceUrl() {
            return sourceUrl;
        }

        /**
         * @param sourceUrl the sourceUrl to set
         */
        public void setSourceUrl(String sourceUrl) {
            this.sourceUrl = sourceUrl;
        }

        /**
         * @return the targetUrl
         */
        public String getTargetUrl() {
            return targetUrl;
        }

        /**
         * @param targetUrl the targetUrl to set
         */
        public void setTargetUrl(String targetUrl) {
            this.targetUrl = targetUrl;
        }

        /**
         * @return the codeTemplate
         */
        public String getCodeTemplate() {
            return codeTemplate;
        }

        /**
         * @param codeTemplate the codeTemplate to set
         */
        public void setCodeTemplate(String codeTemplate) {
            this.codeTemplate = codeTemplate;
        }

        /**
         * @return the format
         */
        public String getFormat() {
            return format;
        }

        /**
         * @param format the format to set
         */
        public void setFormat(String format) {
            this.format = format;
        }

        /**
         * @return the videoCode
         */
        public String getVideoCode() {
            return videoCode;
        }

        /**
         * @param videoCode the videoCode to set
         */
        public void setVideoCode(String videoCode) {
            this.videoCode = videoCode;
        }

        /**
         * @return the videoBitRate
         */
        public String getVideoBitRate() {
            return videoBitRate;
        }

        /**
         * @param videoBitRate the videoBitRate to set
         */
        public void setVideoBitRate(String videoBitRate) {
            this.videoBitRate = videoBitRate;
        }

        /**
         * @return the width
         */
        public int getWidth() {
            return width;
        }

        /**
         * @param width the width to set
         */
        public void setWidth(int width) {
            this.width = width;
        }

        /**
         * @return the height
         */
        public int getHeight() {
            return height;
        }

        /**
         * @param height the height to set
         */
        public void setHeight(int height) {
            this.height = height;
        }

        /**
         * @return the duration
         */
        public long getDuration() {
            return duration;
        }

        /**
         * @param duration the duration to set
         */
        public void setDuration(long duration) {
            this.duration = duration;
        }

        /**
         * @return the screenRatio
         */
        public String getScreenRatio() {
            return screenRatio;
        }

        /**
         * @param screenRatio the screenRatio to set
         */
        public void setScreenRatio(String screenRatio) {
            this.screenRatio = screenRatio;
        }

        /**
         * @return the frameRate
         */
        public float getFrameRate() {
            return frameRate;
        }

        /**
         * @param frameRate the frameRate to set
         */
        public void setFrameRate(float frameRate) {
            this.frameRate = frameRate;
        }

        /**
         * @return the scanMode
         */
        public ScanMode getScanMode() {
            return scanMode;
        }

        /**
         * @param scanMode the scanMode to set
         */
        public void setScanMode(ScanMode scanMode) {
            this.scanMode = scanMode;
        }

        /**
         * @return the audioCode
         */
        public String getAudioCode() {
            return audioCode;
        }

        /**
         * @param audioCode the audioCode to set
         */
        public void setAudioCode(String audioCode) {
            this.audioCode = audioCode;
        }

        /**
         * @return the audioBitRate
         */
        public String getAudioBitRate() {
            return audioBitRate;
        }

        /**
         * @param audioBitRate the audioBitRate to set
         */
        public void setAudioBitRate(String audioBitRate) {
            this.audioBitRate = audioBitRate;
        }

        /**
         * @return the samplingRate
         */
        public int getSamplingRate() {
            return samplingRate;
        }

        /**
         * @param samplingRate the samplingRate to set
         */
        public void setSamplingRate(int samplingRate) {
            this.samplingRate = samplingRate;
        }

        /**
         * @return the trackCount
         */
        public int getTrackCount() {
            return trackCount;
        }

        /**
         * @param trackCount the trackCount to set
         */
        public void setTrackCount(int trackCount) {
            this.trackCount = trackCount;
        }


    }

    private enum ScanMode {
        //逐行扫描，隔行扫描
        PROGRESSIVE, INTERLACED;
    }
}