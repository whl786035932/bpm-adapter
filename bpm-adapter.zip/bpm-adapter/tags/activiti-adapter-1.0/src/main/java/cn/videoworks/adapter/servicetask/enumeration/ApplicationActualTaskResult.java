package cn.videoworks.adapter.servicetask.enumeration;

public enum ApplicationActualTaskResult {
    SUCCESS,    //成功
    FAILURE,    //失败
}
