package cn.videoworks.adapter.servicetask.node;

import cn.videoworks.adapter.servicetask.supernode.MCClusterSuperCheckTask;
import cn.videoworks.adapter.util.JsonUtil;

import java.util.HashMap;
import java.util.Map;

public class MCClusterImageFeatureCheck extends MCClusterSuperCheckTask {

    public Map<String, String> getOutput(Map<String, Object> map) throws Exception {
        Map<String, String> variables = new HashMap<String, String>();
        variables.put("out_frames", JsonUtil.format(((Map) map.get("message")).get("featureinfo")));
        return variables;
    }
}
