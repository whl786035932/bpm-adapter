package cn.videoworks.adapter.servicetask.supernode;

import cn.videoworks.adapter.exception.AdapterBusinessException;
import cn.videoworks.adapter.exception.HttpException;
import cn.videoworks.adapter.servicetask.dto.MCClusterCheckTaskRequestDto;
import cn.videoworks.adapter.servicetask.dto.MCClusterCheckTaskResponseDto;
import cn.videoworks.adapter.servicetask.dto.MCClusterSendTaskRequestDto;
import cn.videoworks.adapter.servicetask.dto.MCClusterSendTaskResponseDto;
import cn.videoworks.adapter.servicetask.enumeration.MCClusterTaskType;
import cn.videoworks.adapter.util.HttpUtil;
import cn.videoworks.adapter.util.JsonUtil;
import cn.videoworks.adapter.util.PropertiesUtil;
import org.activiti.engine.delegate.DelegateExecution;
import org.activiti.engine.delegate.JavaDelegate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.List;
import java.util.Map;

/**
 * 计算集群下发任务模板类
 * Created by caofeiyi on 2014/7/9.
 */
public abstract class MCClusterSuperSendTask implements JavaDelegate {

    private Logger logger = LoggerFactory.getLogger(MCClusterSuperSendTask.class);

    public void execute(DelegateExecution delegateExecution) {
        try {
            if (isExist(delegateExecution)) {
                delegateExecution.setVariable("currentTaskId", getTaskId(delegateExecution));
                delegateExecution.setVariable("errcode", 0);
                delegateExecution.setVariable("error_msg", "计算集群任务已存在");
                logger.debug("计算集群任务已存在!" + "---" + "任务ID:" + getTaskId(delegateExecution));
            } else {
                MCClusterSendTaskRequestDto requestDto = buildRequest(delegateExecution);
                String requestJson = JsonUtil.format(requestDto);
                String url = "http://" + PropertiesUtil.get("mccluster.ip") + "/task/";
                String responseJson = HttpUtil.httpPost(url, requestJson);
                MCClusterSendTaskResponseDto responseDto = JsonUtil.parse(responseJson, MCClusterSendTaskResponseDto.class);
                if (responseDto.getResult() == 0) {
                    Map<String, Object> variables = setVariables(responseDto);
                    if (variables != null) {
                        delegateExecution.setVariables(variables);
                    }
                    delegateExecution.setVariable("currentTaskId", getTaskId(delegateExecution));
                    delegateExecution.setVariable("errcode", 0);
                    delegateExecution.setVariable("error_msg", "计算集群下发任务成功");
                    logger.debug("计算集群下发任务成功!" + "---" + "请求:" + "(" + requestJson + ")" + "---" + "响应:" + "(" + responseJson + ")");
                } else {
                    delegateExecution.setVariable("errcode", 1);
                    delegateExecution.setVariable("error_msg", "计算集群下发任务失败:" + responseDto.getMessage());
                    logger.debug("计算集群下发任务失败!" + "---" + "请求:" + "(" + requestJson + ")" + "---" + "响应:" + "(" + responseJson + ")");
                }
            }
        } catch (Exception e) {
            logger.error(e.getMessage(), e.fillInStackTrace());
            delegateExecution.setVariable("errcode", 1);
            delegateExecution.setVariable("error_msg", "计算集群下发任务异常");
        }
    }

    public MCClusterSendTaskRequestDto buildRequest(DelegateExecution delegateExecution) throws Exception {
        try {
            Map<String, Object> variables = delegateExecution.getVariables();
            MCClusterSendTaskRequestDto dto = new MCClusterSendTaskRequestDto();
            dto.setId(getTaskId(delegateExecution));
            dto.setName(getTaskName(delegateExecution));
            dto.setType(getType());
            dto.setPriority(getPriority());
            dto.setScheduleTime(null);
            dto.setTemplates(getTemplate(variables));
            dto.setParam(getParam(variables));
            if (dto.getParam() == null) {
                throw new Exception();
            }
            return dto;
        } catch (Exception e) {
            e.printStackTrace();
            throw new AdapterBusinessException();
        }
    }

    public Map<String, Object> setVariables(MCClusterSendTaskResponseDto responseDto) throws Exception {
        return null;
    }

    public abstract Map<String, Object> getParam(Map<String, Object> variables) throws Exception;

    public abstract List<String> getTemplate(Map<String, Object> variables) throws Exception;

    public abstract MCClusterTaskType getType() throws Exception;

    public abstract int getPriority() throws Exception;

    public boolean isExist(DelegateExecution delegateExecution) throws Exception {
        try {
            MCClusterCheckTaskRequestDto requestDto = new MCClusterCheckTaskRequestDto();
            requestDto.setId(getTaskId(delegateExecution));
            String requestJson = JsonUtil.format(requestDto);
            String url = "http://" + PropertiesUtil.get("mccluster.ip") + "/task/status/";
            String responseJson = HttpUtil.httpPost(url, requestJson);
            MCClusterCheckTaskResponseDto responseDto = JsonUtil.parse(responseJson, MCClusterCheckTaskResponseDto.class);
            if (responseDto.getResult() == 0) {
                if (responseDto.getData() != null && responseDto.getData().size() > 0) {
                    return true;
                } else {
                    return false;
                }
            } else {
                throw new AdapterBusinessException("请求异常");
            }
        } catch (HttpException httpException) {
            try {
                Thread.sleep(5000);
                return isExist(delegateExecution);
            } catch (Exception e) {
                throw e;
            }
        } catch (Exception e) {
            throw e;
        }
    }

    public String getTaskId(DelegateExecution delegateExecution) throws Exception {
        return PropertiesUtil.get("taskId.prefix") + "_" + getType().name() + "_" + delegateExecution.getProcessInstanceId();
    }

    public String getTaskName(DelegateExecution delegateExecution) throws Exception {
        return PropertiesUtil.get("taskName.prefix") + "_" + getType().name() + "_" + delegateExecution.getProcessInstanceId();
    }
}
