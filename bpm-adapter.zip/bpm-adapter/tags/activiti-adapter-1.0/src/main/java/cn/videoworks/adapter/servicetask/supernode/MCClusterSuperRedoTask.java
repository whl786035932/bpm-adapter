package cn.videoworks.adapter.servicetask.supernode;

import cn.videoworks.adapter.exception.AdapterBusinessException;
import cn.videoworks.adapter.exception.HttpException;
import cn.videoworks.adapter.servicetask.dto.MCClusterCheckTaskRequestDto;
import cn.videoworks.adapter.servicetask.dto.MCClusterCheckTaskResponseDto;
import cn.videoworks.adapter.servicetask.dto.MCClusterRedoTaskRequestDto;
import cn.videoworks.adapter.servicetask.dto.MCClusterRedoTaskResponseDto;
import cn.videoworks.adapter.servicetask.enumeration.MCClusterTaskStatus;
import cn.videoworks.adapter.servicetask.enumeration.MCClusterTaskType;
import cn.videoworks.adapter.util.HttpUtil;
import cn.videoworks.adapter.util.JsonUtil;
import cn.videoworks.adapter.util.PropertiesUtil;
import org.activiti.engine.delegate.DelegateExecution;
import org.activiti.engine.delegate.JavaDelegate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Map;

/**
 * 计算集群重做任务模板类
 * Created by caofeiyi on 2014/8/19.
 */
public abstract class MCClusterSuperRedoTask implements JavaDelegate {

    private Logger logger = LoggerFactory.getLogger(MCClusterSuperRedoTask.class);

    public void execute(DelegateExecution delegateExecution) {
        try {
            MCClusterTaskStatus status = checkStatus(delegateExecution);
            if (status == MCClusterTaskStatus.SUCCESS || status == MCClusterTaskStatus.NEW || status == MCClusterTaskStatus.HANDOUT) {
                delegateExecution.setVariable("errcode", 0);
                delegateExecution.setVariable("error_msg", "计算集群任务已重做");
                logger.debug("计算集群任务已重做!" + "---" + "任务ID:" + getTaskId(delegateExecution));
            } else if (status == MCClusterTaskStatus.FAILURE) {
                MCClusterRedoTaskRequestDto requestDto = buildRequest(delegateExecution.getVariables());
                String requestJson = JsonUtil.format(requestDto);
                String url = "http://" + PropertiesUtil.get("mccluster.ip") + "/task/" + getTaskId(delegateExecution);
                String responseJson = HttpUtil.httpPut(url, requestJson);
                MCClusterRedoTaskResponseDto responseDto = JsonUtil.parse(responseJson, MCClusterRedoTaskResponseDto.class);
                if (responseDto.getResult() == 0) {
                    Map<String, Object> variables = setVariables(responseDto);
                    if (variables != null) {
                        delegateExecution.setVariables(variables);
                    }
                    delegateExecution.setVariable("errcode", 0);
                    delegateExecution.setVariable("error_msg", "计算集群重做任务成功");
                    logger.debug("计算集群重做任务成功!" + "---" + "请求:" + "(" + requestJson + ")" + "---" + "响应:" + "(" + responseJson + ")");
                } else {
                    delegateExecution.setVariable("errcode", 1);
                    delegateExecution.setVariable("error_msg", "计算集群重做任务失败:" + responseDto.getMessage());
                    logger.debug("计算集群重做任务失败!" + "---" + "请求:" + "(" + requestJson + ")" + "---" + "响应:" + "(" + responseJson + ")");
                }
            } else {
                delegateExecution.setVariable("errcode", 1);
                delegateExecution.setVariable("error_msg", "计算集群重做任务失败");
                logger.debug("计算集群重做任务失败!" + "---" + "任务ID:" + getTaskId(delegateExecution));
            }
        } catch (Exception e) {
            logger.error(e.getMessage(), e.fillInStackTrace());
            delegateExecution.setVariable("errcode", 1);
            delegateExecution.setVariable("error_msg", "计算集群重做任务异常");
        }
    }

    public abstract MCClusterTaskType getType() throws Exception;

    public MCClusterRedoTaskRequestDto buildRequest(Map<String, Object> variables) throws Exception {
        MCClusterRedoTaskRequestDto requestDto = new MCClusterRedoTaskRequestDto();
        requestDto.setAction("restart");
        return requestDto;
    }

    public Map<String, Object> setVariables(MCClusterRedoTaskResponseDto responseDto) throws Exception {
        return null;
    }

    public MCClusterTaskStatus checkStatus(DelegateExecution delegateExecution) throws Exception {
        try {
            MCClusterCheckTaskRequestDto requestDto = new MCClusterCheckTaskRequestDto();
            requestDto.setId(getTaskId(delegateExecution));
            String requestJson = JsonUtil.format(requestDto);
            String url = "http://" + PropertiesUtil.get("mccluster.ip") + "/task/status/";
            String responseJson = HttpUtil.httpPost(url, requestJson);
            MCClusterCheckTaskResponseDto responseDto = JsonUtil.parse(responseJson, MCClusterCheckTaskResponseDto.class);
            if (responseDto.getResult() == 0) {
                if (responseDto.getData() != null && responseDto.getData().size() > 0) {
                    return responseDto.getData().get(0).getStatus();
                } else {
                    return null;
                }
            } else {
                throw new AdapterBusinessException("请求异常");
            }
        } catch (HttpException httpException) {
            try {
                Thread.sleep(5000);
                return checkStatus(delegateExecution);
            } catch (Exception e) {
                throw e;
            }
        } catch (Exception e) {
            throw e;
        }
    }

    public String getTaskId(DelegateExecution delegateExecution) throws Exception {
        return PropertiesUtil.get("taskId.prefix") + "_" + getType().name() + "_" + delegateExecution.getProcessInstanceId();
    }
}
