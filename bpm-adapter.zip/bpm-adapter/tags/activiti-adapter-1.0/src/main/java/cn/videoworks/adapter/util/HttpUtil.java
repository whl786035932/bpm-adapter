package cn.videoworks.adapter.util;

import cn.videoworks.adapter.exception.HttpException;
import org.apache.http.HttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.methods.HttpPut;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.DefaultHttpClient;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;

/**
 * Created by caofeiyi on 2014/7/7.
 */
public class HttpUtil {

    Logger logger = LoggerFactory.getLogger(HttpUtil.class);

    /**
     * 发送POST请求
     *
     * @param url
     * @param request
     * @return
     * @throws HttpException
     */
    public static String httpPost(String url, String request) throws HttpException {
        try {
            DefaultHttpClient httpClient = new DefaultHttpClient();
            HttpPost postRequest = new HttpPost(url);
            StringEntity input = new StringEntity(request, "UTF-8");
            input.setContentType("application/json;charset=UTF-8");
            postRequest.setEntity(input);
            HttpResponse response = httpClient.execute(postRequest);
            InputStream is = response.getEntity().getContent();
            BufferedReader in = new BufferedReader(new InputStreamReader(is));
            StringBuffer buffer = new StringBuffer();
            String line = "";
            while ((line = in.readLine()) != null) {
                buffer.append(line);
            }
            return buffer.toString();
        } catch (Exception e) {
            throw new HttpException("网络连接异常", e.fillInStackTrace());
        }
    }

    /**
     * 发送PUT请求
     *
     * @param url
     * @param request
     * @return
     * @throws HttpException
     */
    public static String httpPut(String url, String request) throws HttpException {
        try {
            DefaultHttpClient httpClient = new DefaultHttpClient();
            HttpPut putRequest = new HttpPut(url);
            StringEntity input = new StringEntity(request, "UTF-8");
            input.setContentType("application/json;charset=UTF-8");
            putRequest.setEntity(input);
            HttpResponse response = httpClient.execute(putRequest);
            InputStream is = response.getEntity().getContent();
            BufferedReader in = new BufferedReader(new InputStreamReader(is));
            StringBuffer buffer = new StringBuffer();
            String line = "";
            while ((line = in.readLine()) != null) {
                buffer.append(line);
            }
            return buffer.toString();
        } catch (Exception e) {
            throw new HttpException("网络连接异常", e.fillInStackTrace());
        }
    }
}
