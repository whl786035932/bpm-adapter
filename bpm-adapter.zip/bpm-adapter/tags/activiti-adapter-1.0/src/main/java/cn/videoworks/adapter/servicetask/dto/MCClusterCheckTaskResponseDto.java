package cn.videoworks.adapter.servicetask.dto;

import java.util.List;

/**
 * Created by caofeiyi on 2014/7/7.
 */
public class MCClusterCheckTaskResponseDto {
    private int result;
    private String message;
    private int total;
    private List<MCClusterCheckTaskResponseDataDto> data;

    public int getResult() {
        return result;
    }

    public void setResult(int result) {
        this.result = result;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public int getTotal() {
        return total;
    }

    public void setTotal(int total) {
        this.total = total;
    }

    public List<MCClusterCheckTaskResponseDataDto> getData() {
        return data;
    }

    public void setData(List<MCClusterCheckTaskResponseDataDto> data) {
        this.data = data;
    }
}
