package cn.videoworks.adapter.servicetask.supernode;

import cn.videoworks.adapter.exception.AdapterBusinessException;
import cn.videoworks.adapter.servicetask.dto.ApplicationActualTaskRequestDto;
import cn.videoworks.adapter.servicetask.dto.ApplicationActualTaskResponseDto;
import cn.videoworks.adapter.servicetask.enumeration.ApplicationActualTaskResult;
import cn.videoworks.adapter.servicetask.enumeration.ApplicationActualTaskType;
import cn.videoworks.adapter.util.HttpUtil;
import cn.videoworks.adapter.util.JsonUtil;
import cn.videoworks.adapter.util.PropertiesUtil;
import org.activiti.engine.delegate.DelegateExecution;
import org.activiti.engine.delegate.JavaDelegate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Map;

/**
 * 应用系统实时任务模板类
 * Created by caofeiyi on 2014/8/1.
 */
public abstract class ApplicationSuperActualTask implements JavaDelegate {

    private Logger logger = LoggerFactory.getLogger(ApplicationSuperActualTask.class);

    public void execute(DelegateExecution delegateExecution) {
        try {
            ApplicationActualTaskRequestDto requestDto = buildRequest(delegateExecution);
            String requestJson = JsonUtil.format(requestDto);
            String url = "http://" + PropertiesUtil.get("application.ip") + "/workflowAutoTask/" + getType().name();
            String responseJson = HttpUtil.httpPost(url, requestJson);
            ApplicationActualTaskResponseDto responseDto = JsonUtil.parse(responseJson, ApplicationActualTaskResponseDto.class);
            if (responseDto.getStatusCode() == 200) {
                if (responseDto.getData().getResult() == ApplicationActualTaskResult.SUCCESS) {
                    Map<String, String> variables = setVariables(responseDto);
                    if (variables != null) {
                        delegateExecution.setVariables(variables);
                    }
                    delegateExecution.setVariable("errcode", 0);
                    delegateExecution.setVariable("error_msg", "任务成功");
                    logger.debug("任务成功!" + "---" + "请求:" + "(" + requestJson + ")" + "---" + "响应:" + "(" + responseJson + ")");
                } else {
                    delegateExecution.setVariable("errcode", 1);
                    delegateExecution.setVariable("error_msg", "任务失败:" + responseDto.getData().getResultMessage());
                    logger.debug("任务失败!" + "---" + "请求:" + "(" + requestJson + ")" + "---" + "响应:" + "(" + responseJson + ")");
                }
            } else {
                throw new AdapterBusinessException("请求异常");
            }
        } catch (Exception e) {
            logger.error(e.getMessage(), e.fillInStackTrace());
            delegateExecution.setVariable("errcode", 1);
            delegateExecution.setVariable("error_msg", "任务异常");
        }
    }

    public abstract ApplicationActualTaskType getType() throws Exception;

    public ApplicationActualTaskRequestDto buildRequest(DelegateExecution delegateExecution) throws Exception {
        ApplicationActualTaskRequestDto dto = new ApplicationActualTaskRequestDto();
        dto.setId(delegateExecution.getProcessInstanceId());
        dto.setData(delegateExecution.getVariables());
        return dto;
    }

    public Map<String, String> setVariables(ApplicationActualTaskResponseDto responseDto) throws Exception {
        return responseDto.getData().getData();
    }
}
