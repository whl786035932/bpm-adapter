package cn.videoworks.adapter.servicetask.dto;

import cn.videoworks.adapter.servicetask.enumeration.MCClusterTaskType;

import java.util.List;
import java.util.Map;

/**
 * Created by caofeiyi on 2014/7/7.
 */
public class MCClusterSendTaskRequestDto {
    private String id;
    private String name;
    private MCClusterTaskType type;
    private List<String> templates;
    private Integer priority;
    private String scheduleTime;
    private Map<String, Object> param;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public MCClusterTaskType getType() {
        return type;
    }

    public void setType(MCClusterTaskType type) {
        this.type = type;
    }

    public List<String> getTemplates() {
        return templates;
    }

    public void setTemplates(List<String> templates) {
        this.templates = templates;
    }

    public Integer getPriority() {
        return priority;
    }

    public void setPriority(Integer priority) {
        this.priority = priority;
    }

    public String getScheduleTime() {
        return scheduleTime;
    }

    public void setScheduleTime(String scheduleTime) {
        this.scheduleTime = scheduleTime;
    }

    public Map<String, Object> getParam() {
        return param;
    }

    public void setParam(Map<String, Object> param) {
        this.param = param;
    }
}
