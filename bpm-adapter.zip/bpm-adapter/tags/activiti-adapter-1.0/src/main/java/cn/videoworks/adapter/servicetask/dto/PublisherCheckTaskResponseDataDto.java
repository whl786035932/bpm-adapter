package cn.videoworks.adapter.servicetask.dto;

import java.util.List;

/**
 * Created by caofeiyi on 2014/7/14.
 */
public class PublisherCheckTaskResponseDataDto {
    private List<PublisherCheckTaskResponseTaskDto> taskList;

    public List<PublisherCheckTaskResponseTaskDto> getTaskList() {
        return taskList;
    }

    public void setTaskList(List<PublisherCheckTaskResponseTaskDto> taskList) {
        this.taskList = taskList;
    }
}
