package cn.videoworks.adapter.exception;

/**
 * Created by caofeiyi on 2014/7/8.
 */
public class JsonException extends Exception {
    public JsonException() {
    }

    public JsonException(String message) {
        super(message);
    }

    public JsonException(Throwable cause) {
        super(cause);
    }

    public JsonException(String message, Throwable cause) {
        super(message, cause);
    }


    public JsonException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
        super(message, cause, enableSuppression, writableStackTrace);
    }
}
