package cn.videoworks.adapter.servicetask.dto;

import cn.videoworks.adapter.servicetask.enumeration.MCClusterTaskStatus;
import cn.videoworks.adapter.servicetask.enumeration.MCClusterTaskType;

import java.util.List;
import java.util.Map;

/**
 * Created by caofeiyi on 2014/7/8.
 */
public class MCClusterCheckTaskResponseDataDto {
    private String id;
    private String name;
    private MCClusterTaskType type;
    private List<String> templates;
    private Map<String, Object> param;
    private MCClusterTaskStatus status;
    private float progress;
    private int priority;
    private String createTime;
    private String scheduleTime;
    private Object info;
    private Map<String, Object> result;
    private String startTime;
    private String endTime;
    private String workshopName;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public MCClusterTaskType getType() {
        return type;
    }

    public void setType(MCClusterTaskType type) {
        this.type = type;
    }

    public List<String> getTemplates() {
        return templates;
    }

    public void setTemplates(List<String> templates) {
        this.templates = templates;
    }

    public Map<String, Object> getParam() {
        return param;
    }

    public void setParam(Map<String, Object> param) {
        this.param = param;
    }

    public MCClusterTaskStatus getStatus() {
        return status;
    }

    public void setStatus(MCClusterTaskStatus status) {
        this.status = status;
    }

    public float getProgress() {
        return progress;
    }

    public void setProgress(float progress) {
        this.progress = progress;
    }

    public int getPriority() {
        return priority;
    }

    public void setPriority(int priority) {
        this.priority = priority;
    }

    public String getCreateTime() {
        return createTime;
    }

    public void setCreateTime(String createTime) {
        this.createTime = createTime;
    }

    public String getScheduleTime() {
        return scheduleTime;
    }

    public void setScheduleTime(String scheduleTime) {
        this.scheduleTime = scheduleTime;
    }

    public Object getInfo() {
        return info;
    }

    public void setInfo(Object info) {
        this.info = info;
    }

    public Map<String, Object> getResult() {
        return result;
    }

    public void setResult(Map<String, Object> result) {
        this.result = result;
    }

    public String getStartTime() {
        return startTime;
    }

    public void setStartTime(String startTime) {
        this.startTime = startTime;
    }

    public String getEndTime() {
        return endTime;
    }

    public void setEndTime(String endTime) {
        this.endTime = endTime;
    }

    public String getWorkshopName() {
        return workshopName;
    }

    public void setWorkshopName(String workshopName) {
        this.workshopName = workshopName;
    }
}
