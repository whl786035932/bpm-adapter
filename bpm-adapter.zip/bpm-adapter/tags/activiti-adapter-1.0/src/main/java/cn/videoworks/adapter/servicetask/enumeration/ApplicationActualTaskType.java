package cn.videoworks.adapter.servicetask.enumeration;

public enum ApplicationActualTaskType {
    vfAddReview,        //视频工厂_增加审核
    vfShipOrder,        //视频工厂_更新切片状态
    vfImportUpdate,     //视频工厂_导入更新数据
    vfInfoUpdate,       //视频工厂_更新数据
    mamImport,          //媒资_媒资导入
    mamStatus,          //媒资_更新媒资状态
    mamUpdateMetadata,  //媒资_更新媒资
    mamDeleteMetadata,  //媒资_删除媒资
    mamSearchIndex,     //媒资_同步搜索引擎
    mamSetCatalog,      //媒资_写入编目信息
    mamReport,          //媒资_通知相关人员
    vfSyncCutInfo	//同步切点帧信息到vfCenter
}
