package cn.videoworks.adapter.servicetask.node;

import cn.videoworks.adapter.servicetask.enumeration.MCClusterTaskType;
import cn.videoworks.adapter.servicetask.supernode.MCClusterSuperSendTask;

import java.util.*;

public class MCClusterWriteFileSend extends MCClusterSuperSendTask {

    public Map<String, Object> getParam(Map<String, Object> variables) throws Exception {
        Map<String, Object> paramMap = new HashMap<String, Object>();
        Iterator<Map.Entry<String, Object>> iter = variables.entrySet().iterator();
        while (iter.hasNext()) {
            Map.Entry entry = (Map.Entry) iter.next();
            String key = (String) entry.getKey();
            Object val = entry.getValue();
            if (key.equals("file")) {
                paramMap.put("file", (String) val);
            } else if (key.equals("content")) {
                paramMap.put("content", (String) val);
            }
        }
        if (paramMap.containsKey("file") && paramMap.containsKey("content")) {
            return paramMap;
        } else {
            return null;
        }
    }

    public List<String> getTemplate(Map<String, Object> variables) throws Exception {
        return new LinkedList<String>();
    }

    public MCClusterTaskType getType() throws Exception {
        return MCClusterTaskType.WriteFile;
    }

    public int getPriority() throws Exception {
        return 10;
    }
}