package cn.videoworks.adapter.servicetask.node;

import cn.videoworks.adapter.servicetask.enumeration.MCClusterTaskType;
import cn.videoworks.adapter.servicetask.supernode.MCClusterSuperRedoTask;

public class MCClusterLocateFrame4ImageRedo extends MCClusterSuperRedoTask {
    public MCClusterTaskType getType() throws Exception {
        return MCClusterTaskType.LocateFrame;
    }
}
