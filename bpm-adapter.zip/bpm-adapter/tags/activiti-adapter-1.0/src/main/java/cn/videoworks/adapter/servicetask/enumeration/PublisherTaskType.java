package cn.videoworks.adapter.servicetask.enumeration;

/**
 * Created by caofeiyi on 2014/7/14.
 */
public enum PublisherTaskType {
    add //增加
}
