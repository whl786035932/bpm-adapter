package cn.videoworks.adapter.servicetask.supernode;

import cn.videoworks.adapter.exception.AdapterBusinessException;
import cn.videoworks.adapter.exception.HttpException;
import cn.videoworks.adapter.servicetask.dto.PublisherCheckTaskRequestDto;
import cn.videoworks.adapter.servicetask.dto.PublisherCheckTaskResponseDto;
import cn.videoworks.adapter.servicetask.dto.PublisherCheckTaskResponseTaskDto;
import cn.videoworks.adapter.util.HttpUtil;
import cn.videoworks.adapter.util.JsonUtil;
import cn.videoworks.adapter.util.PropertiesUtil;
import org.activiti.engine.delegate.DelegateExecution;
import org.activiti.engine.delegate.JavaDelegate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Map;

public abstract class PublisherSuperCheckTask implements JavaDelegate {

    private Logger logger = LoggerFactory.getLogger(PublisherSuperCheckTask.class);

    public void execute(DelegateExecution delegateExecution) {
        try {
            PublisherCheckTaskRequestDto requestDto = buildRequest(delegateExecution.getVariables());
            String requestJson = JsonUtil.format(requestDto);
            String url = "http://" + PropertiesUtil.get("publisher.ip") + "/task/list";
            String responseJson = HttpUtil.httpPost(url, requestJson);
            PublisherCheckTaskResponseDto responseDto = JsonUtil.parse(responseJson, PublisherCheckTaskResponseDto.class);
            if (responseDto.getStatusCode() == 200) {
                if (responseDto.getData().getTaskList().get(0).getStatus() == 2) {
                    Map<String, String> variables = setVariables(responseDto.getData().getTaskList().get(0));
                    if (variables != null) {
                        delegateExecution.setVariables(variables);
                    }
                    delegateExecution.setVariable("errcode", 0);
                    delegateExecution.setVariable("error_msg", "发布系统任务成功");
                    logger.debug("发布系统任务成功!" + "---" + "请求:" + "(" + requestJson + ")" + "---" + "响应:" + "(" + responseJson + ")");
                } else if (responseDto.getData().getTaskList().get(0).getStatus() == -1 || responseDto.getData().getTaskList().get(0).getStatus() == -2) {
                    delegateExecution.setVariable("errcode", 1);
                    delegateExecution.setVariable("error_msg", "发布系统任务失败:" + responseDto.getData().getTaskList().get(0).getMessage());
                    logger.debug("发布系统任务失败!" + "---" + "请求:" + "(" + requestJson + ")" + "---" + "响应:" + "(" + responseJson + ")");
                } else {
                    delegateExecution.setVariable("errcode", 2);
                }
            } else {
                throw new AdapterBusinessException("请求异常");
            }
        } catch (HttpException e) {
            logger.error(e.getMessage(), e.fillInStackTrace());
            delegateExecution.setVariable("errcode", 2);
        } catch (Exception e) {
            logger.error(e.getMessage(), e.fillInStackTrace());
            delegateExecution.setVariable("errcode", 1);
            delegateExecution.setVariable("error_msg", "发布系统任务异常");
        }
    }

    public PublisherCheckTaskRequestDto buildRequest(Map<String, Object> variables) throws Exception {
        PublisherCheckTaskRequestDto dto = new PublisherCheckTaskRequestDto();
        dto.setTaskId(String.valueOf(variables.get("currentTaskId")));
        return dto;
    }

    public abstract Map<String, String> setVariables(PublisherCheckTaskResponseTaskDto responseTaskDto) throws Exception;
}
