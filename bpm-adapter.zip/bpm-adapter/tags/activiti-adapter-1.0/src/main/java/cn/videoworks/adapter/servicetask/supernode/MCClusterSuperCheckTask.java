package cn.videoworks.adapter.servicetask.supernode;

import cn.videoworks.adapter.exception.AdapterBusinessException;
import cn.videoworks.adapter.exception.HttpException;
import cn.videoworks.adapter.servicetask.dto.MCClusterCheckTaskRequestDto;
import cn.videoworks.adapter.servicetask.dto.MCClusterCheckTaskResponseDto;
import cn.videoworks.adapter.servicetask.enumeration.MCClusterTaskStatus;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.HashMap;
import java.util.Map;

/**
 * 计算集群监测任务状态模板类
 * Created by caofeiyi on 2014/7/9.
 */
public abstract class MCClusterSuperCheckTask extends MCClusterSuperCheck {

    private Logger logger = LoggerFactory.getLogger(MCClusterSuperCheckTask.class);

    public MCClusterCheckTaskRequestDto buildRequest(Map<String, Object> variables) throws Exception {
        MCClusterCheckTaskRequestDto dto = new MCClusterCheckTaskRequestDto();
        dto.setId(String.valueOf(variables.get("currentTaskId")));
        return dto;
    }

    public Map<String, Object> setVariables(MCClusterCheckTaskResponseDto responseDto, String requestJson, String responseJson) throws Exception {
        Map<String, Object> variables = new HashMap<String, Object>();
        if (responseDto.getResult() == 0) {
            if (responseDto.getData().get(0).getStatus() == MCClusterTaskStatus.SUCCESS) {
                Map<String, String> output = getOutput(responseDto.getData().get(0).getResult());
                if (output != null) {
                    variables.putAll(output);
                }
                variables.put("errcode", 0);
                variables.put("error_msg", "计算集群任务成功");
                logger.debug("计算集群任务成功!" + "---" + "请求:" + "(" + requestJson + ")" + "---" + "响应:" + "(" + responseJson + ")");
            } else if (responseDto.getData().get(0).getStatus() == MCClusterTaskStatus.FAILURE || responseDto.getData().get(0).getStatus() == MCClusterTaskStatus.DELETED) {
                variables.put("taskErrorCode", responseDto.getData().get(0).getResult().get("result"));
                variables.put("errcode", 1);
                variables.put("error_msg", "计算集群任务失败:" + responseDto.getData().get(0).getResult().get("message"));
                logger.debug("计算集群任务失败!" + "---" + "请求:" + "(" + requestJson + ")" + "---" + "响应:" + "(" + responseJson + ")");
            } else {
                variables.put("errcode", 2);
            }
        } else {
            throw new AdapterBusinessException("请求异常");
        }
        return variables;
    }

    public Map<String, Object> setErrorVariables(Exception exception) {
        Map<String, Object> variables = new HashMap<String, Object>();
        if (exception instanceof HttpException) {
            logger.error(exception.getMessage(), exception.fillInStackTrace());
            variables.put("errcode", 2);
        } else {
            logger.error(exception.getMessage(), exception.fillInStackTrace());
            variables.put("errcode", 1);
            variables.put("error_msg", "计算集群任务异常");
        }
        return variables;
    }

    public abstract Map<String, String> getOutput(Map<String, Object> map) throws Exception;
}
