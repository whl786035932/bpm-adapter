package cn.videoworks.adapter.servicetask.dto;

/**
 * Created by caofeiyi on 2014/8/19.
 */
public class MCClusterRedoTaskResponseDto {
    private int result;
    private String message;

    public int getResult() {
        return result;
    }

    public void setResult(int result) {
        this.result = result;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }
}
