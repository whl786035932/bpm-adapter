package cn.videoworks.adapter.servicetask.supernode;

import cn.videoworks.adapter.exception.AdapterBusinessException;
import cn.videoworks.adapter.exception.HttpException;
import cn.videoworks.adapter.servicetask.dto.PublisherCheckTaskRequestDto;
import cn.videoworks.adapter.servicetask.dto.PublisherCheckTaskResponseDto;
import cn.videoworks.adapter.servicetask.dto.PublisherSendTaskRequestDto;
import cn.videoworks.adapter.servicetask.dto.PublisherSendTaskResponseDto;
import cn.videoworks.adapter.servicetask.enumeration.PublisherTaskType;
import cn.videoworks.adapter.util.HttpUtil;
import cn.videoworks.adapter.util.JsonUtil;
import cn.videoworks.adapter.util.PropertiesUtil;
import org.activiti.engine.delegate.DelegateExecution;
import org.activiti.engine.delegate.JavaDelegate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Map;

public abstract class PublisherSuperSendTask implements JavaDelegate {

    private Logger logger = LoggerFactory.getLogger(PublisherSuperSendTask.class);

    public void execute(DelegateExecution delegateExecution) {
        try {
            if (isExist(delegateExecution)) {
                delegateExecution.setVariable("currentTaskId", getTaskId(delegateExecution));
                delegateExecution.setVariable("errcode", 0);
                delegateExecution.setVariable("error_msg", "发布系统任务已存在");
                logger.debug("发布系统任务已存在!" + "---" + "任务ID:" + getTaskId(delegateExecution));
            } else {
                PublisherSendTaskRequestDto requestDto = buildRequest(delegateExecution);
                String requestJson = JsonUtil.format(requestDto);
                String url = "http://" + PropertiesUtil.get("publisher.ip") + "/task/" + getTaskType().name();
                String responseJson = HttpUtil.httpPost(url, requestJson);
                PublisherSendTaskResponseDto responseDto = JsonUtil.parse(responseJson, PublisherSendTaskResponseDto.class);
                if (responseDto.getStatusCode() == 200) {
                    Map<String, Object> variables = setVariables(responseDto);
                    if (variables != null) {
                        delegateExecution.setVariables(variables);
                    }
                    delegateExecution.setVariable("currentTaskId", getTaskId(delegateExecution));
                    delegateExecution.setVariable("errcode", 0);
                    delegateExecution.setVariable("error_msg", "发布系统下发任务成功");
                    logger.debug("发布系统下发任务成功!" + "---" + "请求:" + "(" + requestJson + ")" + "---" + "响应:" + "(" + responseJson + ")");
                } else {
                    delegateExecution.setVariable("errcode", 1);
                    delegateExecution.setVariable("error_msg", "发布系统下发任务失败:" + responseDto.getMessage());
                    logger.debug("发布系统下发任务失败!" + "---" + "请求:" + "(" + requestJson + ")" + "---" + "响应:" + "(" + responseJson + ")");
                }
            }
        } catch (Exception e) {
            logger.error(e.getMessage(), e.fillInStackTrace());
            delegateExecution.setVariable("errcode", 1);
            delegateExecution.setVariable("error_msg", "发布系统下发任务异常");
        }
    }

    public PublisherSendTaskRequestDto buildRequest(DelegateExecution delegateExecution) throws Exception {
        Map<String, Object> variables = delegateExecution.getVariables();
        PublisherSendTaskRequestDto dto = new PublisherSendTaskRequestDto();
        dto.setTaskId(getTaskId(delegateExecution));
        dto.setName(getTaskName(delegateExecution));
        dto.setCatalogInfo(getCatalogInfo(variables));
        dto.setCustomer(getCustomer(variables));
        dto.setVideoName(getVideoName(variables));
        dto.setStrategy(getStrategy(variables));
        dto.setPriority(getPriority());
        return dto;
    }

    public Map<String, Object> setVariables(PublisherSendTaskResponseDto responseDto) throws Exception {
        return null;
    }

    public abstract String getNameSurfix() throws Exception;

    public abstract PublisherTaskType getTaskType() throws Exception;

    public abstract int getPriority() throws Exception;

    public abstract String getCustomer(Map<String, Object> variables) throws Exception;

    public abstract String getCatalogInfo(Map<String, Object> variables) throws Exception;

    public abstract String getVideoName(Map<String, Object> variables) throws Exception;

    public abstract String getStrategy(Map<String, Object> variables) throws Exception;

    public boolean isExist(DelegateExecution delegateExecution) throws Exception {
        try {
            PublisherCheckTaskRequestDto requestDto = new PublisherCheckTaskRequestDto();
            requestDto.setTaskId(getTaskId(delegateExecution));
            String requestJson = JsonUtil.format(requestDto);
            String url = "http://" + PropertiesUtil.get("publisher.ip") + "/task/list";
            String responseJson = HttpUtil.httpPost(url, requestJson);
            PublisherCheckTaskResponseDto responseDto = JsonUtil.parse(responseJson, PublisherCheckTaskResponseDto.class);
            if (responseDto.getStatusCode() == 200) {
                if (responseDto.getData() != null && responseDto.getData().getTaskList() != null && responseDto.getData().getTaskList().size() > 0) {
                    return true;
                } else {
                    return false;
                }
            } else {
                throw new AdapterBusinessException("请求异常");
            }
        } catch (HttpException httpException) {
            try {
                Thread.sleep(5000);
                return isExist(delegateExecution);
            } catch (Exception e) {
                throw e;
            }
        } catch (Exception e) {
            throw e;
        }
    }

    public String getTaskId(DelegateExecution delegateExecution) throws Exception {
        return PropertiesUtil.get("taskId.prefix") + "_" + getNameSurfix() + "_" + delegateExecution.getProcessInstanceId();
    }

    public String getTaskName(DelegateExecution delegateExecution) throws Exception {
        return PropertiesUtil.get("taskName.prefix") + "_" + getNameSurfix() + "_" + delegateExecution.getProcessInstanceId();
    }
}
