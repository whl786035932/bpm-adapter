package cn.videoworks.adapter.servicetask.node;

import cn.videoworks.adapter.servicetask.enumeration.MCClusterTaskType;
import cn.videoworks.adapter.servicetask.supernode.MCClusterSuperSendTask;
import cn.videoworks.adapter.util.JsonUtil;

import java.util.*;
import java.util.Map.Entry;

public class MCClusterCutSend extends MCClusterSuperSendTask {

    public Map<String, Object> getParam(Map<String, Object> variables) throws Exception {
        Map<String, Object> paramMap = new HashMap<String, Object>();
        List<Map<String, Object>> inputList = new LinkedList<Map<String, Object>>();
        Map<String, Object> inputEntity = new HashMap<String, Object>();
        Iterator<Entry<String, Object>> iter = variables.entrySet().iterator();
        while (iter.hasNext()) {
            Map.Entry entry = (Map.Entry) iter.next();
            String key = (String) entry.getKey();
            Object val = entry.getValue();
            if (key.equals("cut_frames")) {
                String frames = (String) val;
                List<Map<String, Object>> list = JsonUtil.parse(
                        frames, LinkedList.class);
                List<Map<String, Object>> cutpoints = getCutPoint(list);
                if (cutpoints == null) return null;
                inputEntity.put("cutpoints", cutpoints);
                inputList.add(inputEntity);
                paramMap.put("input", inputList);
            } else if (key.equals("template")) {
                String template = (String) val;
                paramMap.put("template", template);
            } else if (key.equals("video_url")) {
                String videoUrl = (String) val;
                inputEntity.put("filename", videoUrl);
            } else if (key.equals("out_video_url")) {
                String output = (String) val;
                paramMap.put("output", output);
            }
        }
        if (paramMap.containsKey("input") && paramMap.containsKey("template")
                && paramMap.containsKey("output")) {
            return paramMap;
        } else {
            return null;
        }
    }


    public List<String> getTemplate(Map<String, Object> variables) throws Exception {
        List<String> list = new LinkedList<String>();
        String template = (String) variables.get("template");
        if (template == null) return list;
        list.add(template);
        return list;
    }

    public MCClusterTaskType getType() throws Exception {
        return MCClusterTaskType.Cut;
    }

    public int getPriority() throws Exception {
        return 10;
    }

    private List<Map<String, Object>> getCutPoint(List<Map<String, Object>> list) throws Exception {
        if (list.size() % 2 != 0) return null;
        List<Map<String, Object>> cutpoints = new LinkedList<Map<String, Object>>();
        int length = list.size() / 2;
        for (int i = 0; i < length; i++) {
            Map<String, Object> map = new HashMap<String, Object>();
            Number num1 = (Number) list.get(2 * i).get("frame");
            Number num2 = (Number) list.get(2 * i + 1).get("frame");
            long startFrame = num1.longValue();
            long endFrame = num2.longValue();
            if (startFrame >= endFrame) return null;
            map.put("start_frame", startFrame);
            map.put("end_frame", endFrame);
            cutpoints.add(map);
        }
        return cutpoints;
    }

}