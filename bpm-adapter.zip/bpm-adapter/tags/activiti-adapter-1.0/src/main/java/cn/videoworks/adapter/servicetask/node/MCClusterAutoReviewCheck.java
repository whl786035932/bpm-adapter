package cn.videoworks.adapter.servicetask.node;

import cn.videoworks.adapter.servicetask.supernode.MCClusterSuperCheckTask;
import cn.videoworks.adapter.util.JsonUtil;

import java.math.BigDecimal;
import java.util.*;

public class MCClusterAutoReviewCheck extends MCClusterSuperCheckTask {

    public Map<String, String> getOutput(Map<String, Object> map) throws Exception {
        Map<String, String> variables = new HashMap<String, String>();
        List<MaExamineResult> listRes = change2MaExamineResult((Map<String, Object>) map.get("message"));
        variables.put("out_examineinfo", JsonUtil.format(listRes));
        return variables;
    }

    private List<MaExamineResult> change2MaExamineResult(Map<String, Object> res) throws Exception {
        List<MaExamineResult> listRes = new LinkedList<MaExamineResult>();
        if (res.containsKey("exception_info")) {
            Map<String, Object> exceptionInfo = (Map<String, Object>) res.get("exception_info");
            Iterator<Map.Entry<String, Object>> iter = exceptionInfo.entrySet().iterator();
            while (iter.hasNext()) {
                Map.Entry entry = (Map.Entry) iter.next();
                String key = (String) entry.getKey();
                Object val = entry.getValue();

                MaExamineResult result = new MaExamineResult();
                result.setExamineType(getExamineType(key));
                if (val == null) {
                } else {
                    List<Map<String, Object>> entity = (List<Map<String, Object>>) val;
                    List<Map<String, Long>> defectTime = new LinkedList<Map<String, Long>>();
                    for (Map<String, Object> map : entity) {
                        Map<String, Long> e = new HashMap<String, Long>();
                        Object val1 = map.get("start_time");
                        Object val2 = map.get("end_time");
                        e.put("startTime", new BigDecimal(String.valueOf((val1.toString()))).longValue());
                        e.put("endTime", new BigDecimal(String.valueOf((val2.toString()))).longValue());
                        defectTime.add(e);
                    }
                    result.setDefectTime(defectTime);
                }
                listRes.add(result);
            }
        }
        return listRes;
    }

    private ExamineType getExamineType(String str) throws Exception {
        if (str.equals("audio_mute"))
            return ExamineType.AUDIO_MUTE;
        else if (str.equals("black_filed"))
            return ExamineType.BLACK_FILED;
        else if (str.equals("still_frame"))
            return ExamineType.STILL_FRAME;
        else
            return ExamineType.COLOR_BAR;
    }

    private enum ExamineType {
        // 静音,黑场,静帧,彩条
        AUDIO_MUTE,
        BLACK_FILED,
        STILL_FRAME,
        COLOR_BAR
    }

    private class MaExamineResult {
        /**
         * 计审类型
         */
        private ExamineType examineType;

        /**
         * 问题帧对应的帧号
         */
        private List<Long> defectFrame = new LinkedList<Long>();

        /**
         * 问题时段 (在计审类型是AUDIO_MUTE,取问题时段)
         */
        private List<Map<String, Long>> defectTime = new LinkedList<Map<String, Long>>();

        /**
         * @return the examineType
         */
        public ExamineType getExamineType() {
            return examineType;
        }

        /**
         * @param examineType the examineType to set
         */
        public void setExamineType(ExamineType examineType) {
            this.examineType = examineType;
        }

        /**
         * @return the defectFrame
         */
        public List<Long> getDefectFrame() {
            return defectFrame;
        }

        /**
         * @param defectFrame the defectFrame to set
         */
        public void setDefectFrame(List<Long> defectFrame) {
            this.defectFrame = defectFrame;
        }

        /**
         * @return the defectTime
         */
        public List<Map<String, Long>> getDefectTime() {
            return defectTime;
        }

        /**
         * @param defectTime the defectTime to set
         */
        public void setDefectTime(List<Map<String, Long>> defectTime) {
            this.defectTime = defectTime;
        }
    }
}