package cn.videoworks.adapter.servicetask.dto;

import cn.videoworks.adapter.servicetask.enumeration.ApplicationActualTaskResult;

import java.util.Map;

public class ApplicationActualTaskResponseDataDto {
    private ApplicationActualTaskResult result;
    private String resultMessage;
    private Map<String, String> data;

    public ApplicationActualTaskResult getResult() {
        return result;
    }

    public void setResult(ApplicationActualTaskResult result) {
        this.result = result;
    }

    public String getResultMessage() {
        return resultMessage;
    }

    public void setResultMessage(String resultMessage) {
        this.resultMessage = resultMessage;
    }

    public Map<String, String> getData() {
        return data;
    }

    public void setData(Map<String, String> data) {
        this.data = data;
    }
}
