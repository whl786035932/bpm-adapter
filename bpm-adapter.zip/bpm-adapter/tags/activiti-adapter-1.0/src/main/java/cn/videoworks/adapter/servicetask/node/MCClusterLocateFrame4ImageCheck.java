package cn.videoworks.adapter.servicetask.node;

import cn.videoworks.adapter.servicetask.supernode.MCClusterSuperCheckTask;
import cn.videoworks.adapter.util.JsonUtil;

import java.util.HashMap;
import java.util.Map;

public class MCClusterLocateFrame4ImageCheck extends MCClusterSuperCheckTask {

    public Map<String, String> getOutput(Map<String, Object> map) throws Exception {
        Map<String, String> variables = new HashMap<String, String>();
        variables.put("out_frame", JsonUtil.format(((Map) map.get("message")).get("frameinfo")));
        return variables;
    }
}
