package cn.videoworks.adapter.servicetask.node;

import cn.videoworks.adapter.servicetask.dto.PublisherCheckTaskResponseTaskDto;
import cn.videoworks.adapter.servicetask.supernode.PublisherSuperCheckTask;

import java.util.Map;

public class PublisherDeployCheck extends PublisherSuperCheckTask {

    public Map<String, String> setVariables(PublisherCheckTaskResponseTaskDto responseTaskDto) throws Exception {
        return null;
    }
}
