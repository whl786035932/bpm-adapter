package cn.videoworks.adapter.servicetask.dto;

import cn.videoworks.adapter.servicetask.enumeration.MCClusterTaskStatus;
import cn.videoworks.adapter.servicetask.enumeration.MCClusterTaskType;

import java.util.List;

/**
 * Created by caofeiyi on 2014/7/7.
 */
public class MCClusterCheckTaskRequestDto {
    private String id;
    private String name;
    private String workshopId;
    private MCClusterTaskType type;
    private List<MCClusterTaskStatus> states;
    private Integer priority;
    private String createTimeBegin;
    private String createTimeEnd;
    private String scheduleTimeBegin;
    private String scheduleTimeEnd;
    private String startTimeBegin;
    private String startTimeEnd;
    private String endTimeBegin;
    private String endTimeEnd;
    private String orderBy;
    private boolean isAsc;
    private int currentPage;
    private int pageSize;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getWorkshopId() {
        return workshopId;
    }

    public void setWorkshopId(String workshopId) {
        this.workshopId = workshopId;
    }

    public MCClusterTaskType getType() {
        return type;
    }

    public void setType(MCClusterTaskType type) {
        this.type = type;
    }

    public List<MCClusterTaskStatus> getStates() {
        return states;
    }

    public void setStates(List<MCClusterTaskStatus> states) {
        this.states = states;
    }

    public Integer getPriority() {
        return priority;
    }

    public void setPriority(Integer priority) {
        this.priority = priority;
    }

    public String getCreateTimeBegin() {
        return createTimeBegin;
    }

    public void setCreateTimeBegin(String createTimeBegin) {
        this.createTimeBegin = createTimeBegin;
    }

    public String getCreateTimeEnd() {
        return createTimeEnd;
    }

    public void setCreateTimeEnd(String createTimeEnd) {
        this.createTimeEnd = createTimeEnd;
    }

    public String getScheduleTimeBegin() {
        return scheduleTimeBegin;
    }

    public void setScheduleTimeBegin(String scheduleTimeBegin) {
        this.scheduleTimeBegin = scheduleTimeBegin;
    }

    public String getScheduleTimeEnd() {
        return scheduleTimeEnd;
    }

    public void setScheduleTimeEnd(String scheduleTimeEnd) {
        this.scheduleTimeEnd = scheduleTimeEnd;
    }

    public String getStartTimeBegin() {
        return startTimeBegin;
    }

    public void setStartTimeBegin(String startTimeBegin) {
        this.startTimeBegin = startTimeBegin;
    }

    public String getStartTimeEnd() {
        return startTimeEnd;
    }

    public void setStartTimeEnd(String startTimeEnd) {
        this.startTimeEnd = startTimeEnd;
    }

    public String getEndTimeBegin() {
        return endTimeBegin;
    }

    public void setEndTimeBegin(String endTimeBegin) {
        this.endTimeBegin = endTimeBegin;
    }

    public String getEndTimeEnd() {
        return endTimeEnd;
    }

    public void setEndTimeEnd(String endTimeEnd) {
        this.endTimeEnd = endTimeEnd;
    }

    public String getOrderBy() {
        return orderBy;
    }

    public void setOrderBy(String orderBy) {
        this.orderBy = orderBy;
    }

    public boolean isAsc() {
        return isAsc;
    }

    public void setAsc(boolean isAsc) {
        this.isAsc = isAsc;
    }

    public int getCurrentPage() {
        return currentPage;
    }

    public void setCurrentPage(int currentPage) {
        this.currentPage = currentPage;
    }

    public int getPageSize() {
        return pageSize;
    }

    public void setPageSize(int pageSize) {
        this.pageSize = pageSize;
    }
}
