package cn.videoworks.adapter.servicetask.dto;

/**
 * Created by caofeiyi on 2014/7/14.
 */
public class PublisherSendTaskResponseDataDto {
    private Integer id;
    private String taskId;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getTaskId() {
        return taskId;
    }

    public void setTaskId(String taskId) {
        this.taskId = taskId;
    }
}
