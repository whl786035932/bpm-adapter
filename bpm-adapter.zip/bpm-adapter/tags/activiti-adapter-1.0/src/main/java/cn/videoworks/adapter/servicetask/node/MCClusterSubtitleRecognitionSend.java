package cn.videoworks.adapter.servicetask.node;

import cn.videoworks.adapter.servicetask.enumeration.MCClusterTaskType;
import cn.videoworks.adapter.servicetask.supernode.MCClusterSuperSendTask;

import java.util.List;
import java.util.Map;

public class MCClusterSubtitleRecognitionSend extends MCClusterSuperSendTask {
    public Map<String, Object> getParam(Map<String, Object> variables) {
        //TODO
        return null;
    }

    public List<String> getTemplate(Map<String, Object> variables) {
        //TODO
        return null;
    }

    public MCClusterTaskType getType() {
        return MCClusterTaskType.SubtitleRecognition;
    }

    public int getPriority() {
        return 10;
    }
}