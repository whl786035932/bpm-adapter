package cn.videoworks.adapter.servicetask.dto;

/**
 * Created by caofeiyi on 2014/7/14.
 */
public class PublisherSendTaskRequestDto {
    private Integer id;
    private String taskId;
    private String name;
    private String customer;
    private String videoName;
    private String catalogInfo;
    private String strategy;
    private Integer priority;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getTaskId() {
        return taskId;
    }

    public void setTaskId(String taskId) {
        this.taskId = taskId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getCustomer() {
        return customer;
    }

    public void setCustomer(String customer) {
        this.customer = customer;
    }

    public String getVideoName() {
        return videoName;
    }

    public void setVideoName(String videoName) {
        this.videoName = videoName;
    }

    public String getCatalogInfo() {
        return catalogInfo;
    }

    public void setCatalogInfo(String catalogInfo) {
        this.catalogInfo = catalogInfo;
    }

    public String getStrategy() {
        return strategy;
    }

    public void setStrategy(String strategy) {
        this.strategy = strategy;
    }

    public Integer getPriority() {
        return priority;
    }

    public void setPriority(Integer priority) {
        this.priority = priority;
    }
}
