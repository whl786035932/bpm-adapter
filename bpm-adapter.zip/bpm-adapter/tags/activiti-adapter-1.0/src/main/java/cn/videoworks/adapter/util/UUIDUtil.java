package cn.videoworks.adapter.util;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.UUID;

/**
 * Created by caofeiyi on 2014/7/8.
 */
public class UUIDUtil {

    Logger logger = LoggerFactory.getLogger(UUIDUtil.class);

    /**
     * 自动生成UUID
     *
     * @return
     */
    public static String getUUID() {
        UUID uuid = UUID.randomUUID();
        return uuid.toString();
    }
}
