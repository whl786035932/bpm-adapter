package cn.videoworks.adapter.servicetask.enumeration;

/**
 * Created by caofeiyi on 2014/7/7.
 */
public enum MCClusterTaskStatus {
    NEW,                    //任务可执行（等待）
    HANDOUT,                //任务已分发（运行中）
    FAILURE,                //任务失败
    SUCCESS,                //任务成功
    DELETED,                //任务删除
    STOP,                   //任务停止

}
