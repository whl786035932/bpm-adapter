package cn.videoworks.vicmmam.servicetask;

import java.text.SimpleDateFormat;
import java.util.Date;

import org.activiti.engine.delegate.DelegateExecution;
import org.activiti.engine.delegate.JavaDelegate;

public class SimpleServiceTask2 implements JavaDelegate {
    public void execute(DelegateExecution execution) throws Exception {
        try {
            int no = Integer.valueOf(
                    String.valueOf(execution.getVariable("no")))
                    .intValue();

            SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
            System.out.println(df.format(new Date()) + ":task2" + "-"
                    + execution.getId() + "@" + no);
            if (no == 10) {
                execution.setVariable("errcode", Integer.valueOf(0));
                return;
            }
            if (no < 10) {
                execution.setVariable("errcode", Integer.valueOf(2));
                execution.setVariable("no", Integer.valueOf(no + 1));
                return;
            }
            throw new Exception();
        } catch (Exception e) {
            execution.setVariable("errcode", Integer.valueOf(1));
        }
    }
}