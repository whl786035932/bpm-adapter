package cn.videoworks.vicmmam.servicetask;

import java.text.SimpleDateFormat;
import java.util.Date;

import org.activiti.engine.delegate.DelegateExecution;
import org.activiti.engine.delegate.JavaDelegate;

public class SimpleServiceTask1 implements JavaDelegate {
    public void execute(DelegateExecution execution) throws Exception {
        try {
            System.out.println("start");
            int no = Integer.valueOf(
                    String.valueOf(execution.getVariable("no")))
                    .intValue();

            SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
            System.out.println(df.format(new Date()) + ":task1"
                    + execution.getProcessInstanceId() + "-"
                    + execution.getId() + "@" + no + "%" + (no % 2 == 1));
            if (no % 2 == 1) {
                execution.setVariable("errcode", Integer.valueOf(0));
                return;
            }
            throw new Exception();
        } catch (Exception e) {
            execution.setVariable("errcode", Integer.valueOf(1));
        }
    }
}