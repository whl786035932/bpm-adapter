import cn.videoworks.adapter.exception.SystemConfigException;
import cn.videoworks.adapter.servicetask.dto.PublisherCheckTaskResponseDto;
import cn.videoworks.adapter.util.HttpUtil;
import cn.videoworks.adapter.util.JsonUtil;
import org.activiti.bpmn.model.BpmnModel;
import org.activiti.bpmn.model.FlowElement;
import org.activiti.engine.*;
import org.activiti.engine.history.VWHistoricProcessInstance;
import org.activiti.engine.history.VWHistoricProcessInstanceQuery;
import org.activiti.engine.history.VWHistoricTaskInstance;
import org.activiti.engine.history.VWHistoricTaskInstanceQuery;
import org.activiti.engine.repository.ProcessDefinition;

import java.util.List;

/**
 * Created by caofeiyi on 2014/7/11.
 */
public class EngineTest {
    private static ProcessEngine processEngine = null;

    static {
        initializeBpmSDK();
    }

    public static void initializeBpmSDK() {
        String url = "jdbc:mysql://10.2.17.171:3306/activiti?autoReconnect=true&failOverReadOnly=false&characterEncoding=utf8";
        String password = "123456";
        String user = "root";
        String driver = "com.mysql.jdbc.Driver";
        processEngine = ProcessEngineConfiguration.createStandaloneProcessEngineConfiguration()
                .setDatabaseSchemaUpdate(ProcessEngineConfiguration.DB_SCHEMA_UPDATE_TRUE)
                .setJdbcUrl(url)
                .setJdbcDriver(driver)
                .setJdbcPassword(password)
                .setJdbcUsername(user)
                .setJobExecutorActivate(false)
                .buildProcessEngine();
    }

    public static void main(String[] args) {
        RuntimeService runtimeService = processEngine.getRuntimeService();
        TaskService taskService = processEngine.getTaskService();
        HistoryService historyService = processEngine.getHistoryService();
        IdentityService identityService = processEngine.getIdentityService();
        RepositoryService repositoryService = processEngine
                .getRepositoryService();
        FormService formService = processEngine.getFormService();
        ManagementService managementService = processEngine
                .getManagementService();
        System.out.println("启动成功");
    }

    public static void getProcessNode(RepositoryService repositoryService) {
        List<ProcessDefinition> list = repositoryService
                .createProcessDefinitionQuery().latestVersion().list();
        for (ProcessDefinition processDefinition : list) {
            BpmnModel model = repositoryService.getBpmnModel(processDefinition
                    .getId());
            for (FlowElement element : model.getProcesses().get(0)
                    .getFlowElements()) {
                if (!element.getId().startsWith("sid-")) {
                    System.out.println(element.getId() + ","
                            + element.getName() + ","
                            + processDefinition.getKey());
                }
            }
        }
    }
}
