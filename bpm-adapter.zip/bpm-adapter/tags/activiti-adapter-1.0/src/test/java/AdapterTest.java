import org.activiti.engine.*;


public class AdapterTest {
    private static ProcessEngine processEngine = null;

    static {
        initializeBpmSDK();
    }

    public static void initializeBpmSDK() {
        String url = "jdbc:mysql://10.2.17.171:3306/activiti?autoReconnect=true&failOverReadOnly=false&characterEncoding=utf8";
        String password = "123456";
        String user = "root";
        String driver = "com.mysql.jdbc.Driver";
        processEngine = ProcessEngineConfiguration.createStandaloneProcessEngineConfiguration()
                .setDatabaseSchemaUpdate(ProcessEngineConfiguration.DB_SCHEMA_UPDATE_TRUE)
                .setJdbcUrl(url)
                .setJdbcDriver(driver)
                .setJdbcPassword(password)
                .setJdbcUsername(user)
                .setJobExecutorActivate(true)
                .buildProcessEngine();
    }

    public static void main(String[] args) {
        RuntimeService runtimeService = processEngine.getRuntimeService();
        TaskService taskService = processEngine.getTaskService();
        HistoryService historyService = processEngine.getHistoryService();
        IdentityService identityService = processEngine.getIdentityService();
        RepositoryService repositoryService = processEngine
                .getRepositoryService();
        FormService formService = processEngine.getFormService();
        ManagementService managementService = processEngine
                .getManagementService();
        System.out.println("启动成功");

    }
}
