package cn.videoworks.adapter.servicetask.node;

import cn.videoworks.adapter.exception.AdapterBusinessException;
import cn.videoworks.adapter.util.HttpUtil;
import cn.videoworks.adapter.util.JsonUtil;
import cn.videoworks.adapter.util.PropertiesUtil;
import org.activiti.engine.delegate.DelegateExecution;
import org.activiti.engine.delegate.JavaDelegate;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.HashMap;
import java.util.Map;

/**
 * Created by caofeiyi on 2015/3/11.
 */
public class VFGiveUpCIMPTask implements JavaDelegate {
	
	private Logger logger = LoggerFactory.getLogger(VFGiveUpCIMPTask.class);
	
    public void execute(DelegateExecution delegateExecution) throws Exception {
        try {
            String cimpUrl = PropertiesUtil.get("cimp.url");
            if (StringUtils.isBlank(cimpUrl)) {
                throw new AdapterBusinessException("CIMPURL无效!");
            }
            String url = "http://" + cimpUrl + "/workflowAutoTask/giveupForVf";
            Map<String, String> dataMap = new HashMap<String, String>();
            String processId = String.valueOf(delegateExecution.getVariables().get("processId"));
            String taskDefId = String.valueOf(delegateExecution.getVariables().get("taskDefId"));
            dataMap.put("processId", processId);
            dataMap.put("taskDefId", taskDefId);
            Map<String, Object> requestMap = new HashMap<String, Object>();
            requestMap.put("data",dataMap);
            String responseJson = HttpUtil.httpPost(url, JsonUtil.format(requestMap), HttpUtil.HttpRequestType.JSON);
            MAMTaskDto responseDto = JsonUtil.parse(responseJson, MAMTaskDto.class);
            if (responseDto.getStatusCode() == 200) {
                    delegateExecution.setVariable("errcode", 0);
            } else {
                delegateExecution.setVariable("errcode", 1);
                delegateExecution.setVariable("error_msg", "放弃失败:" + responseDto.getMessage());
            }
        } catch (Exception e) {
        	e.printStackTrace();
            logger.error(e.getMessage(), e.fillInStackTrace());
            delegateExecution.setVariable("errcode", 1);
            delegateExecution.setVariable("error_msg", "放弃异常!");
        }
    }

    private class MAMTaskDto {
        private int statusCode;
        private String message;
        private Map<String, Object> data;

        public int getStatusCode() {
            return statusCode;
        }

        public void setStatusCode(int statusCode) {
            this.statusCode = statusCode;
        }

        public String getMessage() {
            return message;
        }

        public void setMessage(String message) {
            this.message = message;
        }

        public Map<String, Object> getData() {
            return data;
        }

        public void setData(Map<String, Object> data) {
            this.data = data;
        }
    }
}
