package cn.videoworks.adapter.util;

import cn.videoworks.adapter.exception.SystemConfigException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Properties;

/**
 * Created by caofeiyi on 2014/7/7.
 */
public class PropertiesUtil {

    private static Logger logger = LoggerFactory.getLogger(PropertiesUtil.class);

    private static Properties properties = null;

    /**
     * 读取配置文件
     *
     * @throws SystemConfigException
     */
    private static void getProperties() throws SystemConfigException {
        try {
            properties = new Properties();
            properties.load(PropertiesUtil.class.getResourceAsStream("/activiti-adapter.properties"));
        } catch (Exception e) {
            throw new SystemConfigException("读取配置文件异常", e.fillInStackTrace());
        }
    }

    /**
     * 获取配置
     *
     * @param key
     * @return
     * @throws SystemConfigException
     */
    public static String get(String key) throws SystemConfigException {
        String value = "";
        if (properties == null) {
            getProperties();
        }
        if (properties.containsKey(key)) {
            value = String.valueOf(properties.get(key));
        } else {
            throw new SystemConfigException("配置文件参数[" + key + "]异常");
        }
        return value;
    }
    /**
     * 获取配置
     *
     * @param key
     * @return
     * @throws SystemConfigException
     */
    public static String get(String key,String defaultValue) throws SystemConfigException {
        String value = "";
        if (properties == null) {
            getProperties();
        }
        if (properties.containsKey(key)) {
            value = String.valueOf(properties.get(key));
        } else {
            return defaultValue;
        }
        return value;
    }

}