package cn.videoworks.adapter.servicetask.supernode;

import cn.videoworks.adapter.exception.AdapterBusinessException;
import cn.videoworks.adapter.exception.HttpException;
import cn.videoworks.adapter.exception.SystemConfigException;
import cn.videoworks.adapter.servicetask.dto.PublisherCheckTaskRequestDto;
import cn.videoworks.adapter.servicetask.dto.PublisherCheckTaskResponseDto;
import cn.videoworks.adapter.servicetask.dto.PublisherSendTaskRequestDto;
import cn.videoworks.adapter.servicetask.dto.PublisherSendTaskResponseDto;
import cn.videoworks.adapter.servicetask.enumeration.PublisherTaskType;
import cn.videoworks.adapter.util.HttpUtil;
import cn.videoworks.adapter.util.JsonUtil;
import cn.videoworks.adapter.util.PropertiesUtil;
import cn.videoworks.commons.util.json.JsonConverter;

import org.activiti.engine.HistoryService;
import org.activiti.engine.delegate.DelegateExecution;
import org.activiti.engine.delegate.JavaDelegate;
import org.activiti.engine.history.HistoricActivityInstance;
import org.activiti.engine.history.HistoricProcessInstance;
import org.activiti.engine.history.HistoricVariableInstance;
import org.activiti.engine.history.VWHistoricProcessInstance;
import org.activiti.engine.repository.ProcessDefinition;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

public abstract class PublisherSuperSendTask implements JavaDelegate {

	private Logger logger = LoggerFactory
			.getLogger(PublisherSuperSendTask.class);

	DateFormat df = new SimpleDateFormat("yyyyMMddHHmmss");
	
	public void execute(DelegateExecution delegateExecution) {
		try {
			if (isExist(delegateExecution)) {
				delegateExecution.setVariable("currentTaskId",
						getTaskId(delegateExecution));
				delegateExecution.setVariable("errcode", 0);
				delegateExecution.setVariable("error_msg", "发布系统任务已存在");
				logger.debug("发布系统任务已存在!" + "---" + "任务ID:"
						+ getTaskId(delegateExecution));
			} else {
				PublisherSendTaskRequestDto requestDto = buildRequest(delegateExecution);
				String requestJson = JsonUtil.format(requestDto);
				String url = getBaseUrl(delegateExecution.getVariables())
						+ "task/" + getTaskType().name();
				String responseJson = HttpUtil.httpPost(url, requestJson,
						HttpUtil.HttpRequestType.JSON);
				PublisherSendTaskResponseDto responseDto = JsonUtil.parse(
						responseJson, PublisherSendTaskResponseDto.class);
				if (responseDto.getStatusCode() == 200) {
					Map<String, Object> variables = setVariables(responseDto);
					if (variables != null) {
						delegateExecution.setVariables(variables);
					}
					delegateExecution.setVariable("currentTaskId",
							getTaskId(delegateExecution));
					delegateExecution.setVariable("errcode", 0);
					delegateExecution.setVariable("error_msg", "发布系统下发任务成功");
					logger.debug("发布系统下发任务成功!" + "---" + "请求:" + "("
							+ requestJson + ")" + "---" + "响应:" + "("
							+ responseJson + ")");
				} else {
					delegateExecution.setVariable("errcode", 1);
					delegateExecution.setVariable("error_msg", "发布系统下发任务失败:"
							+ responseDto.getMessage());
					logger.debug("发布系统下发任务失败!" + "---" + "请求:" + "("
							+ requestJson + ")" + "---" + "响应:" + "("
							+ responseJson + ")");
				}
			}
		} catch (Exception e) {
			logger.error(e.getMessage(), e.fillInStackTrace());
			delegateExecution.setVariable("errcode", 1);
			delegateExecution.setVariable("error_msg", "发布系统下发任务异常");
		}
	}

	public PublisherSendTaskRequestDto buildRequest(
			DelegateExecution delegateExecution) throws Exception {
		Map<String, Object> variables = delegateExecution.getVariables();
		PublisherSendTaskRequestDto dto = new PublisherSendTaskRequestDto();
		dto.setTaskId(getTaskId(delegateExecution));
		dto.setName(getTaskName(delegateExecution));
		dto.setCatalogInfo(getCatalogInfo(variables));
		dto.setCustomer(getCustomer(variables));
		dto.setVideoName(getVideoName(variables));
		dto.setStrategy(getStrategy(variables));
		dto.setPriority(getPriority(variables));
		dto.setAlias(getAlias(variables));
		dto.setCallBackUrl(getCallBackUrl(delegateExecution));
		dto.setUsername(getUsername(delegateExecution));
		Map<String,Object> map = new HashMap<String, Object>();
		map.put("callBackUrl", getCallBackUrl(variables));//发布系统中无用的参数
		map.put("prepareId", getPreparId(variables));
		dto.setMapStr(JsonConverter.format(map));
		return dto;
	}

	public Map<String, Object> setVariables(
			PublisherSendTaskResponseDto responseDto) throws Exception {
		return null;
	}

	public abstract String getNameSurfix() throws Exception;

	public abstract PublisherTaskType getTaskType() throws Exception;
	
	public abstract String getCallBackUrl(Map<String, Object> variables) throws Exception;

	public abstract String getPreparId(Map<String, Object> variables) throws Exception;
	
	public int getPriority(Map<String, Object> variables) throws Exception {
		int priority = 0;
		if (variables != null && variables.containsKey("priority")
				&& variables.get("priority") != null) {
			String priorityStr = String.valueOf(variables.get("priority"))
					.trim();
			priority = new Integer(priorityStr);
		} else {
			priority = 10;
		}
		return priority;
	}

	public abstract String getCustomer(Map<String, Object> variables)
			throws Exception;

	public abstract String getCatalogInfo(Map<String, Object> variables)
			throws Exception;

	public abstract String getVideoName(Map<String, Object> variables)
			throws Exception;

	public abstract String getStrategy(Map<String, Object> variables)
			throws Exception;

	public abstract String getUsername(DelegateExecution delegateExecution)
			throws Exception;
	
	public abstract String getAlias(Map<String, Object> variables)
			throws Exception;
//	public String getCallBackUrl(DelegateExecution delegateExecution) throws SystemConfigException{
//		String callBackUrl=PropertiesUtil.get("publish.callbackurl");
//		callBackUrl+="/"+delegateExecution.getProcessInstanceId();
//		return callBackUrl;
//	}
	// modify by zy 20180319 向下兼容没有支持回调的发布系统
	public String getCallBackUrl(DelegateExecution delegateExecution){
		String callBackUrl = "";
		try{
			callBackUrl=PropertiesUtil.get("publish.callbackurl");
			callBackUrl+="/"+delegateExecution.getProcessInstanceId();
		}catch(Exception e){
			logger.warn("获取publish.callbackurl失败！", e.fillInStackTrace());
		}
		return callBackUrl;
	}
	public boolean isExist(DelegateExecution delegateExecution)
			throws Exception {
		try {
			PublisherCheckTaskRequestDto requestDto = new PublisherCheckTaskRequestDto();
			requestDto.setTaskId(getTaskId(delegateExecution));
			String requestJson = JsonUtil.format(requestDto);
			String url = getBaseUrl(delegateExecution.getVariables())
					+ "task/list";
			String responseJson = HttpUtil.httpPost(url, requestJson,
					HttpUtil.HttpRequestType.JSON);
			PublisherCheckTaskResponseDto responseDto = JsonUtil.parse(
					responseJson, PublisherCheckTaskResponseDto.class);
			if (responseDto.getStatusCode() == 200) {
				if (responseDto.getData() != null
						&& responseDto.getData().getTaskList() != null
						&& responseDto.getData().getTaskList().size() > 0) {
					return true;
				} else {
					return false;
				}
			} else {
				throw new AdapterBusinessException("请求异常");
			}
		} catch (HttpException httpException) {
			try {
				Thread.sleep(5000);
				return isExist(delegateExecution);
			} catch (Exception e) {
				throw e;
			}
		} catch (Exception e) {
			throw e;
		}
	}

	public String getTaskId(DelegateExecution delegateExecution)
			throws Exception {
		return PropertiesUtil.get("taskId.prefix") + "_" + getNameSurfix()
				+ "_" + delegateExecution.getProcessInstanceId();
	}

	public String getTaskName(DelegateExecution delegateExecution)
			throws Exception {
		VWHistoricProcessInstance childProcess = delegateExecution
				.getEngineServices().getHistoryService()
				.createVWHistoricProcessInstanceQuery()
				.processInstanceId(delegateExecution.getProcessInstanceId())
				.singleResult();
		VWHistoricProcessInstance process = delegateExecution
				.getEngineServices().getHistoryService()
				.createVWHistoricProcessInstanceQuery()
				.processInstanceId(childProcess.getSuperProcessInstanceId())
				.singleResult();
		ProcessDefinition processDefinition = delegateExecution
				.getEngineServices().getRepositoryService()
				.createProcessDefinitionQuery()
				.processDefinitionId(process.getProcessDefinitionId())
				.singleResult();
		String activityId = "";
		
		List<HistoricActivityInstance> activityList = delegateExecution
				.getEngineServices().getHistoryService()
				.createHistoricActivityInstanceQuery()
				.processInstanceId(process.getId()).list();
		for (HistoricActivityInstance activity : activityList) {
			if (childProcess.getId().equals(
					activity.getCalledProcessInstanceId())) {
				activityId = activity.getActivityId();
			}
		}
		//modify by zy 20180118 任务名上带上（sucaiID）后缀
		String taskNameSuffixes = "";
		String taskNameSuffixesKey = PropertiesUtil.get("taskName.suffixes.customer.key","");
		if(StringUtils.isNotBlank(taskNameSuffixesKey)){
			HistoricVariableInstance variable = delegateExecution
					.getEngineServices().getHistoryService()
					.createHistoricVariableInstanceQuery()
					.processInstanceId(process.getId()).variableName(taskNameSuffixesKey)
					.singleResult();
			if (variable != null) {
				taskNameSuffixes = "_"+variable.getValue().toString();
			}
		}
				
				
		return PropertiesUtil.get("taskName.prefix") + "_"
				+ processDefinition.getName() + "_" + activityId + "_"
				+ process.getId() + "_" + df.format(new Date())+taskNameSuffixes;
	}

	public String getBaseUrl(Map<String, Object> variables) throws Exception {
		String baseUrl = "";
		if (variables.containsKey("publisher_ip")
				&& variables.get("publisher_ip") != null) {
			baseUrl = String.valueOf(variables.get("publisher_ip"));
			if (!baseUrl.endsWith("/")) {
				baseUrl = baseUrl + "/";
			}
			baseUrl = baseUrl + "publish/ws";
		} else {
			baseUrl = PropertiesUtil.get("publisher.ip");
		}
		if (StringUtils.isBlank(baseUrl)) {
			throw new AdapterBusinessException("读取发布系统URL异常");
		}
		if (!baseUrl.startsWith("http://")) {
			baseUrl = "http://" + baseUrl;
		}
		if (!baseUrl.endsWith("/")) {
			baseUrl = baseUrl + "/";
		}
		return baseUrl;
	}
}
