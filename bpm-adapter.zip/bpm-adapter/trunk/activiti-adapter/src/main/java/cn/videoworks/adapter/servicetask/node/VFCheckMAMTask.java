package cn.videoworks.adapter.servicetask.node;

import cn.videoworks.adapter.exception.AdapterBusinessException;
import cn.videoworks.adapter.util.HttpUtil;
import cn.videoworks.adapter.util.JsonUtil;
import cn.videoworks.adapter.util.PropertiesUtil;
import org.activiti.engine.delegate.DelegateExecution;
import org.activiti.engine.delegate.JavaDelegate;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.HashMap;
import java.util.Map;

/**
 * Created by caofeiyi on 2015/3/11.
 */
public class VFCheckMAMTask implements JavaDelegate {
	
	private Logger logger = LoggerFactory.getLogger(VFCheckMAMTask.class);
	
    public void execute(DelegateExecution delegateExecution) throws Exception {
        try {
            String mamUrl = PropertiesUtil.get("mam.url");
            if (StringUtils.isBlank(mamUrl)) {
                throw new AdapterBusinessException("媒资URL无效!");
            }
            String url = "http://" + mamUrl + "/workflowAutoTask/mamCheckTask";
            Map<String, String> dataMap = new HashMap<String, String>();
            String processId = String.valueOf(delegateExecution.getVariables().get("processId"));
            String taskDefId = String.valueOf(delegateExecution.getVariables().get("taskDefId"));
            dataMap.put("processId", processId);
            dataMap.put("taskDefId", taskDefId);
            Map<String, Object> requestMap = new HashMap<String, Object>();
            requestMap.put("data",dataMap);
            logger.debug("mam url is :"+url+",params is :"+JsonUtil.format(requestMap));
            String responseJson = HttpUtil.httpPost(url, JsonUtil.format(requestMap), HttpUtil.HttpRequestType.JSON);
            
            MAMTaskDto responseDto = JsonUtil.parse(responseJson, MAMTaskDto.class);
            if (responseDto.getStatusCode() == 200) {
                if (responseDto.getData() != null && responseDto.getData().get("data") !=null && ((Map<String,Object>)responseDto.getData().get("data")).containsKey("review_result")) {
                    delegateExecution.setVariable("review_result", ((Map<String,Object>)responseDto.getData().get("data")).get("review_result"));
                    delegateExecution.setVariable("review_msg", ((Map<String,Object>)responseDto.getData().get("data")).containsKey("review_msg") ? ((Map<String,Object>)responseDto.getData().get("data")).get("review_msg") : "");
                    delegateExecution.setVariable("errcode", 0);
                    delegateExecution.setVariable("error_msg", "任务成功");
                } else {
                    delegateExecution.setVariable("errcode", 2);

                }
            } else {
                delegateExecution.setVariable("errcode", 1);
                delegateExecution.setVariable("error_msg", "监测失败:" + responseDto.getMessage());
            }
        } catch (Exception e) {
        	e.printStackTrace();
            logger.error(e.getMessage(), e.fillInStackTrace());
            delegateExecution.setVariable("errcode", 1);
            delegateExecution.setVariable("error_msg", "检测异常!");
        }
    }

    private class MAMTaskDto {
        private int statusCode;
        private String message;
        private Map<String, Object> data;

        public int getStatusCode() {
            return statusCode;
        }

        public void setStatusCode(int statusCode) {
            this.statusCode = statusCode;
        }

        public String getMessage() {
            return message;
        }

        public void setMessage(String message) {
            this.message = message;
        }

        public Map<String, Object> getData() {
            return data;
        }

        public void setData(Map<String, Object> data) {
            this.data = data;
        }
    }
}
