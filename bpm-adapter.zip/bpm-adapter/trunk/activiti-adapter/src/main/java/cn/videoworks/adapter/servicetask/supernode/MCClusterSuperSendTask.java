package cn.videoworks.adapter.servicetask.supernode;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.activiti.engine.HistoryService;
import org.activiti.engine.delegate.DelegateExecution;
import org.activiti.engine.delegate.JavaDelegate;
import org.activiti.engine.history.HistoricActivityInstance;
import org.activiti.engine.history.HistoricProcessInstance;
import org.activiti.engine.history.HistoricVariableInstance;
import org.activiti.engine.history.VWHistoricProcessInstance;
import org.activiti.engine.repository.ProcessDefinition;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import cn.videoworks.adapter.exception.AdapterBusinessException;
import cn.videoworks.adapter.exception.HttpException;
import cn.videoworks.adapter.servicetask.dto.MCClusterCheckTaskRequestDto;
import cn.videoworks.adapter.servicetask.dto.MCClusterCheckTaskResponseDto;
import cn.videoworks.adapter.servicetask.dto.MCClusterSendTaskRequestDto;
import cn.videoworks.adapter.servicetask.dto.MCClusterSendTaskResponseDto;
import cn.videoworks.adapter.servicetask.enumeration.MCClusterTaskType;
import cn.videoworks.adapter.util.HttpUtil;
import cn.videoworks.adapter.util.JsonUtil;
import cn.videoworks.adapter.util.PropertiesUtil;

/**
 * 计算集群下发任务模板类 Created by caofeiyi on 2014/7/9.
 */
public abstract class MCClusterSuperSendTask implements JavaDelegate {

	private Logger logger = LoggerFactory
			.getLogger(MCClusterSuperSendTask.class);
	
	
	DateFormat df = new SimpleDateFormat("yyyyMMddHHmmss");
	

	public void execute(DelegateExecution delegateExecution) {
		try {
			if (isExist(delegateExecution)) {
				delegateExecution.setVariable("currentTaskId",
						getTaskId(delegateExecution));
				delegateExecution.setVariable("errcode", 0);
				delegateExecution.setVariable("error_msg", "计算集群任务已存在");
				logger.debug("计算集群任务已存在!" + "---" + "任务ID:"
						+ getTaskId(delegateExecution));
			} else {
				MCClusterSendTaskRequestDto requestDto = buildRequest(delegateExecution);
				String requestJson = JsonUtil.format(requestDto);
				String url = getBaseUrl(delegateExecution.getVariables())
						+ "task/";
				String responseJson = HttpUtil.httpPost(url, requestJson,
						HttpUtil.HttpRequestType.JSON);
				MCClusterSendTaskResponseDto responseDto = JsonUtil.parse(
						responseJson, MCClusterSendTaskResponseDto.class);
				if (responseDto.getResult() == 0) {
					Map<String, Object> variables = setVariables(responseDto);
					if (variables != null) {
						delegateExecution.setVariables(variables);
					}
					delegateExecution.setVariable("currentTaskId",
							getTaskId(delegateExecution));
					delegateExecution.setVariable("errcode", 0);
					delegateExecution.setVariable("error_msg", "计算集群下发任务成功");
					logger.debug("计算集群下发任务成功!" + "---" + "请求:" + "("
							+ requestJson + ")" + "---" + "响应:" + "("
							+ responseJson + ")");
				} else {
					delegateExecution.setVariable("errcode", 1);
					delegateExecution.setVariable("error_msg", "计算集群下发任务失败:"
							+ responseDto.getMessage());
					logger.debug("计算集群下发任务失败!" + "---" + "请求:" + "("
							+ requestJson + ")" + "---" + "响应:" + "("
							+ responseJson + ")");
				}
			}
		} catch (Exception e) {
			logger.error(e.getMessage(), e.fillInStackTrace());
			delegateExecution.setVariable("errcode", 1);
			delegateExecution.setVariable("error_msg", "计算集群下发任务异常");
		}
	}

	public MCClusterSendTaskRequestDto buildRequest(
			DelegateExecution delegateExecution) throws Exception {
		try {
			Map<String, Object> variables = delegateExecution.getVariables();
			MCClusterSendTaskRequestDto dto = new MCClusterSendTaskRequestDto();
			dto.setId(getTaskId(delegateExecution));
			dto.setName(getTaskName(delegateExecution));
			
			dto.setPriority(getPriority(variables));
//			HistoryService historyService=delegateExecution.getEngineServices().getHistoryService();
//			String childProcId=delegateExecution.getProcessInstanceId();
//			HistoricProcessInstance childProc=historyService.createHistoricProcessInstanceQuery().processInstanceId(childProcId).singleResult();
//			String parentProcId=childProc.getSuperProcessInstanceId();
//			HistoricProcessInstance parentProc=historyService.createHistoricProcessInstanceQuery().includeProcessVariables().processInstanceId(parentProcId).singleResult();
//			if(parentProc!=null&&parentProc.getProcessVariables()!=null&&
//					parentProc.getProcessVariables().containsKey("mam_priority")&&
//					parentProc.getProcessVariables().get("mam_priority") instanceof Number){
//				int priority=new Integer(String.valueOf(parentProc.getProcessVariables().get("mam_priority"))).intValue() ;
//				dto.setPriority(priority);
//			}else{
//				dto.setPriority(10);
//			}
			dto.setScheduleTime(null);
			dto.setTemplates(getTemplate(variables));
			dto.setParam(getParam(variables));
			if (dto.getParam() == null) {
				throw new Exception();
			}
			dto.setType(getType());
			return dto;
		} catch (Exception e) {
			e.printStackTrace();
			throw new AdapterBusinessException();
		}
	}

	public Map<String, Object> setVariables(
			MCClusterSendTaskResponseDto responseDto) throws Exception {
		return null;
	}

	public abstract Map<String, Object> getParam(Map<String, Object> variables)
			throws Exception;

	public abstract List<String> getTemplate(Map<String, Object> variables)
			throws Exception;

	public abstract MCClusterTaskType getType() throws Exception;

	public int getPriority(Map<String, Object> variables) throws Exception {
		int priority = 0;
		if (variables != null && variables.containsKey("priority")
				&& variables.get("priority") != null) {
			String priorityStr = String.valueOf(variables.get("priority"))
					.trim();
			priority = new Integer(priorityStr);
		} else {
			priority = 10;
		}
		return priority;
	}

	public boolean isExist(DelegateExecution delegateExecution)
			throws Exception {
		try {
			MCClusterCheckTaskRequestDto requestDto = new MCClusterCheckTaskRequestDto();
			requestDto.setId(getTaskId(delegateExecution));
			String requestJson = JsonUtil.format(requestDto);
			String url = getBaseUrl(delegateExecution.getVariables())
					+ "task/status/";
			String responseJson = HttpUtil.httpPost(url, requestJson,
					HttpUtil.HttpRequestType.JSON);
			MCClusterCheckTaskResponseDto responseDto = JsonUtil.parse(
					responseJson, MCClusterCheckTaskResponseDto.class);
			if (responseDto.getResult() == 0) {
				if (responseDto.getData() != null
						&& responseDto.getData().size() > 0) {
					return true;
				} else {
					return false;
				}
			} else {
				throw new AdapterBusinessException("请求异常");
			}
		} catch (HttpException httpException) {
			try {
				Thread.sleep(5000);
				return isExist(delegateExecution);
			} catch (Exception e) {
				throw e;
			}
		} catch (Exception e) {
			throw e;
		}
	}

	public String getTaskId(DelegateExecution delegateExecution)
			throws Exception {
		return PropertiesUtil.get("taskId.prefix") + "_" + getType().name()
				+ "_" + delegateExecution.getProcessInstanceId();
	}

	public String getTaskName(DelegateExecution delegateExecution)
			throws Exception {
		VWHistoricProcessInstance childProcess = delegateExecution
				.getEngineServices().getHistoryService()
				.createVWHistoricProcessInstanceQuery()
				.processInstanceId(delegateExecution.getProcessInstanceId())
				.singleResult();
		VWHistoricProcessInstance process = delegateExecution
				.getEngineServices().getHistoryService()
				.createVWHistoricProcessInstanceQuery()
				.processInstanceId(childProcess.getSuperProcessInstanceId())
				.singleResult();
		ProcessDefinition processDefinition = delegateExecution
				.getEngineServices().getRepositoryService()
				.createProcessDefinitionQuery()
				.processDefinitionId(process.getProcessDefinitionId())
				.singleResult();
		String activityId = "";
		List<HistoricActivityInstance> activityList = delegateExecution
				.getEngineServices().getHistoryService()
				.createHistoricActivityInstanceQuery()
				.processInstanceId(process.getId()).list();
		for (HistoricActivityInstance activity : activityList) {
			if (childProcess.getId().equals(
					activity.getCalledProcessInstanceId())) {
				activityId = activity.getActivityId();
			}
		}
		//modify by zy 20180118 任务名上带上（sucaiID）后缀
		String taskNameSuffixes = "";
		String taskNameSuffixesKey = PropertiesUtil.get("taskName.suffixes.customer.key","");
		if(StringUtils.isNotBlank(taskNameSuffixesKey)){
			HistoricVariableInstance variable = delegateExecution
					.getEngineServices().getHistoryService()
					.createHistoricVariableInstanceQuery()
					.processInstanceId(process.getId()).variableName(taskNameSuffixesKey)
					.singleResult();
			if (variable != null) {
				taskNameSuffixes = "_"+variable.getValue().toString();
			}
		}
		return PropertiesUtil.get("taskName.prefix") + "_"
				+ processDefinition.getName() + "_" + activityId + "_"
				+ process.getId() +"_" + df.format(new Date())+taskNameSuffixes;
	}

	public String getBaseUrl(Map<String, Object> variables) throws Exception {
		String baseUrl = "";
		if (variables.containsKey("mccluster_ip")
				&& variables.get("mccluster_ip") != null) {
			baseUrl = String.valueOf(variables.get("mccluster_ip"));
		} else {
			baseUrl = PropertiesUtil.get("mccluster.ip");
		}
		if (StringUtils.isBlank(baseUrl)) {
			throw new AdapterBusinessException("读取计算集群URL异常");
		}
		if (!baseUrl.startsWith("http://")) {
			baseUrl = "http://" + baseUrl;
		}
		if (!baseUrl.endsWith("/")) {
			baseUrl = baseUrl + "/";
		}
		return baseUrl;
	}
}
