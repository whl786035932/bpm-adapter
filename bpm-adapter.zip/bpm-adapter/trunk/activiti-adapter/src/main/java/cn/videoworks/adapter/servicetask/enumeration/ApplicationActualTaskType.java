package cn.videoworks.adapter.servicetask.enumeration;

public enum ApplicationActualTaskType {
	vfAddReview,        //视频工厂_增加审核
    vfShipOrder,        //视频工厂_更新切片状态
    vfImportUpdate,     //视频工厂_导入更新数据
    vfInfoUpdate,       //视频工厂_更新数据
    vfSendReview,       //视频工厂_通知审核结果
    vfSendReview2,      //视频工厂_通知二审结果
    vfSendMessage,      //视频工厂_发送消息
    mamImport,          //媒资_媒资导入
    mamStatus,          //媒资_更新媒资状态
    mamUpdateMetadata,  //媒资_更新媒资
    mamDeleteMetadata,  //媒资_删除媒资
    mamSearchIndex,     //媒资_同步搜索引擎
    mamSetCatalog,      //媒资_写入编目信息
    mamReport,          //媒资_通知相关人员
    mamLowVideoDrm,     //媒资_低码视频加密
    mamProcessCount,    //媒资_获取流程数量
    mamModifyReference,	//媒资_修改媒资关联关系
    mamUpdataDateType,	//数据清洗日期类型
    mamUpdataPosters,	//数据清洗媒资海报
    mamAutoReviewSend,	//自动计审任务下发
    mamAutoReviewCheck, //自动计审任务查询
    mamImportEPG,		//导入epg
    mamCharacterInitialUpdate,	//媒资_清洗演员/主要人物首字母
    mamJunkFiles,		//媒资检索垃圾文件
    mamArcSpecialMark,	//山东虹软出库转码特殊处理
    mamAddWaitProcess,	//预约流程
    
    
    
    vmsAddOrUpdate,	    //视频管理系统_内容入库
    vmsUnshelve,	    //视频管理系统_内容下架
    vmsStatusUpdate,   //视频管理系统_内容删除更新
    vmsDeleteUpdate,	   //视频管理系统_内容删除更新

    vfSyncCutInfo,	//同步切点帧信息
    vfDocumentCommit,	//提交逻辑段
    vfClipCommit,//提交素材
    vfMatchClips,	//匹配素材
    vfSyncImportClip,	//同步离线素材
    
    
    vfGetEpgCutpoint,	//视频工厂_获取epg切点
    
    vms2ShelvesStatus,	//vms二期变更上下架状态
    
    //cimp适配器
    cimpCdnStatus,	//cdn状态变更
    cimpColumnSycStatus,	//栏目树同步状态变更	
    cimpColumnSitesNoMappingStatus	//栏目树站群解绑状态变更
}
