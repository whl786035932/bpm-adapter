package cn.videoworks.adapter.servicetask.dto;

/**
 * Created by caofeiyi on 2014/7/14.
 */
public class PublisherSendTaskRequestDto {
	private Integer id;
	private String taskId;
	private String name;
	private String alias;
	private String customer;
	private String videoName;
	private String catalogInfo;
	private String strategy;
	private Integer priority;
	private String username;
	private String mapStr;
	private String callBackUrl;
	private String callBackType;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getTaskId() {
		return taskId;
	}

	public void setTaskId(String taskId) {
		this.taskId = taskId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getCustomer() {
		return customer;
	}

	public void setCustomer(String customer) {
		this.customer = customer;
	}

	public String getVideoName() {
		return videoName;
	}

	public void setVideoName(String videoName) {
		this.videoName = videoName;
	}

	public String getCatalogInfo() {
		return catalogInfo;
	}

	public void setCatalogInfo(String catalogInfo) {
		this.catalogInfo = catalogInfo;
	}

	public String getStrategy() {
		return strategy;
	}

	public void setStrategy(String strategy) {
		this.strategy = strategy;
	}

	public Integer getPriority() {
		return priority;
	}

	public void setPriority(Integer priority) {
		this.priority = priority;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getMapStr() {
		return mapStr;
	}

	public void setMapStr(String mapStr) {
		this.mapStr = mapStr;
	}

	public String getAlias() {
		return alias;
	}

	public void setAlias(String alias) {
		this.alias = alias;
	}

	public String getCallBackUrl() {
		return callBackUrl;
	}

	public void setCallBackUrl(String callBackUrl) {
		this.callBackUrl = callBackUrl;
	}

	public String getCallBackType() {
		return callBackType;
	}

	public void setCallBackType(String callBackType) {
		this.callBackType = callBackType;
	}

	
}
