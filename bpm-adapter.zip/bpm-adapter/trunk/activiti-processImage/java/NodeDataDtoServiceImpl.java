package cn.videoworks.vicmmam.service.impl;

import groovy.util.Node;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.activiti.engine.HistoryService;
import org.activiti.engine.history.VWHistoricProcessInstance;
import org.activiti.engine.history.VWHistoricTaskInstance;
import org.apache.commons.lang3.StringUtils;
import org.codehaus.groovy.tools.shell.util.NoExitSecurityManager;
import org.springframework.stereotype.Service;

import cn.videoworks.commons.util.json.JsonConverter;
import cn.videoworks.vicmmam.dto.NodeDataDto;
import cn.videoworks.vicmmam.dto.NodeDto;
import cn.videoworks.vicmmam.service.NodeDataDtoService;

@Service
public class NodeDataDtoServiceImpl implements NodeDataDtoService{
	private   DateFormat df = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
	@Resource
	  private HistoryService historyService ;
	@Override
	public List<NodeDataDto> getNodeDtosVWHistoricProcessInstance(
			List<VWHistoricProcessInstance> vWHistoricProcessInstances,String nodeName) {
		List<NodeDataDto> nodeDataDtos = new ArrayList<NodeDataDto>();
		if(vWHistoricProcessInstances!=null && vWHistoricProcessInstances.size()>0){
			for(VWHistoricProcessInstance node:vWHistoricProcessInstances){
				NodeDataDto  nodeDataDto = new NodeDataDto();
				nodeDataDto.setStartTime(node.getStartTime()!=null ?df.format(node.getStartTime()):"");
				nodeDataDto.setEndTime(node.getEndTime()!=null ?df.format(node.getEndTime()):"");
				nodeDataDto.setUser(node.getStartUserId()!=null?node.getStartUserId():"");
				Map<String ,Object> map = getNodeDataMap(node,nodeName);
				nodeDataDto.setInData(map);
				nodeDataDtos.add(nodeDataDto);
			}
		}
		return nodeDataDtos;
	}

	@Override
	public List<NodeDataDto> getNodeDtosByVWHistoricTaskInstance(
			List<VWHistoricTaskInstance> vWHistoricTaskInstances,String nodeName) {
		List<NodeDataDto> nodeDataDtos = new ArrayList<NodeDataDto>();
		if(vWHistoricTaskInstances!=null && vWHistoricTaskInstances.size()>0){
			for(VWHistoricTaskInstance node:vWHistoricTaskInstances){
				Map<String,Object> processVariables = historyService.createVWHistoricProcessInstanceQuery().processInstanceId(node.getProcessInstanceId()).includeProcessVariables().singleResult().getProcessVariables();
				NodeDataDto  nodeDataDto = new NodeDataDto();
				nodeDataDto.setStartTime(node.getStartTime()!=null ?df.format(node.getStartTime()):"");
				nodeDataDto.setEndTime(node.getEndTime()!=null ?df.format(node.getEndTime()):"");
				nodeDataDto.setUser(node.getAssignee()!=null?node.getAssignee():"");
				Map<String ,Object> map = getNodeDataMap( node, nodeName,processVariables);
				nodeDataDto.setInData(map);
				nodeDataDtos.add(nodeDataDto);
			}
		}
		return nodeDataDtos;
	}
	
	public Map<String,Object> getNodeDataMap(VWHistoricProcessInstance node,String nodeName){
		Map<String ,Object> map = node.getProcessVariables();
		Map<String ,Object> result = new HashMap<String ,Object>();
		switch (nodeName) {
		case "媒资入库":
			Map<String ,Object> metadata = JsonConverter.parse(map.get("metadata").toString(),Map.class);
			if(metadata!=null){
				String type = (String) metadata.get("type");
				if(type!=null && type.equals("PACKAGE")){
					Map<String,Object> basicCatalog = (Map<String, Object>) metadata.get("packageBasicCatalog");
					result.put("标题", basicCatalog.get("properTitle"));
				}else{
					Map<String,Object> basicCatalog = (Map<String, Object>) metadata.get("basicCatalog");
					result.put("标题", basicCatalog.get("properTitle"));
				}
			}
			break;
		case "文件迁移":
			String filesStr = (String) map.get("files");
			Map<String ,Object> files = JsonConverter.parse(filesStr.substring(1, filesStr.length()-1),Map.class);
			result.put("文件来源", files.get("from"));
			result.put("文件目标", files.get("to"));
			break;
		case "视频信息提取":
			String video_url = map.get("video_url").toString();
			result.put("视频文件名", video_url);
			break;
		case "自动计审":
			String autoReview_video_url = map.get("video_url").toString();
			result.put("视频文件名", autoReview_video_url);
			break;
		case "视频转码":
			String transcode_before = map.get("source").toString();
			result.put("转码前文件名", transcode_before);
			String transcode_after = map.get("target").toString();
			result.put("转码后文件名", transcode_after);
			break;
		case "关键帧提取":
			String keyFrames_video_url = map.get("video_url").toString();
			result.put("视频文件名", keyFrames_video_url);
			break ;
		case "媒资元数据更新":
			Map<String ,Object> mAM_Updatemetadata_metadata =  JsonConverter.parse(map.get("metadata").toString(),Map.class);
			if(mAM_Updatemetadata_metadata!=null){
				String type = (String) mAM_Updatemetadata_metadata.get("type");
				if(type!=null && type.equals("PACKAGE")){
					result.put("标题", ((Map<String,Object>)mAM_Updatemetadata_metadata.get("packageBasicCatalog")).get("properTitle"));
				}else{
					result.put("标题", ((Map<String,Object>)mAM_Updatemetadata_metadata.get("basicCatalog")).get("properTitle"));
				}
				result.put("媒资Id", mAM_Updatemetadata_metadata.get("id"));
			}
			break;
		case "备份元数据文件":
			String wirteFile_fileName = map.get("file").toString();
			result.put("物理文件名", wirteFile_fileName);
			break ;
		case "发送邮件":
			Map<String ,Object> mAM_Report_metadata =  JsonConverter.parse(map.get("metadata").toString(),Map.class);
			if(mAM_Report_metadata!=null){
				String mAM_Report_type = (String) mAM_Report_metadata.get("type");
				if(mAM_Report_type!=null && mAM_Report_type.equals("PACKAGE")){
					result.put("标题", ((Map<String,Object>)mAM_Report_metadata.get("packageBasicCatalog")).get("properTitle"));
				}else{
					result.put("标题", ((Map<String,Object>)mAM_Report_metadata.get("basicCatalog")).get("properTitle"));
				}
				result.put("媒资Id", mAM_Report_metadata.get("id"));
			}
			result.put("收件人", node.getStartUserId());
			break;
		case "媒资删除":
			String deleteFile = (String) map.get("file");
			result.put("待删除文件", deleteFile);
			break ;
		case "发布媒资"	:
			Map<String ,Object> deploy_catalog =  JsonConverter.parse(map.get("catalog").toString(),Map.class);
			if(deploy_catalog!=null){
				String deploy_type = (String) deploy_catalog.get("type");
				if(deploy_type!=null && deploy_type.equals("PACKAGE")){
					result.put("标题", ((Map<String,Object>)deploy_catalog.get("packageBasicCatalog")).get("properTitle"));
				}else{
					result.put("标题", ((Map<String,Object>)deploy_catalog.get("basicCatalog")).get("properTitle"));
				}
			}
			break ;
		default:
			String metaDataStr = (String) map.get("metadata");
			Map<String ,Object> all_metadata = StringUtils.isNotBlank(metaDataStr)?JsonConverter.parse(metaDataStr,Map.class):null;
			if(all_metadata!=null){
				String all_type = (String) all_metadata.get("type");
				if(all_type!=null && all_type.equals("PACKAGE")){
					result.put("标题", ((Map<String,Object>)all_metadata.get("packageBasicCatalog")).get("properTitle"));
				}else{
					result.put("标题", ((Map<String,Object>)all_metadata.get("basicCatalog")).get("properTitle"));
				}
				result.put("媒资Id", all_metadata.get("id"));
			}else{
				result.put("标题", "");
				result.put("媒资Id", "");
			}
			break;
		}
		return result ;
	}
	public Map<String,Object> getNodeDataMap(VWHistoricTaskInstance node,String nodeName,Map<String ,Object> map){
		Map<String ,Object> result = new HashMap<String ,Object>();
		String mapMetadataStr = map!=null&&map.size()>0?map.get("mam_metadata").toString():"";
		Map<String ,Object> all_metadata = null;
		if(mapMetadataStr!=null && !mapMetadataStr.equals("")){
			all_metadata = JsonConverter.parse(mapMetadataStr,Map.class);
		}
		if(all_metadata!=null){
			String type = (String) all_metadata.get("type");
			if(type!=null && type.equals("PACKAGE")){
				result.put("标题", all_metadata!=null?((Map<String,Object>)all_metadata.get("packageBasicCatalog")).get("properTitle"):"");
			}else{
				result.put("标题", all_metadata!=null?((Map<String,Object>)all_metadata.get("basicCatalog")).get("properTitle"):"");
			}
			result.put("媒资Id", all_metadata!=null?all_metadata.get("id"):"");
		}
		if(nodeName!=null && (nodeName.equals("MAM_ErrorTask")||nodeName.equals("错误处理"))){
			List<VWHistoricProcessInstance> processes = historyService.createVWHistoricProcessInstanceQuery().superProcessInstanceId(node.getProcessInstanceId()).includeProcessVariables().orderByProcessInstanceEndTime().desc().list();
			if(processes!=null && processes.size()>0){
				int processesFlag = 0 ;
				long endTime = 0;
				for(int i =  0;i<processes.size();i++){
					if(processes.get(i).getEndTime().getTime() == node.getStartTime().getTime()){
						endTime = processes.get(i).getEndTime().getTime();
						processesFlag = i;
						break;
					}
					if(processes.get(i).getEndTime().getTime()>endTime &&processes.get(i).getEndTime().getTime() < node.getStartTime().getTime()){
						endTime = processes.get(i).getEndTime().getTime();
						processesFlag = i;
					}
				}
				VWHistoricProcessInstance processe = processes.get(processesFlag);
				String erro_msg = (String) processe.getProcessVariables().get("error_msg");
				result.put("错误信息", erro_msg);
			}else{
				result.put("错误信息","");
			}
		}
		return result ;
	}
	
}
