package cn.videoworks.vicmmam.service;

import java.util.List;
import java.util.Map;

import org.activiti.engine.history.VWHistoricProcessInstance;
import org.activiti.engine.history.VWHistoricTaskInstance;

import cn.videoworks.vicmmam.dto.NodeDataDto;

public interface NodeDataDtoService {
	List<NodeDataDto> getNodeDtosVWHistoricProcessInstance(List<VWHistoricProcessInstance> vWHistoricProcessInstances,String nodeName );
	
	List<NodeDataDto> getNodeDtosByVWHistoricTaskInstance(List<VWHistoricTaskInstance> vWHistoricTaskInstances ,String nodeName );
}
