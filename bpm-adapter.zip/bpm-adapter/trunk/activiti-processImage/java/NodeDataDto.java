package cn.videoworks.vicmmam.dto;

import java.util.Map;

/**
 * 工作流节点参数 
 * @author lr
 *
 */
public class NodeDataDto {
	private  String startTime ;
	
	private String endTime ;
	
	private String user ;
	
	private Map<String ,Object> inData ;
	
	private Map<String ,Object> outData ;

	public String getStartTime() {
		return startTime;
	}

	public void setStartTime(String startTime) {
		this.startTime = startTime;
	}

	public String getEndTime() {
		return endTime;
	}

	public void setEndTime(String endTime) {
		this.endTime = endTime;
	}

	public String getUser() {
		return user;
	}

	public void setUser(String user) {
		this.user = user;
	}

	public Map<String, Object> getInData() {
		return inData;
	}

	public void setInData(Map<String, Object> inData) {
		this.inData = inData;
	}

	public Map<String, Object> getOutData() {
		return outData;
	}

	public void setOutData(Map<String, Object> outData) {
		this.outData = outData;
	}
	
	
}
